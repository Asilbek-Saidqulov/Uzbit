require('./ts-loader.cjs');
const test = require('node:test');
const assert = require('node:assert/strict');
const { mathEngine } = require('../src/core/math/engine.ts');
const { Rational } = require('../src/core/math/rational.ts');

test('Exact Rational arithmetic: 1/3 + 1/6 equals exact 1/2', () => {
  const r1 = new Rational(1, 3);
  const r2 = new Rational(1, 6);
  const sum = r1.add(r2);
  assert.equal(sum.num, 1n);
  assert.equal(sum.den, 2n);
  assert.equal(sum.toString(), '1/2');

  const res = mathEngine.evaluate('1/3 + 1/6');
  assert.equal(res.status, 'success');
  if (res.status === 'success') {
    assert.equal(res.exact, '1/2');
    assert.equal(res.approximation, 0.5);
  }
});

test('Exact Rational operations: subtraction and multiplication of fractions', () => {
  const resSub = mathEngine.evaluate('7/12 - 1/4');
  assert.equal(resSub.status, 'success');
  if (resSub.status === 'success') {
    assert.equal(resSub.exact, '1/3');
  }

  const resMul = mathEngine.evaluate('(2/3) * (9/4)');
  assert.equal(resMul.status, 'success');
  if (resMul.status === 'success') {
    assert.equal(resMul.exact, '3/2');
    assert.equal(resMul.approximation, 1.5);
  }
});

test('Exponentiation: right-associative power chains', () => {
  const res = mathEngine.evaluate('2^3^2');
  assert.equal(res.status, 'success');
  if (res.status === 'success') {
    assert.equal(res.approximation, 512); // 2^(3^2) = 2^9 = 512
  }
});

test('Implicit multiplication: 2pi and 3(4 + 5)', () => {
  const res1 = mathEngine.evaluate('2pi');
  assert.equal(res1.status, 'success');
  if (res1.status === 'success') {
    assert.ok(Math.abs(res1.approximation - 2 * Math.PI) < 1e-9);
  }

  const res2 = mathEngine.evaluate('3(4 + 5)');
  assert.equal(res2.status, 'success');
  if (res2.status === 'success') {
    assert.equal(res2.approximation, 27);
  }
});

test('Trigonometry with configurable angle modes: Radians vs Degrees', () => {
  // Degrees
  const sinDeg = mathEngine.evaluate('sin(90)', { angleMode: 'degrees' });
  assert.equal(sinDeg.status, 'success');
  if (sinDeg.status === 'success') {
    assert.equal(Math.round(sinDeg.approximation), 1);
  }

  const cosDeg = mathEngine.evaluate('cos(60)', { angleMode: 'degrees' });
  assert.equal(cosDeg.status, 'success');
  if (cosDeg.status === 'success') {
    assert.ok(Math.abs(cosDeg.approximation - 0.5) < 1e-9);
    assert.equal(cosDeg.exact, '1/2');
  }

  // Radians
  const sinRad = mathEngine.evaluate('sin(pi / 2)', { angleMode: 'radians' });
  assert.equal(sinRad.status, 'success');
  if (sinRad.status === 'success') {
    assert.equal(Math.round(sinRad.approximation), 1);
  }
});

test('Factorials, Combinations and Permutations', () => {
  const resFact = mathEngine.evaluate('5!');
  assert.equal(resFact.status, 'success');
  if (resFact.status === 'success') {
    assert.equal(resFact.approximation, 120);
  }

  const resZeroFact = mathEngine.evaluate('0!');
  assert.equal(resZeroFact.status, 'success');
  if (resZeroFact.status === 'success') {
    assert.equal(resZeroFact.approximation, 1);
  }

  const resComb = mathEngine.evaluate('nCr(5, 2)');
  assert.equal(resComb.status, 'success');
  if (resComb.status === 'success') {
    assert.equal(resComb.approximation, 10);
  }

  const resPerm = mathEngine.evaluate('nPr(5, 2)');
  assert.equal(resPerm.status, 'success');
  if (resPerm.status === 'success') {
    assert.equal(resPerm.approximation, 20);
  }
});

test('Domain safety: Division by zero, negative sqrt, and log errors', () => {
  const divZero = mathEngine.evaluate('10 / 0');
  assert.equal(divZero.status, 'error');

  const negSqrt = mathEngine.evaluate('sqrt(-4)');
  assert.equal(negSqrt.status, 'error');

  const negLog = mathEngine.evaluate('ln(-1)');
  assert.equal(negLog.status, 'error');

  const zeroLog = mathEngine.evaluate('log(0)');
  assert.equal(zeroLog.status, 'error');
});
