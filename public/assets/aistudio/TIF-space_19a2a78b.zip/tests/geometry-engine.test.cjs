require('./ts-loader.cjs');
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  distance,
  midpoint,
  angleBetween,
  triangleArea,
  perpendicularVector,
} = require('../src/core/geometry/geometryMath.ts');

test('Geometry Math: Euclidean distance between (0, 0) and (3, 4) is 5', () => {
  const d = distance({ x: 0, y: 0 }, { x: 3, y: 4 });
  assert.equal(d, 5);
});

test('Geometry Math: Midpoint between (-2, 4) and (4, -2) is (1, 1)', () => {
  const m = midpoint({ x: -2, y: 4 }, { x: 4, y: -2 });
  assert.equal(m.x, 1);
  assert.equal(m.y, 1);
});

test('Geometry Math: Angle between (1, 0), (0, 0), and (0, 1) is 90 degrees', () => {
  const ang = angleBetween({ x: 1, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 1 });
  assert.equal(Math.round(ang), 90);
});

test('Geometry Math: Equilateral triangle has 60 degree interior angles', () => {
  const a = { x: 0, y: 0 };
  const b = { x: 2, y: 0 };
  const c = { x: 1, y: Math.sqrt(3) };
  const angA = angleBetween(b, a, c);
  const angB = angleBetween(a, b, c);
  const angC = angleBetween(a, c, b);

  assert.equal(Math.round(angA), 60);
  assert.equal(Math.round(angB), 60);
  assert.equal(Math.round(angC), 60);
});

test('Geometry Math: Triangle area of right triangle with legs 3 and 4 is 6', () => {
  const a = { x: 0, y: 0 };
  const b = { x: 3, y: 0 };
  const c = { x: 0, y: 4 };
  const area = triangleArea(a, b, c);
  assert.equal(Math.round(area), 6);
});

test('Geometry Math: Perpendicular vector is orthogonal (dot product is 0)', () => {
  const v = { x: 3, y: -2 };
  const perp = perpendicularVector(v);
  assert.equal(perp.x, 2);
  assert.equal(perp.y, 3);
  const dot = v.x * perp.x + v.y * perp.y;
  assert.equal(dot, 0);
});
