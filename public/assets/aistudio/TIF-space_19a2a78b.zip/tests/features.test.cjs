require('./ts-loader.cjs');
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseRelation } = require('../src/lib/relation.ts');
const { compileExpr, findFreeIdentifiers } = require('../src/lib/expr.ts');
const { identifyPointsOfInterest, findLocalExtrema } = require('../src/lib/analysis.ts');

test('parses reusable function definition f(x) = 2x^2 + 1', () => {
  const res = parseRelation('f(x) = 2x^2 + 1');
  assert.equal(res.status, 'ok');
  assert.equal(res.value.kind, 'functionDef');
  assert.equal(res.value.name, 'f');
  assert.equal(res.value.fn(3), 19);
});

test('evaluates user-defined function in subsequent expression', () => {
  const fDef = parseRelation('f(x) = 3x - 2');
  assert.equal(fDef.status, 'ok');

  const env = {
    funcs: { f: fDef.value.fn },
  };

  const expr = compileExpr('f(4) + 1', env);
  assert.equal(expr.fn(0, 0), 11);
});

test('detects unbound parameter variables in expression', () => {
  const free = findFreeIdentifiers('y = a*x^2 + b*x + c');
  assert.ok(free.includes('a'));
  assert.ok(free.includes('b'));
  assert.ok(free.includes('c'));
  assert.ok(!free.includes('x'));
  assert.ok(!free.includes('y'));
});

test('detects local extrema: parabola vertex at minimum', () => {
  const f = (x) => x * x - 4;
  const extrema = findLocalExtrema(f, -5, 5);
  assert.equal(extrema.length, 1);
  assert.equal(extrema[0].kind, 'minimum');
  assert.ok(Math.abs(extrema[0].x - 0) < 1e-4);
  assert.ok(Math.abs(extrema[0].y - -4) < 1e-4);
});

test('identifies roots, y-intercept, and extrema for y = x^2 - 4', () => {
  const targets = [{ id: '1', label: 'y = x^2 - 4', fn: (x) => x * x - 4 }];
  const pois = identifyPointsOfInterest(targets, -5, 5);

  const roots = pois.filter((p) => p.kind === 'root');
  assert.equal(roots.length, 2);
  assert.ok(roots.some((r) => Math.abs(r.x - -2) < 1e-4));
  assert.ok(roots.some((r) => Math.abs(r.x - 2) < 1e-4));

  const yInt = pois.find((p) => p.kind === 'yintercept');
  assert.ok(yInt);
  assert.equal(yInt.x, 0);
  assert.equal(yInt.y, -4);

  const min = pois.find((p) => p.kind === 'minimum');
  assert.ok(min);
  assert.ok(Math.abs(min.x - 0) < 1e-4);
  assert.ok(Math.abs(min.y - -4) < 1e-4);
});

test('detects intersections between two curves', () => {
  const targets = [
    { id: '1', label: 'y = x^2', fn: (x) => x * x },
    { id: '2', label: 'y = 4', fn: () => 4 },
  ];
  const pois = identifyPointsOfInterest(targets, -5, 5);
  const intersections = pois.filter((p) => p.kind === 'intersection');

  assert.equal(intersections.length, 2);
  assert.ok(intersections.some((p) => Math.abs(p.x - -2) < 1e-4 && Math.abs(p.y - 4) < 1e-4));
  assert.ok(intersections.some((p) => Math.abs(p.x - 2) < 1e-4 && Math.abs(p.y - 4) < 1e-4));
});