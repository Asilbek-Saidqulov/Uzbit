require('./ts-loader.cjs');
const test = require('node:test');
const assert = require('node:assert/strict');
const { fitLinear, fitQuadratic, fitExponential } = require('../src/lib/regression.ts');
const { solveSystemOfEquations } = require('../src/lib/analysis.ts');

test('linear regression: fits exact line y = 2x + 1 with R² = 1', () => {
  const points = [
    { x: 0, y: 1 },
    { x: 1, y: 3 },
    { x: 2, y: 5 },
    { x: 3, y: 7 },
  ];
  const res = fitLinear(points);
  assert.ok(res);
  assert.equal(res.parameters.m, 2);
  assert.equal(res.parameters.b, 1);
  assert.equal(res.r2, 1);
});

test('quadratic regression: fits exact parabola y = x^2 - 2 with R² = 1', () => {
  const points = [
    { x: -2, y: 2 },
    { x: -1, y: -1 },
    { x: 0, y: -2 },
    { x: 1, y: -1 },
    { x: 2, y: 2 },
  ];
  const res = fitQuadratic(points);
  assert.ok(res);
  assert.equal(res.parameters.a, 1);
  assert.equal(res.parameters.b, 0);
  assert.equal(res.parameters.c, -2);
  assert.equal(res.r2, 1);
});

test('exponential regression: fits y = 2 * e^(0.5x)', () => {
  const points = [
    { x: 0, y: 2 },
    { x: 2, y: 2 * Math.exp(1) },
    { x: 4, y: 2 * Math.exp(2) },
  ];
  const res = fitExponential(points);
  assert.ok(res);
  assert.ok(Math.abs(res.parameters.a - 2) < 1e-3);
  assert.ok(Math.abs(res.parameters.b - 0.5) < 1e-3);
  assert.equal(res.r2, 1);
});

test('systems solver: finds verified intersections between y = x^2 and y = x + 2', () => {
  const funcs = [
    { id: '1', label: 'y = x^2', fn: (x) => x * x },
    { id: '2', label: 'y = x + 2', fn: (x) => x + 2 },
  ];
  const solutions = solveSystemOfEquations(funcs, -5, 5);
  assert.equal(solutions.length, 2);
  assert.ok(solutions.some((s) => Math.abs(s.x - -1) < 1e-4 && s.status === 'verified'));
  assert.ok(solutions.some((s) => Math.abs(s.x - 2) < 1e-4 && s.status === 'verified'));
});