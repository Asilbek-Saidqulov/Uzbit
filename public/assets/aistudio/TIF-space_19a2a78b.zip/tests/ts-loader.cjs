const fs = require('node:fs');
const esbuild = require('esbuild');

require.extensions['.ts'] = (module, filename) => {
  const source = fs.readFileSync(filename, 'utf8');
  const { code } = esbuild.transformSync(source, {
    loader: 'ts',
    format: 'cjs',
    target: 'es2022',
  });
  module._compile(code, filename);
};
