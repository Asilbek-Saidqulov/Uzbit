require('./ts-loader.cjs');
const test = require('node:test');
const assert = require('node:assert/strict');
const { traceZeroSet } = require('../src/lib/implicit.ts');

test('detects an isolated zero between grid samples', () => {
  const contours = traceZeroSet(
    (x, y) => x * x + y * y,
    { xmin: -1, xmax: 1, ymin: -1, ymax: 1 },
    3,
    3
  );

  assert.equal(contours.length, 1);
  assert.equal(contours[0].xs.length, 1);
  assert.ok(Math.abs(contours[0].xs[0]) < 1e-8);
  assert.ok(Math.abs(contours[0].ys[0]) < 1e-8);
});

test('does not turn a positive local minimum into a zero', () => {
  const contours = traceZeroSet(
    (x, y) => x * x + y * y + 0.1,
    { xmin: -1, xmax: 1, ymin: -1, ymax: 1 },
    3,
    3
  );

  assert.equal(contours.length, 0);
});

test('renders a regular circle as a continuous contour, not isolated dots', () => {
  const contours = traceZeroSet(
    (x, y) => x * x + y * y - 9,
    { xmin: -5, xmax: 5, ymin: -5, ymax: 5 },
    100,
    100
  );

  assert.ok(contours.length >= 1);
  assert.ok(contours.every((line) => line.xs.length > 1));
  assert.ok(contours.some((line) => line.xs.length > 20));
});
