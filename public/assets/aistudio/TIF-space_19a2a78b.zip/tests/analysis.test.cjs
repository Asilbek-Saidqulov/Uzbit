require('./ts-loader.cjs');
const test = require('node:test');
const assert = require('node:assert/strict');
const { differentiate, integrateAdaptive } = require('../src/lib/analysis.ts');

test('polynomial definite integral: x^2 - 4 over [0, 2] = -16/3', () => {
  const f = (x) => x * x - 4;
  const res = integrateAdaptive(f, 0, 2);
  assert.equal(res.status, 'ok');
  assert.ok(Math.abs(res.value - -16 / 3) < 1e-6);
  assert.equal(res.reversed, false);
});

test('trigonometric integral: sin(x) over [0, pi] = 2', () => {
  const res = integrateAdaptive(Math.sin, 0, Math.PI);
  assert.equal(res.status, 'ok');
  assert.ok(Math.abs(res.value - 2.0) < 1e-6);
});

test('reversed bounds: integral over [2, 0] = -integral over [0, 2]', () => {
  const f = (x) => x * x - 4;
  const normal = integrateAdaptive(f, 0, 2);
  const reversed = integrateAdaptive(f, 2, 0);

  assert.equal(normal.status, 'ok');
  assert.equal(reversed.status, 'ok');
  assert.equal(reversed.reversed, true);
  assert.ok(Math.abs(reversed.value - 16 / 3) < 1e-6);
  assert.ok(Math.abs(normal.value + reversed.value) < 1e-6);
});

test('zero-width interval: integral over [a, a] = 0', () => {
  const res = integrateAdaptive((x) => x ** 3, 5, 5);
  assert.equal(res.status, 'ok');
  assert.equal(res.value, 0);
  assert.equal(res.errorEstimate, 0);
});

test('detects singular or divergent asymptote: 1/(x - 1) over [0, 2]', () => {
  const f = (x) => 1 / (x - 1);
  const res = integrateAdaptive(f, 0, 2);
  assert.ok(res.status === 'divergent' || res.status === 'singular');
});

test('numerical differentiation: d/dx(x^2 - 4) at x = 1 equals 2', () => {
  const f = (x) => x * x - 4;
  const d = differentiate(f, 1);
  assert.equal(d.isDefined, true);
  assert.ok(Math.abs(d.value - 2.0) < 1e-4);
});

test('detects non-differentiable corner point: |x| at x = 0', () => {
  const absFn = (x) => Math.abs(x);
  const d = differentiate(absFn, 0);
  assert.equal(d.isDefined, false);
  assert.ok(d.reason && d.reason.includes('Non-differentiable'));
});