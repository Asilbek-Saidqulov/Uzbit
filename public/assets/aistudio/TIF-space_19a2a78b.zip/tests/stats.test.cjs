require('./ts-loader.cjs');
const test = require('node:test');
const assert = require('node:assert/strict');
const { computeSummaryStatistics } = require('../src/lib/stats.ts');
const { compileExpr } = require('../src/lib/expr.ts');

test('summary statistics: computes mean, median, IQR, and standard deviation', () => {
  const data = [10, 12, 14, 15, 17, 18, 20];
  const stats = computeSummaryStatistics(data);
  assert.ok(stats);
  assert.equal(stats.n, 7);
  assert.equal(stats.mean, 15.1429);
  assert.equal(stats.median, 15);
  assert.equal(stats.min, 10);
  assert.equal(stats.max, 20);
  assert.equal(stats.q1, 13);
  assert.equal(stats.q3, 17.5);
  assert.equal(stats.iqr, 4.5);
  assert.ok(Math.abs(stats.stdevSample - 3.4847) < 1e-2);
});

test('handles modes and multimodal datasets', () => {
  const data = [1, 2, 2, 3, 4, 4, 5];
  const stats = computeSummaryStatistics(data);
  assert.ok(stats);
  assert.deepEqual(stats.modes, [2, 4]);
});

test('evaluates newly added mathematical functions in expr.ts', () => {
  const secExpr = compileExpr('sec(0)');
  assert.equal(secExpr.fn(0, 0), 1);

  const cbrtExpr = compileExpr('cbrt(27)');
  assert.equal(cbrtExpr.fn(0, 0), 3);

  const log2Expr = compileExpr('log2(8)');
  assert.equal(log2Expr.fn(0, 0), 3);

  const sincExpr = compileExpr('sinc(0)');
  assert.equal(sincExpr.fn(0, 0), 1);
});