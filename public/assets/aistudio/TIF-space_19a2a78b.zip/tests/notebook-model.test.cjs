require('./ts-loader.cjs');
const test = require('node:test');
const assert = require('node:assert/strict');
const {
  createDocument,
  createBlock,
  INITIAL_NOTEBOOKS,
} = require('../src/core/notebook/notebookStore.ts');

test('Notebook Document Model: verifies initial notebook seeds schema', () => {
  assert.ok(Array.isArray(INITIAL_NOTEBOOKS));
  assert.ok(INITIAL_NOTEBOOKS.length >= 3);

  const calcDoc = INITIAL_NOTEBOOKS[0];
  assert.equal(calcDoc.id, 'nb-calculus-1');
  assert.equal(calcDoc.schemaVersion, 1);
  assert.ok(calcDoc.blocks.length >= 5);

  const blockTypes = new Set(calcDoc.blocks.map((b) => b.type));
  assert.ok(blockTypes.has('heading'));
  assert.ok(blockTypes.has('callout'));
  assert.ok(blockTypes.has('math'));
  assert.ok(blockTypes.has('graph'));
  assert.ok(blockTypes.has('derivation'));
  assert.ok(blockTypes.has('table'));
});

test('Notebook Document Model: block creation factory handles all block types', () => {
  const heading = createBlock('heading', 0);
  assert.equal(heading.type, 'heading');
  assert.equal(heading.content.level, 2);

  const math = createBlock('math', 1);
  assert.equal(math.type, 'math');
  assert.ok(typeof math.content.latex === 'string');

  const graph = createBlock('graph', 2);
  assert.equal(graph.type, 'graph');
  assert.ok(typeof graph.content.expression === 'string');

  const derivation = createBlock('derivation', 3);
  assert.equal(derivation.type, 'derivation');
  assert.ok(Array.isArray(derivation.content.steps));
  assert.ok(derivation.content.steps.length >= 2);

  const table = createBlock('table', 4);
  assert.equal(table.type, 'table');
  assert.ok(Array.isArray(table.content.rows));

  const callout = createBlock('callout', 5);
  assert.equal(callout.type, 'callout');
  assert.equal(callout.content.kind, 'note');
});

test('Notebook Document Model: creates a new document with valid schema', () => {
  const doc = createDocument('My Complex Analysis Notebook');
  assert.ok(doc.id.startsWith('nb-'));
  assert.equal(doc.title, 'My Complex Analysis Notebook');
  assert.equal(doc.schemaVersion, 1);
  assert.equal(doc.blocks.length, 2);
  assert.equal(doc.blocks[0].type, 'heading');
  assert.equal(doc.blocks[0].content.text, 'My Complex Analysis Notebook');
});

test('Notebook Document Model: JSON serialization roundtrip preserves block contents', () => {
  const original = INITIAL_NOTEBOOKS[0];
  const jsonStr = JSON.stringify(original);
  const parsed = JSON.parse(jsonStr);

  assert.equal(parsed.id, original.id);
  assert.equal(parsed.blocks.length, original.blocks.length);
  assert.deepEqual(parsed.blocks[0], original.blocks[0]);
  assert.deepEqual(parsed.blocks[4], original.blocks[4]); // Graph block
});

test('Notebook Document Model: supports structured mathematical entities & relationships', () => {
  const calcBlock = createBlock('calculation', 0);
  assert.equal(calcBlock.type, 'calculation');
  assert.equal(calcBlock.content.expression, '1/3 + 1/6');
  assert.equal(calcBlock.content.exactResult, '1/2');

  const proofBlock = createBlock('proof', 1);
  assert.equal(proofBlock.type, 'proof');
  assert.ok(Array.isArray(proofBlock.content.steps));
  assert.ok(proofBlock.content.conclusion.includes('Q.E.D.'));

  const defBlock = createBlock('definition', 2);
  assert.equal(defBlock.type, 'definition');
  assert.equal(defBlock.content.term, 'Continuity at a Point');

  const resultBlock = createBlock('result', 3);
  assert.equal(resultBlock.type, 'result');
  assert.equal(resultBlock.content.status, 'exact');

  const sectionBlock = createBlock('section', 4);
  assert.equal(sectionBlock.type, 'section');
  assert.equal(sectionBlock.content.title, 'Section Topic');

  // Verify relational links on seed document
  const seedDoc = INITIAL_NOTEBOOKS[0];
  const mathBlock = seedDoc.blocks.find((b) => b.id === 'b-4');
  assert.ok(Array.isArray(mathBlock.relationships));
  assert.equal(mathBlock.relationships[0].type, 'visualizedBy');
  assert.equal(mathBlock.relationships[0].targetBlockId, 'b-5');
  assert.equal(mathBlock.relationships[1].type, 'derivedFrom');
  assert.equal(mathBlock.relationships[1].targetBlockId, 'b-7');
});

test('Notebook Regression Engine: computes exact linear and quadratic fits', () => {
  const { computeLinearRegression, computeQuadraticRegression } = require('../src/core/math/regression.ts');

  // Test y = 2x + 1
  const linearPoints = [
    { x: 0, y: 1 },
    { x: 1, y: 3 },
    { x: 2, y: 5 },
    { x: 3, y: 7 },
  ];
  const linResult = computeLinearRegression(linearPoints);
  assert.ok(linResult);
  assert.equal(linResult.model, 'linear');
  assert.equal(linResult.parameters.m, 2);
  assert.equal(linResult.parameters.b, 1);
  assert.equal(linResult.r2, 1);

  // Test y = x^2
  const quadPoints = [
    { x: -2, y: 4 },
    { x: -1, y: 1 },
    { x: 0, y: 0 },
    { x: 1, y: 1 },
    { x: 2, y: 4 },
  ];
  const quadResult = computeQuadraticRegression(quadPoints);
  assert.ok(quadResult);
  assert.equal(quadResult.model, 'quadratic');
  assert.equal(Math.round(quadResult.parameters.a), 1);
  assert.equal(Math.round(quadResult.parameters.b), 0);
  assert.equal(Math.round(quadResult.parameters.c), 0);
  assert.equal(quadResult.r2, 1);
});

test('Notebook Document Model: exports documents to Markdown and LaTeX', () => {
  const { exportToMarkdown, exportToLaTeX } = require('../src/core/notebook/exportUtils.ts');
  const seedDoc = INITIAL_NOTEBOOKS[0];

  const md = exportToMarkdown(seedDoc);
  assert.ok(md.includes('# Calculus I: Tangent Lines & Definite Integrals'));
  assert.ok(md.includes('f(x) = x^2 - 4'));
  assert.ok(md.includes('Riemann Quadrature Proof') || md.includes('Definite Integral'));

  const tex = exportToLaTeX(seedDoc);
  assert.ok(tex.includes('\\documentclass{article}'));
  assert.ok(tex.includes('\\begin{equation}'));
  assert.ok(tex.includes('\\end{document}'));
});
