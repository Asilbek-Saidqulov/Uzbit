require('./ts-loader.cjs');
const test = require('node:test');
const assert = require('node:assert/strict');
const { compileExpr } = require('../src/lib/expr.ts');
const { parseDisplay } = require('../src/lib/mathTree.ts');

test('power chains are displayed right-associatively like the evaluator', () => {
  assert.equal(compileExpr('x^2^3').fn(2, 0), 256);

  const display = parseDisplay('x^2^3');
  assert.equal(display.nodes.length, 1);
  assert.equal(display.nodes[0].t, 'sup');
  assert.equal(display.nodes[0].exp.nodes[0].t, 'sup');
});

test('implicit function arguments are grouped before an exponent', () => {
  assert.equal(compileExpr('sinx^2').fn(2, 0), Math.sin(2) ** 2);

  const display = parseDisplay('sinx^2');
  assert.equal(display.nodes.length, 1);
  assert.equal(display.nodes[0].t, 'sup');
  assert.deepEqual(
    display.nodes[0].base.nodes.map((node) => node.t),
    ['ch', 'ch', 'ch', 'lit', 'ch', 'lit']
  );
});
