/**
 * Euclidean Geometry Math Core for TIFspace Geometry Lab
 * Blueprint Section 4.4: Geometric calculations, constraints, and measurements.
 */

export interface GeoPoint {
  id: string;
  name: string;
  x: number;
  y: number;
  fixed?: boolean;
}

export interface GeoSegment {
  id: string;
  name: string;
  p1Id: string;
  p2Id: string;
  color?: string;
}

export interface GeoLine {
  id: string;
  name: string;
  p1Id: string;
  p2Id: string;
  type: 'line' | 'perpendicularBisector';
  color?: string;
}

export interface GeoCircle {
  id: string;
  name: string;
  centerId: string;
  radiusPointId?: string;
  radius?: number;
  color?: string;
}

export interface GeoPolygon {
  id: string;
  name: string;
  pointIds: string[];
  color?: string;
}

export interface GeoAngle {
  id: string;
  p1Id: string; // ray 1 end
  vertexId: string; // vertex
  p2Id: string; // ray 2 end
}

/**
 * Computes Euclidean distance between two 2D points.
 */
export function distance(p1: { x: number; y: number }, p2: { x: number; y: number }): number {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  return Math.sqrt(dx * dx + dy * dy);
}

/**
 * Computes exact midpoint between two 2D points.
 */
export function midpoint(p1: { x: number; y: number }, p2: { x: number; y: number }): { x: number; y: number } {
  return {
    x: (p1.x + p2.x) / 2,
    y: (p1.y + p2.y) / 2,
  };
}

/**
 * Computes angle at vertex B formed by rays BA and BC in degrees (0 to 180).
 */
export function angleBetween(
  a: { x: number; y: number },
  b: { x: number; y: number }, // vertex
  c: { x: number; y: number }
): number {
  const v1 = { x: a.x - b.x, y: a.y - b.y };
  const v2 = { x: c.x - b.x, y: c.y - b.y };

  const dot = v1.x * v2.x + v1.y * v2.y;
  const mag1 = Math.sqrt(v1.x * v1.x + v1.y * v1.y);
  const mag2 = Math.sqrt(v2.x * v2.x + v2.y * v2.y);

  if (mag1 === 0 || mag2 === 0) return 0;
  const cosTheta = Math.max(-1, Math.min(1, dot / (mag1 * mag2)));
  return (Math.acos(cosTheta) * 180) / Math.PI;
}

/**
 * Computes triangle area using Heron's formula from side lengths.
 */
export function triangleArea(
  a: { x: number; y: number },
  b: { x: number; y: number },
  c: { x: number; y: number }
): number {
  const dAB = distance(a, b);
  const dBC = distance(b, c);
  const dCA = distance(c, a);
  const s = (dAB + dBC + dCA) / 2;
  const rad = s * (s - dAB) * (s - dBC) * (s - dCA);
  return rad > 0 ? Math.sqrt(rad) : 0;
}

/**
 * Calculates perpendicular slope given a direction vector.
 */
export function perpendicularVector(v: { x: number; y: number }): { x: number; y: number } {
  return { x: -v.y, y: v.x };
}
