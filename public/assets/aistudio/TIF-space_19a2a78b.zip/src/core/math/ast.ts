/**
 * Abstract Syntax Tree (AST) definitions for TIFspace mathematical expressions.
 * Blueprint Section 3.1: Versioned, structured mathematical expressions.
 */

import type { Rational } from './rational';

export type MathNodeType =
  | 'number'
  | 'variable'
  | 'constant'
  | 'binary'
  | 'unary'
  | 'function'
  | 'factorial'
  | 'equation';

export interface BaseNode {
  type: MathNodeType;
}

export interface NumberNode extends BaseNode {
  type: 'number';
  value: number;
  raw?: string;
  exactRational?: { num: string; den: string };
}

export interface VariableNode extends BaseNode {
  type: 'variable';
  name: string;
}

export interface ConstantNode extends BaseNode {
  type: 'constant';
  symbol: 'pi' | 'e' | 'phi';
  value: number;
}

export interface BinaryNode extends BaseNode {
  type: 'binary';
  operator: '+' | '-' | '*' | '/' | '^' | '%';
  left: MathNode;
  right: MathNode;
}

export interface UnaryNode extends BaseNode {
  type: 'unary';
  operator: '+' | '-';
  operand: MathNode;
}

export interface FunctionCallNode extends BaseNode {
  type: 'function';
  name: string;
  args: MathNode[];
}

export interface FactorialNode extends BaseNode {
  type: 'factorial';
  operand: MathNode;
}

export interface EquationNode extends BaseNode {
  type: 'equation';
  relation: '=' | '<' | '<=' | '>' | '>=';
  left: MathNode;
  right: MathNode;
}

export type MathNode =
  | NumberNode
  | VariableNode
  | ConstantNode
  | BinaryNode
  | UnaryNode
  | FunctionCallNode
  | FactorialNode
  | EquationNode;

export interface MathExpressionDocument {
  version: 1;
  root: MathNode;
  sourceText?: string;
}

/**
 * Converts a MathNode AST into clean mathematical text representation.
 */
export function astToString(node: MathNode): string {
  switch (node.type) {
    case 'number':
      return node.exactRational && node.exactRational.den !== '1'
        ? `${node.exactRational.num}/${node.exactRational.den}`
        : String(node.value);
    case 'variable':
      return node.name;
    case 'constant':
      return node.symbol === 'pi' ? 'π' : node.symbol === 'phi' ? 'φ' : 'e';
    case 'unary':
      return `${node.operator}${astToString(node.operand)}`;
    case 'binary':
      return `(${astToString(node.left)} ${node.operator} ${astToString(node.right)})`;
    case 'function':
      return `${node.name}(${node.args.map(astToString).join(', ')})`;
    case 'factorial':
      return `(${astToString(node.operand)})!`;
    case 'equation':
      return `${astToString(node.left)} ${node.relation} ${astToString(node.right)}`;
    default:
      return '';
  }
}

/**
 * Formats AST to LaTeX string.
 */
export function astToLaTeX(node: MathNode): string {
  switch (node.type) {
    case 'number':
      if (node.exactRational && node.exactRational.den !== '1') {
        const sign = node.exactRational.num.startsWith('-') ? '-' : '';
        const absNum = node.exactRational.num.replace('-', '');
        return `${sign}\\frac{${absNum}}{${node.exactRational.den}}`;
      }
      return String(node.value);
    case 'variable':
      return node.name;
    case 'constant':
      return node.symbol === 'pi' ? '\\pi' : node.symbol === 'phi' ? '\\phi' : 'e';
    case 'unary':
      return `${node.operator}${astToLaTeX(node.operand)}`;
    case 'binary':
      if (node.operator === '/') {
        return `\\frac{${astToLaTeX(node.left)}}{${astToLaTeX(node.right)}}`;
      }
      if (node.operator === '*') {
        return `${astToLaTeX(node.left)} \\cdot ${astToLaTeX(node.right)}`;
      }
      if (node.operator === '^') {
        return `{${astToLaTeX(node.left)}}^{${astToLaTeX(node.right)}}`;
      }
      return `${astToLaTeX(node.left)} ${node.operator} ${astToLaTeX(node.right)}`;
    case 'function':
      if (node.name === 'sqrt') {
        return `\\sqrt{${astToLaTeX(node.args[0])}}`;
      }
      if (node.name === 'sin' || node.name === 'cos' || node.name === 'tan' || node.name === 'ln') {
        return `\\${node.name}\\left(${node.args.map(astToLaTeX).join(', ')}\\right)`;
      }
      return `\\operatorname{${node.name}}\\left(${node.args.map(astToLaTeX).join(', ')}\\right)`;
    case 'factorial':
      return `${astToLaTeX(node.operand)}!`;
    case 'equation':
      const rel = node.relation === '<=' ? '\\le' : node.relation === '>=' ? '\\ge' : node.relation;
      return `${astToLaTeX(node.left)} ${rel} ${astToLaTeX(node.right)}`;
    default:
      return '';
  }
}
