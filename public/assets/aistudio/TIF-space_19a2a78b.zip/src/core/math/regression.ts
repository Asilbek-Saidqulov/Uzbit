/**
 * TIFspace Deterministic Polynomial & Linear Regression Engine
 * Pure mathematical algorithms for coordinate table fitting.
 */

export interface Point {
  x: number;
  y: number;
}

export interface RegressionResult {
  model: 'linear' | 'quadratic';
  equation: string;
  latex: string;
  r2: number;
  parameters: { [key: string]: number };
}

/**
 * Computes Ordinary Least Squares (OLS) Linear Regression: y = mx + b
 */
export function computeLinearRegression(points: Point[]): RegressionResult | null {
  const valid = points.filter((p) => !isNaN(p.x) && !isNaN(p.y) && isFinite(p.x) && isFinite(p.y));
  const n = valid.length;
  if (n < 2) return null;

  let sumX = 0;
  let sumY = 0;
  for (const p of valid) {
    sumX += p.x;
    sumY += p.y;
  }
  const meanX = sumX / n;
  const meanY = sumY / n;

  let ssXX = 0;
  let ssXY = 0;
  let ssYY = 0;

  for (const p of valid) {
    const dx = p.x - meanX;
    const dy = p.y - meanY;
    ssXX += dx * dx;
    ssXY += dx * dy;
    ssYY += dy * dy;
  }

  if (Math.abs(ssXX) < 1e-12) return null; // Vertical line

  const m = ssXY / ssXX;
  const b = meanY - m * meanX;

  const r2 = ssYY === 0 ? 1 : Math.max(0, Math.min(1, (ssXY * ssXY) / (ssXX * ssYY)));

  const mStr = Math.abs(m - Math.round(m)) < 1e-4 ? Math.round(m).toString() : m.toFixed(4);
  const bSign = b >= 0 ? '+' : '-';
  const bAbs = Math.abs(b);
  const bStr = Math.abs(bAbs - Math.round(bAbs)) < 1e-4 ? Math.round(bAbs).toString() : bAbs.toFixed(4);

  const equation = b === 0 ? `y = ${mStr}x` : `y = ${mStr}x ${bSign} ${bStr}`;
  const latex = b === 0 ? `y = ${mStr}x` : `y = ${mStr}x ${bSign} ${bStr}`;

  return {
    model: 'linear',
    equation,
    latex,
    r2,
    parameters: { m, b },
  };
}

/**
 * Computes Quadratic Regression: y = ax^2 + bx + c using 3x3 Gaussian elimination
 */
export function computeQuadraticRegression(points: Point[]): RegressionResult | null {
  const valid = points.filter((p) => !isNaN(p.x) && !isNaN(p.y) && isFinite(p.x) && isFinite(p.y));
  const n = valid.length;
  if (n < 3) return null;

  let sumX = 0, sumX2 = 0, sumX3 = 0, sumX4 = 0;
  let sumY = 0, sumXY = 0, sumX2Y = 0;

  for (const p of valid) {
    const x = p.x;
    const y = p.y;
    const x2 = x * x;
    sumX += x;
    sumX2 += x2;
    sumX3 += x2 * x;
    sumX4 += x2 * x2;
    sumY += y;
    sumXY += x * y;
    sumX2Y += x2 * y;
  }

  // Matrix system: A * [c, b, a]^T = B
  const A = [
    [n, sumX, sumX2],
    [sumX, sumX2, sumX3],
    [sumX2, sumX3, sumX4],
  ];
  const B = [sumY, sumXY, sumX2Y];

  // 3x3 Determinant
  const det3 = (m: number[][]) =>
    m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
    m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
    m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);

  const detA = det3(A);
  if (Math.abs(detA) < 1e-12) return null;

  const replaceCol = (m: number[][], col: number, vec: number[]) => {
    return m.map((row, r) => row.map((val, c) => (c === col ? vec[r] : val)));
  };

  const cVal = det3(replaceCol(A, 0, B)) / detA;
  const bVal = det3(replaceCol(A, 1, B)) / detA;
  const aVal = det3(replaceCol(A, 2, B)) / detA;

  // Calculate R^2
  const meanY = sumY / n;
  let ssTot = 0;
  let ssRes = 0;
  for (const p of valid) {
    const yPred = aVal * p.x * p.x + bVal * p.x + cVal;
    ssTot += (p.y - meanY) ** 2;
    ssRes += (p.y - yPred) ** 2;
  }
  const r2 = ssTot === 0 ? 1 : Math.max(0, Math.min(1, 1 - ssRes / ssTot));

  const fmt = (v: number) =>
    Math.abs(v - Math.round(v)) < 1e-4 ? Math.round(v).toString() : v.toFixed(3);

  const equation = `y = ${fmt(aVal)}x^2 + ${fmt(bVal)}x + ${fmt(cVal)}`;
  const latex = `y = ${fmt(aVal)}x^2 ${bVal >= 0 ? '+' : '-'} ${fmt(Math.abs(bVal))}x ${cVal >= 0 ? '+' : '-'} ${fmt(Math.abs(cVal))}`;

  return {
    model: 'quadratic',
    equation,
    latex,
    r2,
    parameters: { a: aVal, b: bVal, c: cVal },
  };
}

