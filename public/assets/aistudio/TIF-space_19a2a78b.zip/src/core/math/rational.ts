/**
 * Exact Rational Arithmetic Engine for TIFspace.
 * Handles fractional numbers without floating-point degradation.
 * Computes exact additions, subtractions, multiplications, and divisions.
 */

export class Rational {
  readonly num: bigint;
  readonly den: bigint;

  constructor(numerator: bigint | number, denominator: bigint | number = 1n) {
    let n = typeof numerator === 'bigint' ? numerator : BigInt(Math.trunc(numerator));
    let d = typeof denominator === 'bigint' ? denominator : BigInt(Math.trunc(denominator));

    if (d === 0n) {
      throw new Error('DivisionByZero: Denominator cannot be zero');
    }

    if (d < 0n) {
      n = -n;
      d = -d;
    }

    const g = Rational.gcd(n < 0n ? -n : n, d);
    this.num = n / g;
    this.den = d / g;
  }

  static fromNumber(val: number, maxDenominator = 100000n): Rational {
    if (!Number.isFinite(val)) {
      throw new Error('Cannot create rational from non-finite number');
    }
    if (Math.abs(val) < 1e-12) return new Rational(0n, 1n);

    const sign = val < 0 ? -1n : 1n;
    const absVal = Math.abs(val);

    // If it's already an integer
    if (Math.floor(absVal) === absVal) {
      return new Rational(sign * BigInt(Math.floor(absVal)), 1n);
    }

    // Continued fraction approximation for exact representation
    let p0 = 0n, q0 = 1n, p1 = 1n, q1 = 0n;
    let x = absVal;

    for (let iter = 0; iter < 24; iter++) {
      const a = BigInt(Math.floor(x));
      const p2 = a * p1 + p0;
      const q2 = a * q1 + q0;

      if (q2 > maxDenominator) break;

      p0 = p1; q0 = q1;
      p1 = p2; q1 = q2;

      const frac = Number(p1) / Number(q1);
      if (Math.abs(absVal - frac) < 1e-10) break;

      const remainder = x - Math.floor(x);
      if (remainder < 1e-10) break;
      x = 1 / remainder;
    }

    return new Rational(sign * p1, q1);
  }

  static gcd(a: bigint, b: bigint): bigint {
    while (b !== 0n) {
      const t = b;
      b = a % b;
      a = t;
    }
    return a === 0n ? 1n : a;
  }

  add(other: Rational): Rational {
    return new Rational(
      this.num * other.den + other.num * this.den,
      this.den * other.den
    );
  }

  sub(other: Rational): Rational {
    return new Rational(
      this.num * other.den - other.num * this.den,
      this.den * other.den
    );
  }

  mul(other: Rational): Rational {
    return new Rational(this.num * other.num, this.den * other.den);
  }

  div(other: Rational): Rational {
    if (other.num === 0n) {
      throw new Error('DivisionByZero: Cannot divide by zero');
    }
    return new Rational(this.num * other.den, this.den * other.num);
  }

  pow(exponent: number): Rational {
    if (!Number.isInteger(exponent)) {
      throw new Error('Rational exponentiation only supports integer exponents');
    }
    if (exponent === 0) return new Rational(1n, 1n);
    if (exponent < 0) {
      return new Rational(this.den ** BigInt(-exponent), this.num ** BigInt(-exponent));
    }
    const exp = BigInt(exponent);
    return new Rational(this.num ** exp, this.den ** exp);
  }

  toNumber(): number {
    return Number(this.num) / Number(this.den);
  }

  toString(): string {
    if (this.den === 1n) return this.num.toString();
    return `${this.num}/${this.den}`;
  }

  toLaTeX(): string {
    if (this.den === 1n) return this.num.toString();
    const sign = this.num < 0n ? '-' : '';
    const absNum = this.num < 0n ? -this.num : this.num;
    return `${sign}\\frac{${absNum}}{${this.den}}`;
  }
}
