/**
 * TIFspace Mathematical Engine.
 * Implements Section 3.2 & 4.2 of the Technical Blueprint:
 * - Deterministic, non-eval, AST-driven evaluation
 * - Exact rational arithmetic reduction (e.g. 1/3 + 1/6 = 1/2)
 * - Configurable angle modes (Radians / Degrees)
 * - Controlled decimal precision
 * - Strict domain safety & error handling
 */

import { Rational } from './rational';
import type { MathNode } from './ast';

export type AngleMode = 'radians' | 'degrees';

export interface EvalOptions {
  angleMode?: AngleMode;
  precision?: number;
  variables?: Record<string, number>;
}

export type MathResult =
  | {
      status: 'success';
      exact?: string;
      exactLaTeX?: string;
      approximation: number;
      formatted: string;
      ast?: MathNode;
    }
  | {
      status: 'error';
      code: string;
      message: string;
    }
  | {
      status: 'unsupported';
      operation: string;
    };

export interface MathEngine {
  parse(input: string): MathNode;
  evaluate(input: string | MathNode, options?: EvalOptions): MathResult;
  simplify(input: string | MathNode): MathResult;
}

// Token types for recursive descent parser
type TokenType = 'NUMBER' | 'IDENT' | 'OP' | 'LPAREN' | 'RPAREN' | 'COMMA' | 'BANG';

interface Token {
  type: TokenType;
  value: string;
  pos: number;
}

const CONSTANTS: Record<string, number> = {
  pi: Math.PI,
  π: Math.PI,
  e: Math.E,
  phi: (1 + Math.sqrt(5)) / 2,
  φ: (1 + Math.sqrt(5)) / 2,
};

function factorial(n: number): number {
  if (n < 0 || !Number.isInteger(n)) {
    throw new Error('Factorial requires a non-negative integer');
  }
  if (n > 170) {
    throw new Error('Factorial overflow (maximum supported is 170!)');
  }
  let res = 1;
  for (let i = 2; i <= n; i++) res *= i;
  return res;
}

function combinations(n: number, r: number): number {
  if (n < 0 || r < 0 || r > n || !Number.isInteger(n) || !Number.isInteger(r)) {
    throw new Error('nCr requires integers 0 <= r <= n');
  }
  return factorial(n) / (factorial(r) * factorial(n - r));
}

function permutations(n: number, r: number): number {
  if (n < 0 || r < 0 || r > n || !Number.isInteger(n) || !Number.isInteger(r)) {
    throw new Error('nPr requires integers 0 <= r <= n');
  }
  return factorial(n) / factorial(n - r);
}

/**
 * Tokenizes a mathematical expression string.
 */
function tokenize(src: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;

  while (i < src.length) {
    const ch = src[i];

    if (/\s/.test(ch)) {
      i++;
      continue;
    }

    if (/[0-9.]/.test(ch)) {
      let numStr = '';
      const start = i;
      while (i < src.length && /[0-9.]/.test(src[i])) {
        numStr += src[i++];
      }
      tokens.push({ type: 'NUMBER', value: numStr, pos: start });
      continue;
    }

    if (/[a-zA-Zπφ_]/.test(ch)) {
      let ident = '';
      const start = i;
      while (i < src.length && /[a-zA-Z0-9πφ_]/.test(src[i])) {
        ident += src[i++];
      }
      tokens.push({ type: 'IDENT', value: ident, pos: start });
      continue;
    }

    if (ch === '(') {
      tokens.push({ type: 'LPAREN', value: '(', pos: i++ });
      continue;
    }

    if (ch === ')') {
      tokens.push({ type: 'RPAREN', value: ')', pos: i++ });
      continue;
    }

    if (ch === ',') {
      tokens.push({ type: 'COMMA', value: ',', pos: i++ });
      continue;
    }

    if (ch === '!') {
      tokens.push({ type: 'BANG', value: '!', pos: i++ });
      continue;
    }

    if ('+-*/^%'.includes(ch)) {
      tokens.push({ type: 'OP', value: ch, pos: i++ });
      continue;
    }

    throw new Error(`Unexpected character '${ch}' at position ${i}`);
  }

  return tokens;
}

/**
 * Recursive descent AST parser.
 * Handles implicit multiplication (e.g. 2pi, 3(4), 5x), operator precedence, right-associative powers.
 */
class Parser {
  private pos = 0;

  constructor(private tokens: Token[]) {}

  parse(): MathNode {
    if (this.tokens.length === 0) {
      throw new Error('Empty expression');
    }
    const node = this.parseExpression();
    if (this.pos < this.tokens.length) {
      throw new Error(`Unexpected token '${this.tokens[this.pos].value}' at position ${this.tokens[this.pos].pos}`);
    }
    return node;
  }

  private peek(): Token | undefined {
    return this.tokens[this.pos];
  }

  private consume(expected?: string): Token {
    const t = this.tokens[this.pos];
    if (!t) throw new Error('Unexpected end of expression');
    if (expected && t.value !== expected) {
      throw new Error(`Expected '${expected}' but got '${t.value}' at position ${t.pos}`);
    }
    this.pos++;
    return t;
  }

  // Precedence level 1: + -
  private parseExpression(): MathNode {
    let left = this.parseTerm();

    while (this.peek() && this.peek()!.type === 'OP' && (this.peek()!.value === '+' || this.peek()!.value === '-')) {
      const op = this.consume().value as '+' | '-';
      const right = this.parseTerm();
      left = { type: 'binary', operator: op, left, right };
    }

    return left;
  }

  // Precedence level 2: * / % and implicit multiplication
  private parseTerm(): MathNode {
    let left = this.parseFactor();

    while (this.pos < this.tokens.length) {
      const next = this.peek();
      if (!next) break;

      if (next.type === 'OP' && (next.value === '*' || next.value === '/' || next.value === '%')) {
        const op = this.consume().value as '*' | '/' | '%';
        const right = this.parseFactor();
        left = { type: 'binary', operator: op, left, right };
      } else if (this.isImplicitMulStart(next)) {
        // Implicit product: 2x, 3(4), etc.
        const right = this.parseFactor();
        left = { type: 'binary', operator: '*', left, right };
      } else {
        break;
      }
    }

    return left;
  }

  private isImplicitMulStart(t: Token): boolean {
    return t.type === 'NUMBER' || t.type === 'IDENT' || t.type === 'LPAREN';
  }

  // Precedence level 3: Right-associative exponentiation ^
  private parseFactor(): MathNode {
    const base = this.parseUnary();

    if (this.peek() && this.peek()!.type === 'OP' && this.peek()!.value === '^') {
      this.consume('^');
      const exponent = this.parseFactor(); // Right-associative
      return { type: 'binary', operator: '^', left: base, right: exponent };
    }

    return base;
  }

  // Precedence level 4: Unary + -
  private parseUnary(): MathNode {
    if (this.peek() && this.peek()!.type === 'OP' && (this.peek()!.value === '+' || this.peek()!.value === '-')) {
      const op = this.consume().value as '+' | '-';
      const operand = this.parseUnary();
      return { type: 'unary', operator: op, operand };
    }

    return this.parsePostfix();
  }

  // Postfix: factorial !
  private parsePostfix(): MathNode {
    let primary = this.parsePrimary();

    while (this.peek() && this.peek()!.type === 'BANG') {
      this.consume('!');
      primary = { type: 'factorial', operand: primary };
    }

    return primary;
  }

  // Primary: Number, Constant, Variable, Parentheses, Function call
  private parsePrimary(): MathNode {
    const t = this.peek();
    if (!t) throw new Error('Unexpected end of expression');

    if (t.type === 'NUMBER') {
      this.consume();
      const val = parseFloat(t.value);
      if (Number.isNaN(val)) throw new Error(`Invalid number '${t.value}'`);
      return { type: 'number', value: val, raw: t.value };
    }

    if (t.type === 'LPAREN') {
      this.consume('(');
      const expr = this.parseExpression();
      this.consume(')');
      return expr;
    }

    if (t.type === 'IDENT') {
      const name = this.consume().value.toLowerCase();

      // Check for constants
      if (name in CONSTANTS) {
        return {
          type: 'constant',
          symbol: name === 'pi' || name === 'π' ? 'pi' : name === 'phi' || name === 'φ' ? 'phi' : 'e',
          value: CONSTANTS[name],
        };
      }

      // Check if function call (followed by LPAREN)
      if (this.peek() && this.peek()!.type === 'LPAREN') {
        this.consume('(');
        const args: MathNode[] = [];
        if (this.peek() && this.peek()!.type !== 'RPAREN') {
          args.push(this.parseExpression());
          while (this.peek() && this.peek()!.type === 'COMMA') {
            this.consume(',');
            args.push(this.parseExpression());
          }
        }
        this.consume(')');
        return { type: 'function', name, args };
      }

      // Otherwise it's a variable
      return { type: 'variable', name };
    }

    throw new Error(`Unexpected token '${t.value}' at position ${t.pos}`);
  }
}

/**
 * Core Mathematical Engine instance
 */
export class DefaultMathEngine implements MathEngine {
  parse(input: string): MathNode {
    const tokens = tokenize(input.trim());
    const parser = new Parser(tokens);
    return parser.parse();
  }

  evaluate(input: string | MathNode, options: EvalOptions = {}): MathResult {
    const angleMode = options.angleMode || 'radians';
    const precision = options.precision ?? 8;
    const variables = options.variables || {};

    let ast: MathNode;
    try {
      ast = typeof input === 'string' ? this.parse(input) : input;
    } catch (err: any) {
      return {
        status: 'error',
        code: 'PARSE_ERROR',
        message: err.message || 'Failed to parse expression',
      };
    }

    try {
      // Step 1: Attempt exact rational arithmetic where possible
      const exactRat = this.tryExactRational(ast, variables);

      // Step 2: Compute numerical floating-point evaluation
      const numVal = this.evalNode(ast, angleMode, variables);

      if (!Number.isFinite(numVal)) {
        return {
          status: 'error',
          code: 'MATH_DOMAIN_ERROR',
          message: Number.isNaN(numVal)
            ? 'Result is undefined (e.g. division by zero or 0/0)'
            : 'Result diverges to infinity',
        };
      }

      // Clean format
      const formatted = Number(numVal.toPrecision(precision)).toString();

      let exactStr: string | undefined;
      let exactLaTeX: string | undefined;

      if (exactRat) {
        exactStr = exactRat.toString();
        exactLaTeX = exactRat.toLaTeX();
      } else {
        // Try auto-rationalizing small fractions
        const autoFrac = Rational.fromNumber(numVal, 256n);
        if (autoFrac.den > 1n && Math.abs(autoFrac.toNumber() - numVal) < 1e-9) {
          exactStr = autoFrac.toString();
          exactLaTeX = autoFrac.toLaTeX();
        }
      }

      return {
        status: 'success',
        exact: exactStr,
        exactLaTeX,
        approximation: numVal,
        formatted,
        ast,
      };
    } catch (err: any) {
      return {
        status: 'error',
        code: 'EVAL_ERROR',
        message: err.message || 'Error during mathematical evaluation',
      };
    }
  }

  simplify(input: string | MathNode): MathResult {
    // For rational algebraic simplifications
    return this.evaluate(input);
  }

  /**
   * Attempts exact rational arithmetic evaluation on pure rational AST subtrees
   */
  private tryExactRational(node: MathNode, vars: Record<string, number>): Rational | null {
    switch (node.type) {
      case 'number':
        return Rational.fromNumber(node.value);

      case 'binary': {
        const left = this.tryExactRational(node.left, vars);
        const right = this.tryExactRational(node.right, vars);
        if (!left || !right) return null;

        try {
          if (node.operator === '+') return left.add(right);
          if (node.operator === '-') return left.sub(right);
          if (node.operator === '*') return left.mul(right);
          if (node.operator === '/') return left.div(right);
          if (node.operator === '^' && right.den === 1n && Math.abs(Number(right.num)) <= 16) {
            return left.pow(Number(right.num));
          }
        } catch {
          return null;
        }
        return null;
      }

      case 'unary': {
        const operand = this.tryExactRational(node.operand, vars);
        if (!operand) return null;
        if (node.operator === '-') return new Rational(-operand.num, operand.den);
        return operand;
      }

      default:
        return null;
    }
  }

  /**
   * Numerical evaluation of AST
   */
  private evalNode(node: MathNode, angleMode: AngleMode, vars: Record<string, number>): number {
    switch (node.type) {
      case 'number':
        return node.value;

      case 'constant':
        return node.value;

      case 'variable': {
        if (node.name in vars) return vars[node.name];
        throw new Error(`Undefined variable '${node.name}'`);
      }

      case 'unary': {
        const v = this.evalNode(node.operand, angleMode, vars);
        return node.operator === '-' ? -v : v;
      }

      case 'binary': {
        const l = this.evalNode(node.left, angleMode, vars);
        const r = this.evalNode(node.right, angleMode, vars);

        switch (node.operator) {
          case '+':
            return l + r;
          case '-':
            return l - r;
          case '*':
            return l * r;
          case '/':
            if (Math.abs(r) < 1e-15) throw new Error('DivisionByZero: Cannot divide by zero');
            return l / r;
          case '^':
            if (l < 0 && !Number.isInteger(r)) {
              throw new Error('ComplexResult: Negative base with non-integer exponent');
            }
            return Math.pow(l, r);
          case '%':
            return l % r;
        }
      }

      case 'factorial': {
        const v = this.evalNode(node.operand, angleMode, vars);
        return factorial(v);
      }

      case 'function': {
        const evaluatedArgs = node.args.map((a) => this.evalNode(a, angleMode, vars));
        const [a, b] = evaluatedArgs;

        // Trigonometric helper
        const toRad = (angle: number) => (angleMode === 'degrees' ? (angle * Math.PI) / 180 : angle);
        const fromRad = (rad: number) => (angleMode === 'degrees' ? (rad * 180) / Math.PI : rad);

        switch (node.name) {
          case 'sin':
            return Math.sin(toRad(a));
          case 'cos':
            return Math.cos(toRad(a));
          case 'tan': {
            const rad = toRad(a);
            if (Math.abs(Math.cos(rad)) < 1e-12) {
              throw new Error('Tangent undefined at odd multiples of π/2');
            }
            return Math.tan(rad);
          }
          case 'asin':
            if (a < -1 || a > 1) throw new Error('DomainError: asin argument must be in [-1, 1]');
            return fromRad(Math.asin(a));
          case 'acos':
            if (a < -1 || a > 1) throw new Error('DomainError: acos argument must be in [-1, 1]');
            return fromRad(Math.acos(a));
          case 'atan':
            return fromRad(Math.atan(a));
          case 'sinh':
            return Math.sinh(a);
          case 'cosh':
            return Math.cosh(a);
          case 'tanh':
            return Math.tanh(a);
          case 'sqrt':
            if (a < 0) throw new Error('DomainError: Cannot take square root of negative number');
            return Math.sqrt(a);
          case 'cbrt':
            return Math.cbrt(a);
          case 'ln':
            if (a <= 0) throw new Error('DomainError: Natural logarithm ln requires positive argument');
            return Math.log(a);
          case 'log':
          case 'log10':
            if (a <= 0) throw new Error('DomainError: Logarithm requires positive argument');
            return Math.log10(a);
          case 'log2':
            if (a <= 0) throw new Error('DomainError: Logarithm base 2 requires positive argument');
            return Math.log2(a);
          case 'exp':
            return Math.exp(a);
          case 'abs':
            return Math.abs(a);
          case 'floor':
            return Math.floor(a);
          case 'ceil':
            return Math.ceil(a);
          case 'round':
            return Math.round(a);
          case 'fact':
            return factorial(a);
          case 'ncr':
            return combinations(a, b);
          case 'npr':
            return permutations(a, b);
          default:
            throw new Error(`Unknown mathematical function '${node.name}'`);
        }
      }

      default:
        throw new Error('Unsupported AST node');
    }
  }
}

export const mathEngine = new DefaultMathEngine();
