/**
 * TIFspace Notebook Document Export Utilities
 * Exports structured mathematical notebooks to Markdown, LaTeX, and JSON.
 */

import type {
  MathDocument,
  HeadingContent,
  SectionContent,
  ParagraphContent,
  MathBlockContent,
  CalculationContent,
  ProofContent,
  DerivationContent,
  DefinitionContent,
  ResultContent,
  EmbeddedGraphContent,
  TableContent,
  CalloutContent,
} from './types';

export function exportToMarkdown(doc: MathDocument): string {
  let md = `# ${doc.title}\n\n`;
  if (doc.subject) {
    md += `*Subject: ${doc.subject}*\n\n`;
  }

  for (const b of doc.blocks) {
    const c = b.content as any;
    switch (b.type) {
      case 'heading': {
        const h = c as HeadingContent;
        const hashes = '#'.repeat(h.level || 2);
        md += `${hashes} ${h.text}\n\n`;
        break;
      }
      case 'section': {
        const s = c as SectionContent;
        md += `## 📁 ${s.title}\n`;
        if (s.description) md += `*${s.description}*\n`;
        md += '\n';
        break;
      }
      case 'paragraph': {
        const p = c as ParagraphContent;
        md += `${p.text}\n\n`;
        break;
      }
      case 'math': {
        const m = c as MathBlockContent;
        if (m.name) md += `**${m.name}:**\n`;
        md += `$$\n${m.latex}\n$$\n`;
        if (m.description) md += `*Domain: ${m.description}*\n`;
        md += '\n';
        break;
      }
      case 'calculation': {
        const calc = c as CalculationContent;
        md += `> **Calculation:** \`${calc.expression}\` = **${calc.exactResult || calc.formattedResult || ''}**\n\n`;
        break;
      }
      case 'proof': {
        const pr = c as ProofContent;
        md += `### 🛡️ Proof: ${pr.theorem || 'Proposition'}\n\n`;
        pr.steps.forEach((s, i) => {
          md += `${i + 1}. $${s.expr}$ — *${s.reason || 'Deduction'}*\n`;
        });
        if (pr.conclusion) md += `\n**${pr.conclusion}**\n`;
        md += '\n';
        break;
      }
      case 'derivation': {
        const d = c as DerivationContent;
        md += `### 🌿 ${d.title || 'Derivation'}\n\n`;
        d.steps.forEach((s, i) => {
          md += `${i + 1}. $${s.expr}$ — *${s.reason || 'Step'}*\n`;
        });
        md += '\n';
        break;
      }
      case 'definition': {
        const def = c as DefinitionContent;
        md += `> **Definition (${def.term}):** $${def.notation || ''}$\n>\n> ${def.statement}\n`;
        if (def.domainConstraint) md += `>\n> *Constraint: ${def.domainConstraint}*\n`;
        md += '\n';
        break;
      }
      case 'result': {
        const res = c as ResultContent;
        md += `### 🏆 Result: ${res.title || 'Outcome'} [${res.status || 'exact'}]\n`;
        md += `${res.statement}\n\n`;
        if (res.latex) md += `$$\n${res.latex}\n$$\n\n`;
        break;
      }
      case 'graph': {
        const g = c as EmbeddedGraphContent;
        md += `> **Interactive Graph:** $y = ${g.expression}$\n\n`;
        break;
      }
      case 'table': {
        const t = c as TableContent;
        md += `### 📊 ${t.caption || 'Coordinate Table'}\n\n| X | Y |\n|---|---|\n`;
        t.rows.forEach((r) => {
          md += `| ${r.x} | ${r.y} |\n`;
        });
        if (t.regressionEquation) {
          md += `\n*Regression Model: $${t.regressionEquation}$ (R² = ${t.r2 || 1})*\n`;
        }
        md += '\n';
        break;
      }
      case 'callout': {
        const call = c as CalloutContent;
        md += `> **${call.title || call.kind.toUpperCase()}:** ${call.text}\n\n`;
        break;
      }
      case 'divider': {
        md += `---\n\n`;
        break;
      }
    }
  }

  return md;
}

export function exportToLaTeX(doc: MathDocument): string {
  let tex = `\\documentclass{article}\n\\usepackage{amsmath, amssymb, amsthm}\n\\title{${doc.title}}\n\\author{TIFspace Mathematics}\n\\date{\\today}\n\\begin{document}\n\\maketitle\n\n`;

  for (const b of doc.blocks) {
    const c = b.content as any;
    switch (b.type) {
      case 'heading': {
        const h = c as HeadingContent;
        if (h.level === 1) tex += `\\section{${h.text}}\n\n`;
        else if (h.level === 2) tex += `\\subsection{${h.text}}\n\n`;
        else tex += `\\subsubsection{${h.text}}\n\n`;
        break;
      }
      case 'section': {
        const s = c as SectionContent;
        tex += `\\section{${s.title}}\n${s.description ? `% ${s.description}\n` : ''}\n`;
        break;
      }
      case 'paragraph': {
        const p = c as ParagraphContent;
        tex += `${p.text}\n\n`;
        break;
      }
      case 'math': {
        const m = c as MathBlockContent;
        tex += `\\begin{equation}\n${m.latex}\n\\end{equation}\n\n`;
        break;
      }
      case 'calculation': {
        const calc = c as CalculationContent;
        tex += `% Calculation: ${calc.expression}\n\\[ ${calc.exactResult || calc.formattedResult} \\]\n\n`;
        break;
      }
      case 'proof': {
        const pr = c as ProofContent;
        tex += `\\begin{proof}[${pr.theorem || 'Proposition'}]\n`;
        pr.steps.forEach((s) => {
          tex += `\\[ ${s.expr} \\] \\quad \\text{(${s.reason || 'step'})}\n`;
        });
        tex += `\\end{proof}\n\n`;
        break;
      }
      case 'definition': {
        const def = c as DefinitionContent;
        tex += `\\begin{definition}[${def.term}]\n${def.statement}\n\\[ ${def.notation || ''} \\]\n\\end{definition}\n\n`;
        break;
      }
      case 'result': {
        const res = c as ResultContent;
        tex += `\\paragraph{${res.title || 'Result'}:} ${res.statement}\n\\[ ${res.latex || ''} \\]\n\n`;
        break;
      }
      case 'table': {
        const t = c as TableContent;
        tex += `\\begin{table}[h]\n\\centering\n\\begin{tabular}{c c}\n\\hline\n$X$ & $Y$ \\\\\n\\hline\n`;
        t.rows.forEach((r) => {
          tex += `${r.x} & ${r.y} \\\\\n`;
        });
        tex += `\\hline\n\\end{tabular}\n\\caption{${t.caption || 'Dataset'}}\n\\end{table}\n\n`;
        break;
      }
    }
  }

  tex += `\\end{document}\n`;
  return tex;
}

