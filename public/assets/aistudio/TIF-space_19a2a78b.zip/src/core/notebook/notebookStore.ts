/**
 * Notebook Storage & Document State Management
 * Blueprint Section 4.1 & 6.3: Local-first persistence.
 */

import type { MathDocument, MathBlock, BlockType } from './types';

const STORAGE_KEY = 'tifspace_notebook_documents_v1';

export const INITIAL_NOTEBOOKS: MathDocument[] = [
  {
    id: 'nb-calculus-1',
    title: 'Calculus I: Tangent Lines & Definite Integrals',
    schemaVersion: 1,
    subject: 'Calculus',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Calculus', 'Integrals', 'Derivatives', 'Quadratic'],
    blocks: [
      {
        id: 'b-1',
        type: 'heading',
        position: 0,
        content: {
          level: 1,
          text: 'Calculus I: Parabola Analysis & Fundamental Theorem',
        },
      },
      {
        id: 'b-2',
        type: 'callout',
        position: 1,
        content: {
          kind: 'theorem',
          title: 'The Fundamental Theorem of Calculus',
          text: 'If f is continuous on [a, b] and F is an antiderivative of f on [a, b], then \\int_{a}^{b} f(x)\\,dx = F(b) - F(a).',
        },
      },
      {
        id: 'b-3',
        type: 'paragraph',
        position: 2,
        content: {
          text: 'Consider the quadratic function f(x) = x^2 - 4. We analyze its instantaneous rate of change and the net signed area bounded between x = 0 and x = 2.',
        },
      },
      {
        id: 'b-4',
        type: 'math',
        position: 3,
        relationships: [
          { targetBlockId: 'b-5', type: 'visualizedBy', label: 'Interactive Graph' },
          { targetBlockId: 'b-7', type: 'derivedFrom', label: 'Analytical Integral' },
        ],
        metadata: {
          label: 'Primary Quadratic Curve',
          category: 'Explicit Function',
        },
        content: {
          name: 'f(x)',
          latex: 'f(x) = x^2 - 4',
          showEvaluation: true,
          description: 'Standard second-degree parabola with roots at x = ±2',
        },
      },
      {
        id: 'b-5',
        type: 'graph',
        position: 4,
        relationships: [
          { targetBlockId: 'b-4', type: 'references', label: 'Plots Equation f(x)' },
        ],
        metadata: {
          label: 'Dynamic Parabolic Plot',
        },
        content: {
          expression: 'x^2 - 4',
          sourceBlockId: 'b-4',
          derivativeVisible: true,
          integralVisible: true,
          integralBounds: { a: 0, b: 2 },
          viewport: { xMin: -6, xMax: 6, yMin: -6, yMax: 6 },
        },
      },
      {
        id: 'b-6',
        type: 'heading',
        position: 5,
        content: {
          level: 2,
          text: 'Step-by-Step Analytical Derivation',
        },
      },
      {
        id: 'b-7',
        type: 'derivation',
        position: 6,
        relationships: [
          { targetBlockId: 'b-4', type: 'references', label: 'Evaluates f(x)' },
        ],
        metadata: {
          label: 'Riemann Quadrature Proof',
        },
        content: {
          title: 'Definite Integral Evaluation over [0, 2]',
          steps: [
            { id: 's1', expr: '\\int_{0}^{2} (x^2 - 4)\\,dx', reason: 'Setup integral with lower bound a=0 and upper bound b=2' },
            { id: 's2', expr: '\\left[ \\frac{x^3}{3} - 4x \\right]_{0}^{2}', reason: 'Apply power rule for antiderivative F(x) = x³/3 - 4x' },
            { id: 's3', expr: '\\left( \\frac{2^3}{3} - 4(2) \\right) - \\left( 0 - 0 \\right)', reason: 'Evaluate limits: F(2) - F(0)' },
            { id: 's4', expr: '\\frac{8}{3} - 8 = \\frac{8}{3} - \\frac{24}{3} = -\\frac{16}{3} \\approx -5.333', reason: 'Exact rational arithmetic reduction' },
          ],
        },
      },
      {
        id: 'b-8',
        type: 'divider',
        position: 7,
        content: { style: 'solid' },
      },
      {
        id: 'b-9',
        type: 'table',
        position: 8,
        relationships: [
          { targetBlockId: 'b-4', type: 'references', label: 'Discrete samples of f(x)' },
        ],
        metadata: {
          label: 'Coordinate Table',
        },
        content: {
          caption: 'Discrete Coordinate Samples along f(x)',
          model: 'quadratic',
          rows: [
            { x: '-2', y: '0' },
            { x: '-1', y: '-3' },
            { x: '0', y: '-4' },
            { x: '1', y: '-3' },
            { x: '2', y: '0' },
          ],
        },
      },
    ],
  },
  {
    id: 'nb-linear-algebra',
    title: 'Linear Algebra: Orthogonal Projections',
    schemaVersion: 1,
    subject: 'Linear Algebra',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['LinearAlgebra', 'Vectors', 'Projections'],
    blocks: [
      {
        id: 'la-1',
        type: 'heading',
        position: 0,
        content: {
          level: 1,
          text: 'Vector Orthogonal Projections & Gram-Schmidt',
        },
      },
      {
        id: 'la-2',
        type: 'callout',
        position: 1,
        content: {
          kind: 'definition',
          title: 'Orthogonal Projection Formula',
          text: '\\text{proj}_{\\mathbf{u}}(\\mathbf{v}) = \\frac{\\mathbf{u} \\cdot \\mathbf{v}}{\\|\\mathbf{u}\\|^2} \\mathbf{u}',
        },
      },
      {
        id: 'la-3',
        type: 'paragraph',
        position: 2,
        content: {
          text: 'The projection of vector v onto vector u decomposes v into parallel and perpendicular components v = v_parallel + v_perp.',
        },
      },
    ],
  },
  {
    id: 'nb-statistics',
    title: 'Statistics & Ordinary Least Squares Regression',
    schemaVersion: 1,
    subject: 'Statistics',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: ['Statistics', 'Regression', 'Data'],
    blocks: [
      {
        id: 'st-1',
        type: 'heading',
        position: 0,
        content: {
          level: 1,
          text: 'Ordinary Least Squares & Coefficient of Determination (R²)',
        },
      },
      {
        id: 'st-2',
        type: 'paragraph',
        position: 1,
        content: {
          text: 'Given n data points (x_i, y_i), linear regression estimates the line y = mx + b that minimizes the sum of squared vertical residuals.',
        },
      },
      {
        id: 'st-3',
        type: 'math',
        position: 2,
        content: {
          latex: 'R^2 = 1 - \\frac{\\sum (y_i - \\hat{y}_i)^2}{\\sum (y_i - \\bar{y})^2}',
          showEvaluation: false,
        },
      },
    ],
  },
];

export function getDocuments(): MathDocument[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {}

  // Fallback to initial seeds
  saveAllDocuments(INITIAL_NOTEBOOKS);
  return INITIAL_NOTEBOOKS;
}

export function getDocument(id: string): MathDocument | null {
  const docs = getDocuments();
  return docs.find((d) => d.id === id) || null;
}

export function saveDocument(doc: MathDocument): void {
  const docs = getDocuments();
  const idx = docs.findIndex((d) => d.id === doc.id);
  const updatedDoc = { ...doc, updatedAt: new Date().toISOString() };

  let nextDocs: MathDocument[];
  if (idx >= 0) {
    nextDocs = [...docs.slice(0, idx), updatedDoc, ...docs.slice(idx + 1)];
  } else {
    nextDocs = [updatedDoc, ...docs];
  }
  saveAllDocuments(nextDocs);
}

export function createDocument(title = 'Untitled Notebook', subject = 'Mathematics'): MathDocument {
  const newDoc: MathDocument = {
    id: `nb-${Date.now()}`,
    title,
    schemaVersion: 1,
    subject,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    tags: [subject],
    blocks: [
      {
        id: `b-${Date.now()}-1`,
        type: 'heading',
        position: 0,
        content: { level: 1, text: title },
      },
      {
        id: `b-${Date.now()}-2`,
        type: 'paragraph',
        position: 1,
        content: { text: 'Type notes, click + to add mathematical blocks, or insert live graphs...' },
      },
    ],
  };

  const docs = getDocuments();
  saveAllDocuments([newDoc, ...docs]);
  return newDoc;
}

export function deleteDocument(id: string): void {
  const docs = getDocuments();
  const nextDocs = docs.filter((d) => d.id !== id);
  saveAllDocuments(nextDocs);
}

export function duplicateDocument(id: string): MathDocument | null {
  const doc = getDocument(id);
  if (!doc) return null;

  const duplicated: MathDocument = {
    ...doc,
    id: `nb-${Date.now()}`,
    title: `${doc.title} (Copy)`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    blocks: doc.blocks.map((b, i) => ({
      ...b,
      id: `b-${Date.now()}-${i}`,
    })),
  };

  const docs = getDocuments();
  saveAllDocuments([duplicated, ...docs]);
  return duplicated;
}

function saveAllDocuments(docs: MathDocument[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
  } catch {}
}

export function createBlock(type: BlockType, position: number): MathBlock {
  const id = `b-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

  switch (type) {
    case 'heading':
      return { id, type, position, content: { level: 2, text: 'New Section' } };
    case 'section':
      return {
        id,
        type,
        position,
        content: {
          title: 'Section Topic',
          description: 'Structured mathematical derivations & analysis',
          isCollapsed: false,
        },
      };
    case 'paragraph':
      return { id, type, position, content: { text: 'Write mathematical explanations or proofs here...' } };
    case 'math':
      return {
        id,
        type,
        position,
        metadata: { label: 'Equation' },
        content: { latex: 'f(x) = x^2 - 4', showEvaluation: true },
      };
    case 'calculation':
      return {
        id,
        type,
        position,
        metadata: { label: 'Calculation' },
        content: {
          expression: '1/3 + 1/6',
          exactResult: '1/2',
          formattedResult: '0.5',
          approximation: 0.5,
          angleMode: 'radians',
        },
      };
    case 'proof':
      return {
        id,
        type,
        position,
        metadata: { label: 'Formal Proof' },
        content: {
          theorem: 'Fundamental Algebraic Identity',
          steps: [
            { id: 'ps-1', expr: 'x^2 - y^2 = (x - y)(x + y)', reason: 'Difference of squares factorization', verified: true },
            { id: 'ps-2', expr: '(x - y)(x + y) = x^2 + xy - yx - y^2 = x^2 - y^2', reason: 'Distributive field axiom expansion', verified: true },
          ],
          conclusion: 'Q.E.D. The identity holds universally over any commutative ring.',
        },
      };
    case 'definition':
      return {
        id,
        type,
        position,
        metadata: { label: 'Definition' },
        content: {
          term: 'Continuity at a Point',
          notation: '\\lim_{x \\to c} f(x) = f(c)',
          statement: 'A real-valued function f is continuous at coordinate c if the two-sided limit exists and precisely matches f(c).',
          domainConstraint: 'c \\in \\text{dom}(f)',
        },
      };
    case 'result':
      return {
        id,
        type,
        position,
        metadata: { label: 'Verified Result' },
        content: {
          title: 'Definite Area Outcome',
          statement: 'Net signed Riemann integral over the interval [0, 2]',
          latex: '\\int_{0}^{2} (x^2 - 4)\\,dx = -\\frac{16}{3} \\approx -5.333',
          status: 'exact',
        },
      };
    case 'derivation':
      return {
        id,
        type,
        position,
        metadata: { label: 'Derivation' },
        content: {
          title: 'Mathematical Derivation',
          steps: [
            { id: 's1', expr: 'x^2 - 4 = 0', reason: 'Set function to zero' },
            { id: 's2', expr: '(x - 2)(x + 2) = 0', reason: 'Factor difference of squares' },
            { id: 's3', expr: 'x = \\pm 2', reason: 'Solve for roots' },
          ],
        },
      };
    case 'graph':
      return {
        id,
        type,
        position,
        metadata: { label: 'Interactive Graph' },
        content: {
          expression: 'x^2 - 4',
          derivativeVisible: false,
          integralVisible: false,
          viewport: { xMin: -6, xMax: 6, yMin: -6, yMax: 6 },
        },
      };
    case 'table':
      return {
        id,
        type,
        position,
        metadata: { label: 'Data Table' },
        content: {
          caption: 'Dataset Table',
          model: 'linear',
          rows: [
            { x: '1', y: '2' },
            { x: '2', y: '4' },
            { x: '3', y: '6' },
          ],
        },
      };
    case 'callout':
      return {
        id,
        type,
        position,
        content: { kind: 'note', title: 'Note', text: 'Important mathematical property to remember.' },
      };
    case 'divider':
      return { id, type, position, content: { style: 'solid' } };
  }
}

export function appendMathBlockToActive(latex: string): MathDocument {
  const docs = getDocuments();
  const targetDoc = docs[0] || createDocument('Calculation Notes');
  const newBlock: MathBlock = {
    id: `b-${Date.now()}`,
    type: 'math',
    position: targetDoc.blocks.length,
    metadata: { label: 'Equation' },
    content: { latex, showEvaluation: true },
  };
  const updatedDoc: MathDocument = {
    ...targetDoc,
    blocks: [...targetDoc.blocks, newBlock],
    updatedAt: new Date().toISOString(),
  };
  saveDocument(updatedDoc);
  return updatedDoc;
}
