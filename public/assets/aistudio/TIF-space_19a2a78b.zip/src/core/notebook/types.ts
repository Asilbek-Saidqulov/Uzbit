/**
 * TIFspace Structured Mathematical Notebook Schema
 * Blueprint Section 4.1: Structured mathematical entity model.
 */

export type BlockType =
  | 'heading'
  | 'paragraph'
  | 'math'
  | 'derivation'
  | 'graph'
  | 'table'
  | 'callout'
  | 'divider'
  | 'calculation'
  | 'proof'
  | 'definition'
  | 'result'
  | 'section';

export interface BaseBlockContent {
  [key: string]: unknown;
}

export type RelationshipType =
  | 'references'
  | 'derivedFrom'
  | 'visualizedBy'
  | 'produces'
  | 'calculates';

export interface BlockRelationship {
  targetBlockId: string;
  type: RelationshipType;
  label?: string;
}

export interface BlockMetadata {
  label?: string;
  category?: string;
  tags?: string[];
  isCollapsed?: boolean;
  color?: string;
}

export interface HeadingContent extends BaseBlockContent {
  level: 1 | 2 | 3;
  text: string;
}

export interface SectionContent extends BaseBlockContent {
  title: string;
  description?: string;
  isCollapsed?: boolean;
  icon?: string;
}

export interface ParagraphContent extends BaseBlockContent {
  text: string;
}

export interface MathBlockContent extends BaseBlockContent {
  latex: string;
  showEvaluation?: boolean;
  variable?: string;
  name?: string;
  description?: string;
}

export interface DerivationStep {
  id: string;
  expr: string;
  reason?: string;
}

export interface DerivationContent extends BaseBlockContent {
  title?: string;
  steps: DerivationStep[];
}

export interface ProofStep {
  id: string;
  expr: string;
  reason?: string;
  verified?: boolean;
}

export interface ProofContent extends BaseBlockContent {
  theorem?: string;
  steps: ProofStep[];
  conclusion?: string;
}

export interface CalculationContent extends BaseBlockContent {
  expression: string;
  exactResult?: string;
  formattedResult?: string;
  approximation?: number;
  angleMode?: 'radians' | 'degrees';
  sourceBlockId?: string;
}

export interface DefinitionContent extends BaseBlockContent {
  term: string;
  notation?: string;
  statement: string;
  domainConstraint?: string;
}

export interface ResultContent extends BaseBlockContent {
  title?: string;
  statement: string;
  latex?: string;
  status?: 'exact' | 'approximate' | 'verified';
}

export interface EmbeddedGraphContent extends BaseBlockContent {
  expression: string;
  derivativeVisible?: boolean;
  integralVisible?: boolean;
  integralBounds?: { a: number; b: number };
  viewport?: { xMin: number; xMax: number; yMin: number; yMax: number };
  sourceBlockId?: string;
}

export interface TableRowData {
  x: string;
  y: string;
}

export interface TableContent extends BaseBlockContent {
  caption?: string;
  rows: TableRowData[];
  model?: 'linear' | 'quadratic' | 'exponential' | 'none';
  regressionEquation?: string;
  r2?: number;
}

export interface CalloutContent extends BaseBlockContent {
  kind: 'definition' | 'theorem' | 'note' | 'warning';
  title?: string;
  text: string;
}

export interface DividerContent extends BaseBlockContent {
  style?: 'solid' | 'dashed';
}

export interface MathBlock {
  id: string;
  type: BlockType;
  position: number;
  sectionId?: string;
  metadata?: BlockMetadata;
  relationships?: BlockRelationship[];
  createdAt?: string;
  updatedAt?: string;
  content:
    | HeadingContent
    | SectionContent
    | ParagraphContent
    | MathBlockContent
    | DerivationContent
    | ProofContent
    | CalculationContent
    | DefinitionContent
    | ResultContent
    | EmbeddedGraphContent
    | TableContent
    | CalloutContent
    | DividerContent;
}

export interface NotebookSection {
  id: string;
  title: string;
  description?: string;
  isCollapsed?: boolean;
  order: number;
}

export interface MathDocument {
  id: string;
  title: string;
  schemaVersion: number;
  sections?: NotebookSection[];
  blocks: MathBlock[];
  createdAt: string;
  updatedAt: string;
  tags?: string[];
  subject?: string;
}
