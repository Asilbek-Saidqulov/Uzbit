export type PrimaryRoute = 'workspace' | 'lab' | 'reference' | 'settings';

export type LegacyRoute =
  | 'home'
  | 'notebooks'
  | 'recent'
  | 'favorites'
  | 'graphing'
  | 'calculator'
  | 'formulas'
  | 'geometry'
  | 'explorer'
  | 'practice';

export type AppRoute = PrimaryRoute | LegacyRoute;

export type LabTab = 'graphing' | 'geometry';
export type ReferenceTab = 'formulas' | 'explorer' | 'practice';
export type WorkspaceTab = 'notebooks' | 'calculator';

export interface RoutePayload {
  expression?: string;
  notebookId?: string;
  filter?: string;
  tab?: LabTab | ReferenceTab | WorkspaceTab;
}

export interface NavItem {
  id: PrimaryRoute;
  label: string;
  badge?: string;
  icon: string;
  description?: string;
}

export interface NotebookMeta {
  id: string;
  title: string;
  updatedAt: string;
  tags: string[];
  snippet?: string;
}
