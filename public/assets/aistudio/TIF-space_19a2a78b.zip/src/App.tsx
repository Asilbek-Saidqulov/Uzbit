'use client';

import { useState, useEffect } from 'react';
import type { AppRoute, LabTab, ReferenceTab, RoutePayload } from '@/types/navigation';
import { useTheme } from '@/lib/useTheme';
import AppSidebar from '@/components/navigation/AppSidebar';
import GlobalHeader from '@/components/navigation/GlobalHeader';
import CommandPalette from '@/components/navigation/CommandPalette';
import ShortcutsModal from '@/components/navigation/ShortcutsModal';
import QuickCalculatorDrawer from '@/components/calculator/QuickCalculatorDrawer';
import MobileTabBar from '@/components/navigation/MobileTabBar';

import WorkspaceHub from '@/modules/workspace/WorkspaceHub';
import VisualLabView from '@/modules/lab/VisualLabView';
import ReferenceHub from '@/modules/reference/ReferenceHub';
import SettingsView from '@/modules/settings/SettingsView';

export default function App() {
  const { theme, toggleTheme } = useTheme();

  // Resolve initial route from URL hash or localStorage
  const [currentRoute, setCurrentRoute] = useState<AppRoute>(() => {
    try {
      const hash = window.location.hash;
      if (hash.startsWith('#route=')) {
        const raw = hash.replace('#route=', '').split('&')[0] as AppRoute;
        return raw;
      }
      const saved = localStorage.getItem('tifspace_active_route');
      if (saved) return saved as AppRoute;
    } catch {}
    return 'workspace';
  });

  const [routePayload, setRoutePayload] = useState<RoutePayload | null>(() => {
    try {
      const hash = window.location.hash;
      if (hash.includes('expr=')) {
        const match = hash.match(/expr=([^&]+)/);
        if (match) return { expression: decodeURIComponent(match[1]) };
      }
    } catch {}
    return null;
  });

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [quickCalcOpen, setQuickCalcOpen] = useState(false);

  // Global Keyboard Shortcuts Listener (? and ⌘/)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        (e.key === '?' || (e.key === '/' && (e.metaKey || e.ctrlKey))) &&
        !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement)
      ) {
        e.preventDefault();
        setShortcutsOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleNavigate = (route: AppRoute, payload?: RoutePayload) => {
    // If user navigates to calculator, open quick calculator drawer directly
    if (route === 'calculator') {
      setQuickCalcOpen(true);
      return;
    }

    setCurrentRoute(route);
    setRoutePayload(payload || null);
    try {
      localStorage.setItem('tifspace_active_route', route);
      window.location.hash = payload?.expression
        ? `#route=${route}&expr=${encodeURIComponent(payload.expression)}`
        : `#route=${route}`;
    } catch {}
  };

  // Determine subtab states
  const labSubTab: LabTab = currentRoute === 'geometry' ? 'geometry' : 'graphing';
  const refSubTab: ReferenceTab =
    currentRoute === 'explorer'
      ? 'explorer'
      : currentRoute === 'practice'
      ? 'practice'
      : 'formulas';

  const isLab = currentRoute === 'lab' || currentRoute === 'graphing' || currentRoute === 'geometry';
  const isReference =
    currentRoute === 'reference' ||
    currentRoute === 'formulas' ||
    currentRoute === 'explorer' ||
    currentRoute === 'practice';
  const isSettings = currentRoute === 'settings';
  const isWorkspace = !isLab && !isReference && !isSettings;

  return (
    <div className="flex h-dvh w-full overflow-hidden bg-canvas text-ink">
      {/* Global Shallow Sidebar */}
      <AppSidebar
        currentRoute={currentRoute}
        onNavigate={handleNavigate}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        onOpenQuickCalc={() => setQuickCalcOpen(true)}
        onOpenShortcuts={() => setShortcutsOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden pb-14 md:pb-0">
        {/* Shallow Header */}
        <GlobalHeader
          currentRoute={currentRoute}
          onNavigate={handleNavigate}
          theme={theme}
          onToggleTheme={toggleTheme}
          onOpenSearch={() => setSearchOpen(true)}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onOpenQuickCalc={() => setQuickCalcOpen(true)}
        />

        {/* View Router */}
        <main className="relative flex min-h-0 flex-1 flex-col overflow-hidden bg-canvas">
          {isWorkspace && (
            <WorkspaceHub
              onNavigate={handleNavigate}
              onOpenQuickCalc={() => setQuickCalcOpen(true)}
            />
          )}

          {isLab && (
            <VisualLabView
              theme={theme}
              onToggleTheme={toggleTheme}
              initialTab={labSubTab}
              initialExpression={routePayload?.expression}
              onNavigate={handleNavigate}
            />
          )}

          {isReference && (
            <ReferenceHub
              initialTab={refSubTab}
              onNavigate={handleNavigate}
            />
          )}

          {isSettings && (
            <SettingsView theme={theme} onToggleTheme={toggleTheme} />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <MobileTabBar
        currentRoute={currentRoute}
        onNavigate={handleNavigate}
        onOpenQuickCalc={() => setQuickCalcOpen(true)}
      />

      {/* Quick Mathematical Calculator Drawer */}
      <QuickCalculatorDrawer
        isOpen={quickCalcOpen}
        onClose={() => setQuickCalcOpen(false)}
        onNavigate={handleNavigate}
      />

      {/* Command Palette (⌘K) Modal */}
      <CommandPalette
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onNavigate={handleNavigate}
      />

      {/* Mathematical Keyboard Shortcuts (?) Modal */}
      <ShortcutsModal
        isOpen={shortcutsOpen}
        onClose={() => setShortcutsOpen(false)}
      />
    </div>
  );
}
