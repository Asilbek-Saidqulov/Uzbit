'use client';

import { useEffect } from 'react';
import { Keyboard, X, Sparkles, Command, Sliders, LineChart, BookOpen } from 'lucide-react';
import MathView from '@/components/MathView';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ShortcutItem {
  keys: string[];
  label: string;
  math?: string;
}

interface ShortcutSection {
  title: string;
  icon: any;
  items: ShortcutItem[];
}

export default function ShortcutsModal({ isOpen, onClose }: ShortcutsModalProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const SHORTCUT_SECTIONS: ShortcutSection[] = [
    {
      title: 'Navigation & Platform',
      icon: Command,
      items: [
        { keys: ['⌘', 'K'], label: 'Open Command Palette' },
        { keys: ['?'], label: 'Open Keyboard Shortcuts' },
        { keys: ['Esc'], label: 'Close Modals & Clear Focus' },
      ],
    },
    {
      title: 'Mathematical Notation & Operators',
      icon: Sparkles,
      items: [
        { keys: ['/'], label: 'Stacked Fraction', math: '\\frac{a}{b}' },
        { keys: ['^'], label: 'Superscript Power', math: 'x^n' },
        { keys: ['sqrt(...)'], label: 'Square Root Radical', math: '\\sqrt{x}' },
        { keys: ['pi', 'π'], label: 'Circle Archimedes Constant', math: '\\pi \\approx 3.14159' },
        { keys: ['e'], label: 'Euler Exponential Base', math: 'e \\approx 2.71828' },
        { keys: ['phi', 'φ'], label: 'Golden Ratio', math: '\\phi \\approx 1.61803' },
        { keys: ['!'], label: 'Factorial', math: 'n!' },
      ],
    },
    {
      title: 'Calculus & Functions',
      icon: LineChart,
      items: [
        { keys: ['f(x) = ...'], label: 'Define Named Function', math: 'f(x) = x^2 - 4' },
        { keys: ['f\'(x)'], label: 'First Derivative Tangent Curve', math: 'f\'(x) = 2x' },
        { keys: ['∫ [a, b]'], label: 'Definite Riemann Area', math: '\\int_a^b f(x)\\,dx' },
        { keys: ['nCr(n, r)'], label: 'Combinations', math: '\\binom{n}{r}' },
      ],
    },
    {
      title: 'Interactive Canvas Navigation',
      icon: Sliders,
      items: [
        { keys: ['Scroll Wheel'], label: 'Continuous Zoom In / Out' },
        { keys: ['Click & Drag'], label: 'Pan Canvas Viewport' },
        { keys: ['Hover Point'], label: 'Inspect Exact POI (Roots, Extrema)' },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-2xl rounded-2xl border border-line bg-panel p-6 shadow-2xl z-10 overflow-hidden max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-line">
          <div className="flex items-center gap-2.5">
            <div className="grid h-8 w-8 place-items-center rounded-xl border border-line bg-field text-accent">
              <Keyboard className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-ink">Mathematical Keyboard Shortcuts</h2>
              <p className="text-xs text-muted">Complete guide to mathematical syntax and quick navigation</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-lg border border-line text-muted hover:text-ink hover:bg-field"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto space-y-6 py-4">
          {SHORTCUT_SECTIONS.map((sec, i) => {
            const Icon = sec.icon;
            return (
              <div key={i} className="space-y-2.5">
                <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-accent">
                  <Icon className="h-3.5 w-3.5" />
                  <span>{sec.title}</span>
                </div>

                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {sec.items.map((item, j) => (
                    <div
                      key={j}
                      className="flex items-center justify-between rounded-xl border border-line/60 bg-field/40 px-3 py-2 text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="font-medium text-ink">{item.label}</div>
                        {item.math && (
                          <div className="text-[11px] text-accent font-serif">
                            <MathView math={item.math} />
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        {item.keys.map((k, ki) => (
                          <kbd
                            key={ki}
                            className="rounded border border-line bg-panel px-1.5 py-0.5 font-mono text-[10px] font-semibold text-ink shadow-xs"
                          >
                            {k}
                          </kbd>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="border-t border-line/60 pt-3 flex items-center justify-between text-xs text-muted">
          <span>Press <kbd className="rounded border border-line px-1 py-0.5 text-[10px]">?</kbd> anywhere to open this modal</span>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg bg-accent px-4 py-1.5 text-xs font-bold text-accent-ink shadow-sm hover:opacity-90"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
