'use client';

import type { AppRoute, PrimaryRoute } from '@/types/navigation';
import { BookOpen, LineChart, Library, Calculator } from 'lucide-react';

interface MobileTabBarProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
  onOpenQuickCalc: () => void;
}

export default function MobileTabBar({
  currentRoute,
  onNavigate,
  onOpenQuickCalc,
}: MobileTabBarProps) {
  const activeHub: PrimaryRoute =
    currentRoute === 'lab' || currentRoute === 'graphing' || currentRoute === 'geometry'
      ? 'lab'
      : currentRoute === 'reference' ||
        currentRoute === 'formulas' ||
        currentRoute === 'explorer' ||
        currentRoute === 'practice'
      ? 'reference'
      : currentRoute === 'settings'
      ? 'settings'
      : 'workspace';

  return (
    <nav
      aria-label="Mobile Navigation"
      className="fixed bottom-0 inset-x-0 z-40 flex h-14 items-center justify-around border-t border-line bg-panel/95 backdrop-blur-md px-2 py-1 md:hidden select-none"
    >
      <button
        type="button"
        onClick={() => onNavigate('workspace')}
        className={`flex flex-col items-center justify-center gap-0.5 rounded-lg py-1 px-3 transition-colors ${
          activeHub === 'workspace' ? 'text-accent font-bold' : 'text-muted hover:text-ink'
        }`}
      >
        <BookOpen className="h-4 w-4" />
        <span className="text-[10px] tracking-tight">Workspace</span>
      </button>

      <button
        type="button"
        onClick={() => onNavigate('lab')}
        className={`flex flex-col items-center justify-center gap-0.5 rounded-lg py-1 px-3 transition-colors ${
          activeHub === 'lab' ? 'text-accent font-bold' : 'text-muted hover:text-ink'
        }`}
      >
        <LineChart className="h-4 w-4" />
        <span className="text-[10px] tracking-tight">Visual Lab</span>
      </button>

      <button
        type="button"
        onClick={() => onNavigate('reference')}
        className={`flex flex-col items-center justify-center gap-0.5 rounded-lg py-1 px-3 transition-colors ${
          activeHub === 'reference' ? 'text-accent font-bold' : 'text-muted hover:text-ink'
        }`}
      >
        <Library className="h-4 w-4" />
        <span className="text-[10px] tracking-tight">Reference</span>
      </button>

      <button
        type="button"
        onClick={onOpenQuickCalc}
        className="flex flex-col items-center justify-center gap-0.5 rounded-lg py-1 px-3 text-muted hover:text-ink transition-colors"
      >
        <Calculator className="h-4 w-4 text-accent" />
        <span className="text-[10px] tracking-tight">Calc</span>
      </button>
    </nav>
  );
}

