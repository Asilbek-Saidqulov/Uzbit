'use client';

import type { AppRoute } from '@/types/navigation';
import type { Theme } from '@/lib/theme';
import { Menu, Search, Sun, Moon, Calculator } from 'lucide-react';

interface GlobalHeaderProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
  theme: Theme;
  onToggleTheme: () => void;
  onOpenSearch: () => void;
  onOpenMobileMenu: () => void;
  onOpenQuickCalc?: () => void;
}

const HUB_TITLES: Record<string, { hub: string; name: string }> = {
  workspace: { hub: 'Workspace', name: 'Notebooks & Exploration' },
  home: { hub: 'Workspace', name: 'Notebooks & Exploration' },
  notebooks: { hub: 'Workspace', name: 'Notebooks' },
  calculator: { hub: 'Workspace', name: 'Calculator' },
  lab: { hub: 'Visual Lab', name: 'Curves & Geometry' },
  graphing: { hub: 'Visual Lab', name: 'Graphing Studio' },
  geometry: { hub: 'Visual Lab', name: 'Geometry Sandbox' },
  reference: { hub: 'Reference', name: 'Formulas & Review' },
  formulas: { hub: 'Reference', name: 'Formula Library' },
  explorer: { hub: 'Reference', name: 'Concept Explorer' },
  practice: { hub: 'Reference', name: 'Practice Review' },
  settings: { hub: 'System', name: 'Preferences' },
};

export default function GlobalHeader({
  currentRoute,
  onNavigate,
  theme,
  onToggleTheme,
  onOpenSearch,
  onOpenMobileMenu,
  onOpenQuickCalc,
}: GlobalHeaderProps) {
  const meta = HUB_TITLES[currentRoute] || { hub: 'Workspace', name: 'Mathematical Hub' };

  return (
    <header className="flex h-12 shrink-0 items-center justify-between border-b border-line bg-panel px-3 sm:px-4 select-none">
      {/* Left: Mobile menu button & Shallow Breadcrumb */}
      <div className="flex items-center gap-2 sm:gap-3">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          className="grid h-8 w-8 place-items-center rounded-lg border border-line text-muted transition-colors hover:bg-field hover:text-ink md:hidden focus-ring"
          title="Open Navigation"
          aria-label="Open Navigation"
        >
          <Menu className="h-4 w-4" />
        </button>

        <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs">
          <button
            type="button"
            onClick={() => onNavigate('workspace')}
            className="font-semibold text-muted transition-colors hover:text-ink focus-ring rounded"
          >
            TIFspace
          </button>
          <span className="text-muted/50">/</span>
          <span className="font-medium text-muted hidden sm:inline">{meta.hub}</span>
          <span className="text-muted/50 hidden sm:inline">/</span>
          <span className="font-semibold text-ink">{meta.name}</span>
        </nav>
      </div>

      {/* Right: Quick Search + Quick Calculator Drawer + Theme */}
      <div className="flex items-center gap-2">
        {/* Command Search */}
        <button
          type="button"
          onClick={onOpenSearch}
          className="flex h-8 items-center gap-2 rounded-lg border border-line bg-field/60 px-2.5 text-xs text-muted transition-colors hover:border-accent/40 hover:bg-field hover:text-ink focus-ring"
          title="Search formulas, tools and documents (⌘K)"
        >
          <Search className="h-3.5 w-3.5" />
          <span className="hidden md:inline">Search mathematical workspace</span>
          <kbd className="hidden rounded border border-line bg-panel px-1.5 py-0.2 text-[10px] font-mono sm:inline">
            ⌘K
          </kbd>
        </button>

        {/* Quick Calculator Action Button */}
        {onOpenQuickCalc && (
          <button
            type="button"
            onClick={onOpenQuickCalc}
            title="Open Quick Calculator"
            className="flex h-8 items-center gap-1.5 rounded-lg border border-line/80 bg-field/60 px-2.5 text-xs font-medium text-ink transition-colors hover:border-accent/40 hover:bg-field focus-ring"
          >
            <Calculator className="h-3.5 w-3.5 text-accent" />
            <span className="hidden sm:inline">Calc</span>
          </button>
        )}

        {/* Theme Toggle */}
        <button
          type="button"
          onClick={onToggleTheme}
          title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
          aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
          className="grid h-8 w-8 place-items-center rounded-lg border border-transparent text-muted transition-colors hover:border-line hover:bg-field hover:text-ink focus-ring"
        >
          {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>
      </div>
    </header>
  );
}
