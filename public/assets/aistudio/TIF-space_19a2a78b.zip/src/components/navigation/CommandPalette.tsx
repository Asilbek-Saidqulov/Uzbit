'use client';

import { useEffect, useState } from 'react';
import type { AppRoute } from '@/types/navigation';
import {
  Search,
  LineChart,
  Calculator,
  Library,
  BookOpen,
  Shapes,
  Compass,
  GraduationCap,
  Settings,
  X,
  ArrowRight,
} from 'lucide-react';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (route: AppRoute, payload?: { expression?: string }) => void;
}

interface CommandItem {
  id: string;
  route: AppRoute;
  title: string;
  category: string;
  subtitle: string;
  icon: any;
  expression?: string;
}

const COMMANDS: CommandItem[] = [
  {
    id: 'workspace',
    route: 'workspace',
    title: 'Mathematical Workspace',
    category: 'Workspace',
    subtitle: 'Structured mathematical documents, derivation steps & proofs',
    icon: BookOpen,
  },
  {
    id: 'lab-graphing',
    route: 'lab',
    title: 'Graphing Lab',
    category: 'Visual Lab',
    subtitle: 'Graph functions, derivatives, integrals, tangents & regressions',
    icon: LineChart,
  },
  {
    id: 'lab-geometry',
    route: 'geometry',
    title: 'Geometry Sandbox',
    category: 'Visual Lab',
    subtitle: 'Euclidean constructions, angles, triangles, circles & bisectors',
    icon: Shapes,
  },
  {
    id: 'calculator',
    route: 'calculator',
    title: 'Quick Calculator',
    category: 'Computation',
    subtitle: 'Exact rational arithmetic, trigonometry & precision evaluation',
    icon: Calculator,
  },
  {
    id: 'formulas',
    route: 'formulas',
    title: 'Formula Catalog',
    category: 'Reference',
    subtitle: 'Browse algebra, calculus, geometry and physics theorems',
    icon: Library,
  },
  {
    id: 'explorer',
    route: 'explorer',
    title: 'Concept Explorer',
    category: 'Reference',
    subtitle: 'Mathematical intuition, proofs, definitions & dynamic sliders',
    icon: Compass,
  },
  {
    id: 'practice',
    route: 'practice',
    title: 'Practice & Review',
    category: 'Reference',
    subtitle: 'Adaptive problem bank with step-by-step analytical proofs',
    icon: GraduationCap,
  },
  {
    id: 'graph-parabola',
    route: 'lab',
    title: 'Plot: Parabola f(x) = x² − 4',
    category: 'Quick Plot',
    subtitle: 'Quadratic roots at x = ±2 with minimum vertex at (0, -4)',
    icon: LineChart,
    expression: 'f(x) = x^2 - 4',
  },
  {
    id: 'graph-gaussian',
    route: 'lab',
    title: 'Plot: Gaussian Normal Curve',
    category: 'Quick Plot',
    subtitle: 'Standard normal distribution probability density function',
    icon: LineChart,
    expression: 'y = (1 / sqrt(2 * pi)) * e^(-0.5 * x^2)',
  },
  {
    id: 'graph-sin',
    route: 'lab',
    title: 'Plot: Sine Wave y = sin(x)',
    category: 'Quick Plot',
    subtitle: 'Harmonic oscillator periodic waveform',
    icon: LineChart,
    expression: 'y = sin(x)',
  },
  {
    id: 'graph-circle',
    route: 'lab',
    title: 'Plot: Circle x² + y² = 25',
    category: 'Quick Plot',
    subtitle: 'Implicit circular relation with radius 5',
    icon: LineChart,
    expression: 'x^2 + y^2 = 25',
  },
  {
    id: 'settings',
    route: 'settings',
    title: 'Settings & Preferences',
    category: 'System',
    subtitle: 'Trig angle mode, precision, dark/light theme, and backup',
    icon: Settings,
  },
];

export default function CommandPalette({ isOpen, onClose, onNavigate }: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    if (isOpen) {
      setSelectedIndex(0);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      } else if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const filtered = COMMANDS.filter((cmd) => {
    const q = query.toLowerCase().trim();
    if (!q) return true;
    return (
      cmd.title.toLowerCase().includes(q) ||
      cmd.subtitle.toLowerCase().includes(q) ||
      cmd.category.toLowerCase().includes(q) ||
      (cmd.expression && cmd.expression.toLowerCase().includes(q))
    );
  });

  const handleSelect = (item: CommandItem) => {
    onNavigate(item.route, item.expression ? { expression: item.expression } : undefined);
    onClose();
  };

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (filtered.length > 0 ? (prev + 1) % filtered.length : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (filtered.length > 0 ? (prev - 1 + filtered.length) % filtered.length : 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        handleSelect(filtered[selectedIndex]);
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16 sm:pt-24"
    >
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={onClose} />
      <div className="relative flex w-full max-w-xl flex-col overflow-hidden rounded-2xl border border-line bg-panel shadow-2xl animate-modal">
        {/* Search Input Bar */}
        <div className="flex items-center border-b border-line px-4 py-3">
          <Search className="h-4 w-4 text-muted" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleInputKeyDown}
            placeholder="Type a command, tool, equation or formula..."
            className="ml-3 flex-1 bg-transparent text-sm text-ink placeholder-muted focus:outline-none"
          />
          <button
            type="button"
            onClick={onClose}
            className="grid h-6 w-6 place-items-center rounded-md text-muted hover:bg-field hover:text-ink"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-80 overflow-y-auto p-2">
          {filtered.length === 0 ? (
            <div className="p-6 text-center text-xs text-muted">
              No matching commands or tools found for &ldquo;{query}&rdquo;
            </div>
          ) : (
            <div className="space-y-1">
              {filtered.map((item, idx) => {
                const Icon = item.icon;
                const isSelected = idx === selectedIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelect(item)}
                    onMouseEnter={() => setSelectedIndex(idx)}
                    className={`flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left transition-colors ${
                      isSelected ? 'bg-accent/15 text-accent' : 'text-ink hover:bg-field'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`grid h-8 w-8 place-items-center rounded-lg border ${
                          isSelected
                            ? 'border-accent/40 bg-accent text-accent-ink'
                            : 'border-line bg-field text-muted'
                        }`}
                      >
                        <Icon className="h-4 w-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-ink">{item.title}</span>
                          <span className="rounded bg-field px-1.5 py-0.2 text-[10px] text-muted">
                            {item.category}
                          </span>
                        </div>
                        <p className="text-[11px] text-muted">{item.subtitle}</p>
                      </div>
                    </div>
                    <ArrowRight className="h-3.5 w-3.5 text-muted/60" />
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-line bg-field/40 px-4 py-2 text-[11px] text-muted">
          <span>Navigate with <kbd className="rounded border border-line bg-panel px-1 text-[10px]">↑</kbd> <kbd className="rounded border border-line bg-panel px-1 text-[10px]">↓</kbd>, press <kbd className="rounded border border-line bg-panel px-1.5 text-[10px]">Enter</kbd> to select</span>
          <span className="font-mono">ESC to exit</span>
        </div>
      </div>
    </div>
  );
}
