'use client';

import type { AppRoute, PrimaryRoute } from '@/types/navigation';
import {
  BookOpen,
  LineChart,
  Library,
  Settings,
  ChevronLeft,
  ChevronRight,
  Calculator,
  Search,
  HelpCircle,
  X,
} from 'lucide-react';

interface AppSidebarProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onOpenQuickCalc?: () => void;
  onOpenShortcuts?: () => void;
}

export default function AppSidebar({
  currentRoute,
  onNavigate,
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
  onOpenQuickCalc,
  onOpenShortcuts,
}: AppSidebarProps) {
  // Normalize active route to one of the 4 primary hubs
  const activeHub: PrimaryRoute =
    currentRoute === 'lab' || currentRoute === 'graphing' || currentRoute === 'geometry'
      ? 'lab'
      : currentRoute === 'reference' ||
        currentRoute === 'formulas' ||
        currentRoute === 'explorer' ||
        currentRoute === 'practice'
      ? 'reference'
      : currentRoute === 'settings'
      ? 'settings'
      : 'workspace';

  const navItems = [
    {
      id: 'workspace' as PrimaryRoute,
      label: 'Workspace',
      hint: 'Notebooks & proofs',
      icon: BookOpen,
    },
    {
      id: 'lab' as PrimaryRoute,
      label: 'Visual Lab',
      hint: 'Graphing & geometry',
      icon: LineChart,
    },
    {
      id: 'reference' as PrimaryRoute,
      label: 'Reference',
      hint: 'Formulas & review',
      icon: Library,
    },
    {
      id: 'settings' as PrimaryRoute,
      label: 'Settings',
      hint: 'Precision & notation',
      icon: Settings,
    },
  ];

  const sidebarContent = (
    <div className="flex h-full flex-col bg-panel text-ink select-none">
      {/* Brand Header */}
      <div className="flex h-13 shrink-0 items-center justify-between border-b border-line px-3">
        <button
          type="button"
          onClick={() => {
            onNavigate('workspace');
            onCloseMobile();
          }}
          className="flex items-center gap-2.5 text-left transition-opacity hover:opacity-85 focus-ring rounded-lg p-1"
        >
          <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-ink shadow-xs">
            <span className="font-serif font-black text-sm leading-none italic">T</span>
          </div>
          {!collapsed && (
            <div className="flex flex-col">
              <span className="text-xs font-bold tracking-tight text-ink">TIFspace</span>
              <span className="text-[10px] text-muted">Math Workspace</span>
            </div>
          )}
        </button>

        {/* Mobile close button */}
        <button
          type="button"
          onClick={onCloseMobile}
          className="grid h-8 w-8 place-items-center rounded-lg text-muted hover:bg-field md:hidden"
          aria-label="Close navigation"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Desktop collapse toggle */}
        <button
          type="button"
          onClick={onToggleCollapse}
          title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          aria-label={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
          className="hidden h-7 w-7 place-items-center rounded-lg border border-line/60 bg-field/40 text-muted transition-colors hover:border-line hover:text-ink md:grid focus-ring"
        >
          {collapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
        </button>
      </div>

      {/* Primary Navigation Destinations */}
      <nav aria-label="Primary destinations" className="flex-1 space-y-1 p-2">
        {!collapsed && (
          <div className="px-2 pt-1 pb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted/70">
            Navigation
          </div>
        )}
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeHub === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onNavigate(item.id);
                onCloseMobile();
              }}
              title={collapsed ? `${item.label} (${item.hint})` : undefined}
              className={`group flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs font-medium transition-all focus-ring ${
                isActive
                  ? 'bg-accent text-accent-ink font-semibold shadow-xs'
                  : 'text-ink/80 hover:bg-field hover:text-ink'
              }`}
            >
              <Icon
                className={`h-4 w-4 shrink-0 transition-colors ${
                  isActive ? 'text-accent-ink' : 'text-muted group-hover:text-ink'
                }`}
              />
              {!collapsed && (
                <div className="flex flex-col text-left overflow-hidden">
                  <span className="truncate leading-tight">{item.label}</span>
                  <span
                    className={`text-[10px] truncate leading-tight ${
                      isActive ? 'text-accent-ink/75' : 'text-muted'
                    }`}
                  >
                    {item.hint}
                  </span>
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Mathematical Quick Tools */}
      <div className="border-t border-line/70 p-2 space-y-1">
        {!collapsed && (
          <div className="px-2 pt-1 pb-1 text-[10px] font-semibold uppercase tracking-wider text-muted/70">
            Quick Tools
          </div>
        )}

        {/* Instant Calculator Drawer Trigger */}
        <button
          type="button"
          onClick={() => {
            onOpenQuickCalc?.();
            onCloseMobile();
          }}
          title={collapsed ? 'Quick Calculator' : undefined}
          className="group flex w-full items-center gap-2.5 rounded-xl border border-line/60 bg-field/40 px-2.5 py-1.5 text-xs font-medium text-ink/85 transition-all hover:border-accent/40 hover:bg-field hover:text-ink focus-ring"
        >
          <Calculator className="h-4 w-4 shrink-0 text-accent" />
          {!collapsed && (
            <div className="flex flex-1 items-center justify-between">
              <span>Calculator</span>
              <span className="rounded bg-panel px-1 text-[9px] font-mono text-muted">Exact</span>
            </div>
          )}
        </button>

        {/* Shortcuts / Notation Trigger */}
        <button
          type="button"
          onClick={() => {
            onOpenShortcuts?.();
            onCloseMobile();
          }}
          title={collapsed ? 'Keyboard Shortcuts (?)' : undefined}
          className="group flex w-full items-center gap-2.5 rounded-xl px-2.5 py-1.5 text-xs text-muted hover:bg-field hover:text-ink transition-colors focus-ring"
        >
          <HelpCircle className="h-4 w-4 shrink-0" />
          {!collapsed && (
            <div className="flex flex-1 items-center justify-between">
              <span>Math Shortcuts</span>
              <kbd className="font-mono text-[9px]">?</kbd>
            </div>
          )}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Shallow Sidebar */}
      <aside
        className={`hidden shrink-0 border-r border-line bg-panel transition-[width] duration-150 ease-out md:block ${
          collapsed ? 'w-13' : 'w-52'
        }`}
      >
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Overlay */}
      {mobileOpen && (
        <div role="dialog" aria-modal="true" className="fixed inset-0 z-50 flex md:hidden">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
          />
          <div className="relative flex w-60 max-w-[80vw] flex-col bg-panel shadow-2xl animate-drawer">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
}
