'use client';

import { useMemo, useState } from 'react';
import type { MathBlock, BlockType } from '@/core/notebook/types';
import {
  ListTree,
  Search,
  X,
  LineChart,
  Table as TableIcon,
  Calculator,
  Compass,
  Sparkles,
  BookOpen,
  CheckCircle2,
  ChevronRight,
  Filter,
} from 'lucide-react';

interface NotebookOutlineProps {
  blocks: MathBlock[];
  activeBlockId: string | null;
  onSelectBlock: (blockId: string) => void;
  isOpen: boolean;
  onClose: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

type FilterCategory = 'all' | 'math' | 'calculation' | 'proof' | 'graph' | 'table';

export default function NotebookOutline({
  blocks,
  activeBlockId,
  onSelectBlock,
  isOpen,
  onClose,
  searchQuery,
  onSearchChange,
}: NotebookOutlineProps) {
  const [filter, setFilter] = useState<FilterCategory>('all');

  const filteredBlocks = useMemo(() => {
    return blocks.filter((b) => {
      // 1. Type filter
      if (filter === 'math' && b.type !== 'math') return false;
      if (filter === 'calculation' && b.type !== 'calculation') return false;
      if (filter === 'proof' && b.type !== 'derivation' && b.type !== 'proof') return false;
      if (filter === 'graph' && b.type !== 'graph') return false;
      if (filter === 'table' && b.type !== 'table') return false;

      // 2. Search query filter
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();

      // Check block metadata
      if (b.metadata?.label?.toLowerCase().includes(q)) return true;
      if (b.metadata?.category?.toLowerCase().includes(q)) return true;

      // Check content fields
      const content = b.content as any;
      if (content.text && content.text.toLowerCase().includes(q)) return true;
      if (content.title && content.title.toLowerCase().includes(q)) return true;
      if (content.latex && content.latex.toLowerCase().includes(q)) return true;
      if (content.expression && content.expression.toLowerCase().includes(q)) return true;
      if (content.term && content.term.toLowerCase().includes(q)) return true;
      if (content.statement && content.statement.toLowerCase().includes(q)) return true;

      // Derivation / Proof steps search
      if (Array.isArray(content.steps)) {
        return content.steps.some(
          (s: any) =>
            (s.expr && s.expr.toLowerCase().includes(q)) ||
            (s.reason && s.reason.toLowerCase().includes(q))
        );
      }

      return false;
    });
  }, [blocks, filter, searchQuery]);

  const getBlockSummary = (b: MathBlock): { label: string; badge: string; icon: string; snippet: string } => {
    const content = b.content as any;
    switch (b.type) {
      case 'heading':
      case 'section':
        return {
          label: content.text || content.title || 'Section',
          badge: 'SEC',
          icon: '§',
          snippet: content.description || 'Topic boundary',
        };
      case 'math':
        return {
          label: content.name ? `Equation: ${content.name}` : 'Equation',
          badge: 'EQN',
          icon: 'fx',
          snippet: content.latex || 'Symbolic formula',
        };
      case 'calculation':
        return {
          label: 'Calculation',
          badge: 'CALC',
          icon: '=',
          snippet: `${content.expression || ''} ${content.exactResult ? `→ ${content.exactResult}` : ''}`,
        };
      case 'derivation':
      case 'proof':
        return {
          label: content.title || content.theorem || 'Proof Derivation',
          badge: 'PROOF',
          icon: '∴',
          snippet: `${content.steps?.length || 0} analytical steps`,
        };
      case 'graph':
        return {
          label: 'Curve Plot',
          badge: 'GRAPH',
          icon: '📈',
          snippet: `y = ${content.expression || 'x'}`,
        };
      case 'table':
        return {
          label: content.caption || 'Data Table',
          badge: 'TABLE',
          icon: '⊞',
          snippet: `${content.rows?.length || 0} coordinate rows`,
        };
      case 'definition':
        return {
          label: content.term || 'Definition',
          badge: 'DEF',
          icon: 'def',
          snippet: content.statement || '',
        };
      case 'result':
        return {
          label: content.title || 'Verified Result',
          badge: 'RESULT',
          icon: '✓',
          snippet: content.latex || content.statement || '',
        };
      case 'callout':
        return {
          label: content.title || 'Mathematical Note',
          badge: 'NOTE',
          icon: '!',
          snippet: content.text || '',
        };
      case 'paragraph':
        return {
          label: 'Explanatory Note',
          badge: 'NOTE',
          icon: '¶',
          snippet: content.text || '',
        };
      default:
        return {
          label: 'Block',
          badge: 'OBJ',
          icon: '•',
          snippet: '',
        };
    }
  };

  if (!isOpen) return null;

  return (
    <aside
      aria-label="Notebook Outline"
      className="flex h-full w-72 shrink-0 flex-col border-r border-line bg-panel select-none overflow-hidden"
    >
      {/* Header */}
      <div className="flex h-13 shrink-0 items-center justify-between border-b border-line px-3.5">
        <div className="flex items-center gap-2">
          <ListTree className="h-4 w-4 text-accent" />
          <span className="text-xs font-bold uppercase tracking-wider text-ink">
            Object Outline
          </span>
          <span className="rounded-full bg-field px-1.5 py-0.2 font-mono text-[10px] text-muted">
            {filteredBlocks.length}
          </span>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="grid h-7 w-7 place-items-center rounded-lg text-muted hover:text-ink hover:bg-field focus-ring"
          aria-label="Close outline"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Search Bar */}
      <div className="border-b border-line/60 p-2.5">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search equations, proofs, vars..."
            className="w-full rounded-lg border border-line bg-field/60 py-1.5 pl-8 pr-2.5 text-xs text-ink placeholder-muted focus:border-accent focus:outline-none"
          />
        </div>

        {/* Filter Pills */}
        <div className="mt-2 flex items-center gap-1 overflow-x-auto pb-1 text-[10px] font-semibold">
          {[
            { id: 'all' as FilterCategory, label: 'All' },
            { id: 'math' as FilterCategory, label: 'Equations' },
            { id: 'calculation' as FilterCategory, label: 'Calculations' },
            { id: 'proof' as FilterCategory, label: 'Proofs' },
            { id: 'graph' as FilterCategory, label: 'Graphs' },
            { id: 'table' as FilterCategory, label: 'Tables' },
          ].map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setFilter(cat.id)}
              className={`rounded px-2 py-0.5 shrink-0 transition-colors ${
                filter === cat.id
                  ? 'bg-accent text-accent-ink font-bold'
                  : 'bg-field text-muted hover:text-ink'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Structured Outline Records List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {filteredBlocks.length === 0 ? (
          <div className="p-6 text-center text-xs text-muted">
            No mathematical objects found matching your filter.
          </div>
        ) : (
          filteredBlocks.map((b) => {
            const summary = getBlockSummary(b);
            const isSelected = activeBlockId === b.id;
            const isSection = b.type === 'heading' || b.type === 'section';

            return (
              <button
                key={b.id}
                type="button"
                onClick={() => onSelectBlock(b.id)}
                className={`group flex w-full items-start gap-2.5 rounded-xl px-2.5 py-2 text-left transition-all ${
                  isSelected
                    ? 'bg-accent/15 border border-accent/40 shadow-xs'
                    : isSection
                    ? 'bg-field/40 hover:bg-field text-ink font-bold border border-transparent'
                    : 'hover:bg-field/60 text-ink/85 border border-transparent'
                }`}
              >
                {/* Object Badge */}
                <span
                  className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md text-[10px] font-mono font-bold ${
                    isSelected
                      ? 'bg-accent text-accent-ink'
                      : isSection
                      ? 'bg-panel text-accent border border-line'
                      : 'bg-panel text-muted border border-line'
                  }`}
                >
                  {summary.icon}
                </span>

                <div className="flex flex-col min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <span
                      className={`text-xs truncate ${
                        isSection ? 'font-bold text-ink' : isSelected ? 'font-semibold text-accent' : 'font-medium'
                      }`}
                    >
                      {summary.label}
                    </span>
                    <span className="text-[9px] font-mono text-muted/70 shrink-0 uppercase">
                      {summary.badge}
                    </span>
                  </div>

                  {summary.snippet && (
                    <span className="text-[10px] font-mono text-muted truncate mt-0.5">
                      {summary.snippet}
                    </span>
                  )}
                </div>
              </button>
            );
          })
        )}
      </div>

      {/* Bottom Outline Footer */}
      <div className="border-t border-line/60 bg-field/30 px-3 py-2 text-[10px] text-muted flex items-center justify-between">
        <span>Click item to jump directly</span>
        <span className="font-mono">TIFspace Structure</span>
      </div>
    </aside>
  );
}

