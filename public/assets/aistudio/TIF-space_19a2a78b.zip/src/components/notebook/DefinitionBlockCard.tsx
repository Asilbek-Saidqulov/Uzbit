'use client';

import React from 'react';
import type { MathBlock, DefinitionContent } from '@/core/notebook/types';
import MathView from '@/components/MathView';
import {
  BookMarked,
  Copy,
  Trash2,
  Link2,
  ChevronUp,
  ChevronDown,
} from 'lucide-react';

interface DefinitionBlockCardProps {
  block: MathBlock;
  isFirst: boolean;
  isLast: boolean;
  onUpdate: (patch: Partial<DefinitionContent>) => void;
  onUpdateMetadata: (patch: Partial<MathBlock['metadata']>) => void;
  onMove: (dir: -1 | 1) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onOpenLinkModal: () => void;
  onJumpToBlock: (targetBlockId: string) => void;
}

export default function DefinitionBlockCard({
  block,
  isFirst,
  isLast,
  onUpdate,
  onUpdateMetadata,
  onMove,
  onDuplicate,
  onDelete,
  onOpenLinkModal,
  onJumpToBlock,
}: DefinitionBlockCardProps) {
  const content = block.content as DefinitionContent;

  return (
    <div
      id={`block-${block.id}`}
      className="group rounded-2xl border border-line bg-panel shadow-xs transition-all hover:border-indigo-500/40 hover:shadow-sm"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 bg-field/30 px-4 py-2.5 rounded-t-2xl">
        <div className="flex items-center gap-2.5 flex-wrap">
          <span className="flex items-center gap-1.5 rounded-md border border-indigo-500/30 bg-indigo-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-indigo-400">
            <BookMarked className="h-3 w-3" />
            <span>Definition</span>
            <span className="opacity-60">#{block.position + 1}</span>
          </span>

          <input
            type="text"
            value={block.metadata?.label || ''}
            onChange={(e) => onUpdateMetadata({ label: e.target.value })}
            placeholder="Label (e.g. Definition 1.2)"
            className="rounded border border-transparent bg-transparent px-1.5 py-0.5 text-xs font-semibold text-ink hover:border-line focus:border-indigo-500 focus:bg-field focus:outline-none"
          />

          {/* Relationship Pills */}
          {block.relationships && block.relationships.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap">
              {block.relationships.map((rel) => (
                <button
                  key={rel.targetBlockId + rel.type}
                  type="button"
                  onClick={() => onJumpToBlock(rel.targetBlockId)}
                  className="flex items-center gap-1 rounded-md border border-line bg-panel px-2 py-0.5 text-[10px] font-medium text-muted hover:border-accent hover:text-ink transition-colors"
                  title={`Jump to linked object (${rel.type})`}
                >
                  <Link2 className="h-2.5 w-2.5 text-accent" />
                  <span className="capitalize">{rel.type}:</span>
                  <span className="font-semibold">{rel.label || 'Target'}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
          <button
            type="button"
            onClick={onOpenLinkModal}
            title="Link to another mathematical object"
            className="flex items-center gap-1 rounded-md border border-line bg-field px-2 py-1 text-[11px] font-medium text-muted hover:border-indigo-500 hover:text-ink transition-colors"
          >
            <Link2 className="h-3 w-3 text-indigo-400" />
            <span>Link</span>
          </button>

          <button
            type="button"
            onClick={() => onMove(-1)}
            disabled={isFirst}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move up"
          >
            <ChevronUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onMove(1)}
            disabled={isLast}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move down"
          >
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDuplicate}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink"
            title="Duplicate definition"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-danger"
            title="Delete definition"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Term name */}
          <div>
            <label className="block text-[11px] font-semibold text-muted mb-1">
              Term Being Defined
            </label>
            <input
              type="text"
              value={content.term || ''}
              onChange={(e) => onUpdate({ term: e.target.value })}
              placeholder="e.g. Differentiability, Topology, Vector Space"
              className="w-full rounded-xl border border-line bg-field px-3 py-1.5 text-xs font-bold text-ink focus:border-indigo-500 focus:outline-none"
            />
          </div>

          {/* Notation */}
          <div>
            <label className="block text-[11px] font-semibold text-muted mb-1">
              Symbolic Notation (LaTeX)
            </label>
            <input
              type="text"
              value={content.notation || ''}
              onChange={(e) => onUpdate({ notation: e.target.value })}
              placeholder="e.g. f'(x) = \lim_{h \to 0} \frac{f(x+h)-f(x)}{h}"
              className="w-full rounded-xl border border-line bg-field px-3 py-1.5 font-mono text-xs text-ink focus:border-indigo-500 focus:outline-none"
            />
          </div>
        </div>

        {content.notation && (
          <div className="py-1 text-center font-serif text-sm text-ink overflow-x-auto">
            <MathView math={content.notation} displayMode />
          </div>
        )}

        {/* Statement */}
        <div>
          <label className="block text-[11px] font-semibold text-muted mb-1">
            Formal Mathematical Statement
          </label>
          <textarea
            rows={2}
            value={content.statement || ''}
            onChange={(e) => onUpdate({ statement: e.target.value })}
            placeholder="A rigorous definition explaining the exact conditions..."
            className="w-full rounded-xl border border-line bg-field p-2.5 text-xs leading-relaxed text-ink focus:border-indigo-500 focus:outline-none"
          />
        </div>

        {/* Domain Constraint */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-muted font-medium text-[11px]">Domain Criteria:</span>
          <input
            type="text"
            value={content.domainConstraint || ''}
            onChange={(e) => onUpdate({ domainConstraint: e.target.value })}
            placeholder="e.g. x ∈ ℝ, V is a field over F"
            className="flex-1 rounded-lg border border-line bg-field px-2.5 py-1 font-mono text-xs text-ink focus:border-indigo-500 focus:outline-none"
          />
        </div>
      </div>
    </div>
  );
}

