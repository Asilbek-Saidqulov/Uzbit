'use client';

import React, { useState, useEffect } from 'react';
import type { MathBlock, CalculationContent } from '@/core/notebook/types';
import { mathEngine } from '@/core/math/engine';
import {
  Calculator,
  Copy,
  CheckCircle2,
  Link2,
  Trash2,
  ChevronUp,
  ChevronDown,
  RotateCcw,
} from 'lucide-react';

interface CalculationBlockCardProps {
  block: MathBlock;
  isFirst: boolean;
  isLast: boolean;
  onUpdate: (patch: Partial<CalculationContent>) => void;
  onUpdateMetadata: (patch: Partial<MathBlock['metadata']>) => void;
  onMove: (dir: -1 | 1) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onOpenLinkModal: () => void;
  onJumpToBlock: (targetBlockId: string) => void;
}

export default function CalculationBlockCard({
  block,
  isFirst,
  isLast,
  onUpdate,
  onUpdateMetadata,
  onMove,
  onDuplicate,
  onDelete,
  onOpenLinkModal,
  onJumpToBlock,
}: CalculationBlockCardProps) {
  const content = block.content as CalculationContent;
  const [copied, setCopied] = useState(false);
  const angleMode = content.angleMode || 'radians';

  // Evaluate expression deterministically via mathEngine
  const evalResult = content.expression
    ? mathEngine.evaluate(content.expression, angleMode)
    : null;

  // Sync evaluated results to content if they changed
  useEffect(() => {
    if (evalResult?.status === 'success') {
      const exact = evalResult.exact;
      const formatted = evalResult.formatted;
      const approx = typeof evalResult.value === 'number' ? evalResult.value : undefined;

      if (
        content.exactResult !== exact ||
        content.formattedResult !== formatted ||
        content.approximation !== approx
      ) {
        onUpdate({
          exactResult: exact,
          formattedResult: formatted,
          approximation: approx,
        });
      }
    }
  }, [evalResult?.status, evalResult?.formatted, evalResult?.exact]);

  const handleCopyResult = () => {
    const val = evalResult?.exact || evalResult?.formatted || content.formattedResult;
    if (!val) return;
    navigator.clipboard?.writeText(val);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div
      id={`block-${block.id}`}
      className="group rounded-2xl border border-line bg-panel shadow-xs transition-all hover:border-amber-500/40 hover:shadow-sm"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 bg-field/30 px-4 py-2.5 rounded-t-2xl">
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Badge */}
          <span className="flex items-center gap-1.5 rounded-md border border-amber-500/30 bg-amber-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-amber-400">
            <Calculator className="h-3 w-3" />
            <span>Calculation</span>
            <span className="opacity-60">#{block.position + 1}</span>
          </span>

          {/* Label */}
          <input
            type="text"
            value={block.metadata?.label || ''}
            onChange={(e) => onUpdateMetadata({ label: e.target.value })}
            placeholder="Label (e.g. Riemann Sum, Total Area)"
            className="rounded border border-transparent bg-transparent px-1.5 py-0.5 text-xs font-semibold text-ink hover:border-line focus:border-amber-500 focus:bg-field focus:outline-none"
          />

          {/* Relationship Pills */}
          {block.relationships && block.relationships.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap">
              {block.relationships.map((rel) => (
                <button
                  key={rel.targetBlockId + rel.type}
                  type="button"
                  onClick={() => onJumpToBlock(rel.targetBlockId)}
                  className="flex items-center gap-1 rounded-md border border-line bg-panel px-2 py-0.5 text-[10px] font-medium text-muted hover:border-accent hover:text-ink transition-colors"
                  title={`Jump to linked object (${rel.type})`}
                >
                  <Link2 className="h-2.5 w-2.5 text-accent" />
                  <span className="capitalize">{rel.type}:</span>
                  <span className="font-semibold">{rel.label || 'Target'}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
          <button
            type="button"
            onClick={onOpenLinkModal}
            title="Link to another mathematical object"
            className="flex items-center gap-1 rounded-md border border-line bg-field px-2 py-1 text-[11px] font-medium text-muted hover:border-amber-500 hover:text-ink transition-colors"
          >
            <Link2 className="h-3 w-3 text-amber-400" />
            <span>Link</span>
          </button>

          <button
            type="button"
            onClick={() => onMove(-1)}
            disabled={isFirst}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move up"
          >
            <ChevronUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onMove(1)}
            disabled={isLast}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move down"
          >
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDuplicate}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink"
            title="Duplicate calculation"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-danger"
            title="Delete calculation"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Main Calculation Inputs & Output */}
      <div className="p-4 space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Expression Input */}
          <div className="flex-1">
            <label className="block text-[11px] font-semibold text-muted mb-1">
              Mathematical Expression
            </label>
            <div className="relative">
              <input
                type="text"
                value={content.expression}
                onChange={(e) => onUpdate({ expression: e.target.value })}
                placeholder="e.g. 1/3 + 1/6, sin(pi/4), sqrt(18), 2^10"
                className="w-full rounded-xl border border-line bg-field px-3 py-2 font-mono text-sm text-ink focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Angle Mode Selector */}
          <div className="shrink-0">
            <label className="block text-[11px] font-semibold text-muted mb-1">
              Trig Mode
            </label>
            <div className="flex rounded-xl border border-line bg-field p-0.5 text-xs font-semibold">
              <button
                type="button"
                onClick={() => onUpdate({ angleMode: 'radians' })}
                className={`px-3 py-1.5 rounded-lg transition-colors ${
                  angleMode === 'radians'
                    ? 'bg-amber-500 text-black shadow-xs font-bold'
                    : 'text-muted hover:text-ink'
                }`}
              >
                RAD
              </button>
              <button
                type="button"
                onClick={() => onUpdate({ angleMode: 'degrees' })}
                className={`px-3 py-1.5 rounded-lg transition-colors ${
                  angleMode === 'degrees'
                    ? 'bg-amber-500 text-black shadow-xs font-bold'
                    : 'text-muted hover:text-ink'
                }`}
              >
                DEG
              </button>
            </div>
          </div>
        </div>

        {/* Real-Time Result Display Card */}
        <div className="rounded-xl border border-line/70 bg-field/40 p-3.5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-[10px] uppercase font-bold tracking-wider text-muted mb-0.5">
              Computed Value
            </div>
            {evalResult?.status === 'success' ? (
              <div className="flex items-baseline gap-3 flex-wrap">
                <span className="font-mono text-lg font-bold text-amber-400">
                  {evalResult.exact || evalResult.formatted}
                </span>
                {evalResult.exact && evalResult.exact !== evalResult.formatted && (
                  <span className="text-xs font-mono text-muted">
                    ≈ {evalResult.formatted}
                  </span>
                )}
              </div>
            ) : evalResult?.status === 'error' ? (
              <div className="text-xs text-danger font-medium">
                {evalResult.error}
              </div>
            ) : (
              <div className="text-xs text-muted font-mono">
                Enter expression to calculate
              </div>
            )}
          </div>

          {evalResult?.status === 'success' && (
            <button
              type="button"
              onClick={handleCopyResult}
              className="flex items-center gap-1.5 rounded-lg border border-line bg-panel px-2.5 py-1 text-xs font-semibold text-ink hover:border-amber-500 transition-colors"
            >
              {copied ? (
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
              ) : (
                <Copy className="h-3.5 w-3.5 text-muted" />
              )}
              <span>{copied ? 'Copied' : 'Copy Value'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

