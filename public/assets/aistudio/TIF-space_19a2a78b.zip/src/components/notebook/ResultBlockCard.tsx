'use client';

import React, { useState } from 'react';
import type { MathBlock, ResultContent } from '@/core/notebook/types';
import MathView from '@/components/MathView';
import {
  Award,
  Copy,
  CheckCircle2,
  Trash2,
  Link2,
  ChevronUp,
  ChevronDown,
  Edit2,
  Check,
} from 'lucide-react';

interface ResultBlockCardProps {
  block: MathBlock;
  isFirst: boolean;
  isLast: boolean;
  onUpdate: (patch: Partial<ResultContent>) => void;
  onUpdateMetadata: (patch: Partial<MathBlock['metadata']>) => void;
  onMove: (dir: -1 | 1) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onOpenLinkModal: () => void;
  onJumpToBlock: (targetBlockId: string) => void;
}

export default function ResultBlockCard({
  block,
  isFirst,
  isLast,
  onUpdate,
  onUpdateMetadata,
  onMove,
  onDuplicate,
  onDelete,
  onOpenLinkModal,
  onJumpToBlock,
}: ResultBlockCardProps) {
  const content = block.content as ResultContent;
  const [editingLatex, setEditingLatex] = useState(false);
  const [copied, setCopied] = useState(false);
  const status = content.status || 'exact';

  const handleCopyLatex = () => {
    if (!content.latex) return;
    navigator.clipboard?.writeText(content.latex);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div
      id={`block-${block.id}`}
      className="group rounded-2xl border border-line bg-panel shadow-xs transition-all hover:border-emerald-400/50 hover:shadow-sm"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 bg-field/30 px-4 py-2.5 rounded-t-2xl">
        <div className="flex items-center gap-2.5 flex-wrap">
          <span className="flex items-center gap-1.5 rounded-md border border-emerald-400/40 bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-300">
            <Award className="h-3 w-3" />
            <span>Verified Result</span>
            <span className="opacity-60">#{block.position + 1}</span>
          </span>

          <input
            type="text"
            value={block.metadata?.label || content.title || ''}
            onChange={(e) => {
              onUpdateMetadata({ label: e.target.value });
              onUpdate({ title: e.target.value });
            }}
            placeholder="Result Name (e.g. Definite Area)"
            className="rounded border border-transparent bg-transparent px-1.5 py-0.5 text-xs font-semibold text-ink hover:border-line focus:border-emerald-400 focus:bg-field focus:outline-none"
          />

          {/* Relationship Pills */}
          {block.relationships && block.relationships.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap">
              {block.relationships.map((rel) => (
                <button
                  key={rel.targetBlockId + rel.type}
                  type="button"
                  onClick={() => onJumpToBlock(rel.targetBlockId)}
                  className="flex items-center gap-1 rounded-md border border-line bg-panel px-2 py-0.5 text-[10px] font-medium text-muted hover:border-accent hover:text-ink transition-colors"
                  title={`Jump to linked object (${rel.type})`}
                >
                  <Link2 className="h-2.5 w-2.5 text-accent" />
                  <span className="capitalize">{rel.type}:</span>
                  <span className="font-semibold">{rel.label || 'Target'}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
          {/* Status selector */}
          <select
            value={status}
            onChange={(e) => onUpdate({ status: e.target.value as any })}
            className="rounded-lg border border-line bg-field px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-muted focus:border-emerald-400 focus:outline-none"
          >
            <option value="exact">Exact Result</option>
            <option value="verified">Verified Q.E.D.</option>
            <option value="approximate">Numerical Approx</option>
          </select>

          <button
            type="button"
            onClick={onOpenLinkModal}
            title="Link to another mathematical object"
            className="flex items-center gap-1 rounded-md border border-line bg-field px-2 py-1 text-[11px] font-medium text-muted hover:border-emerald-400 hover:text-ink transition-colors"
          >
            <Link2 className="h-3 w-3 text-emerald-400" />
            <span>Link</span>
          </button>

          <button
            type="button"
            onClick={() => onMove(-1)}
            disabled={isFirst}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move up"
          >
            <ChevronUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onMove(1)}
            disabled={isLast}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move down"
          >
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDuplicate}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink"
            title="Duplicate result"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-danger"
            title="Delete result"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 space-y-3">
        {/* Outcome Statement */}
        <div>
          <input
            type="text"
            value={content.statement || ''}
            onChange={(e) => onUpdate({ statement: e.target.value })}
            placeholder="Statement of finding (e.g. Net signed area of the integral)"
            className="w-full bg-transparent text-xs font-medium text-ink placeholder:text-muted focus:outline-none"
          />
        </div>

        {/* Result Formula Display */}
        <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/10 p-3.5 text-center">
          {editingLatex ? (
            <div className="space-y-2">
              <input
                type="text"
                value={content.latex || ''}
                onChange={(e) => onUpdate({ latex: e.target.value })}
                placeholder="e.g. \int_{0}^{2} (x^2 - 4)\,dx = -\frac{16}{3}"
                className="w-full rounded-lg border border-line bg-panel px-3 py-1.5 font-mono text-xs text-ink focus:border-emerald-400 focus:outline-none"
                autoFocus
              />
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setEditingLatex(false)}
                  className="flex items-center gap-1 rounded bg-panel px-2 py-0.5 text-[11px] font-semibold text-emerald-400 border border-line"
                >
                  <Check className="h-3 w-3" />
                  <span>Done</span>
                </button>
              </div>
            </div>
          ) : (
            <div
              onClick={() => setEditingLatex(true)}
              className="cursor-pointer overflow-x-auto py-1 text-lg font-serif text-ink"
              title="Click to edit formula"
            >
              <MathView math={content.latex || '0'} displayMode />
            </div>
          )}
        </div>

        {/* Footer controls */}
        <div className="flex items-center justify-between text-[11px] pt-1">
          <button
            type="button"
            onClick={() => setEditingLatex(!editingLatex)}
            className="flex items-center gap-1 text-muted hover:text-ink font-semibold transition-colors"
          >
            <Edit2 className="h-3 w-3" />
            <span>{editingLatex ? 'Done Editing' : 'Edit Formula'}</span>
          </button>

          {content.latex && (
            <button
              type="button"
              onClick={handleCopyLatex}
              className="flex items-center gap-1 text-muted hover:text-ink font-medium transition-colors"
            >
              {copied ? <CheckCircle2 className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
              <span>{copied ? 'Copied' : 'Copy LaTeX'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

