'use client';

import React, { useState, useMemo, useEffect, useRef } from 'react';
import type { BlockType } from '@/core/notebook/types';
import {
  Sparkles,
  Calculator,
  GitBranch,
  ShieldCheck,
  LineChart,
  Table as TableIcon,
  FolderTree,
  BookMarked,
  Award,
  FileText,
  Search,
  X,
  Plus,
} from 'lucide-react';

export interface BlockOption {
  type: BlockType;
  label: string;
  category: 'Mathematics' | 'Visualization' | 'Structure';
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  badge?: string;
  keyboardHint?: string;
}

export const BLOCK_OPTIONS: BlockOption[] = [
  // Mathematics
  {
    type: 'math',
    label: 'Equation',
    category: 'Mathematics',
    icon: Sparkles,
    description: 'LaTeX mathematical expression with evaluation and domain constraints',
    badge: 'KaTeX',
    keyboardHint: '/math',
  },
  {
    type: 'calculation',
    label: 'Calculation',
    category: 'Mathematics',
    icon: Calculator,
    description: 'Deterministic computation with exact rational arithmetic and decimal output',
    badge: 'CAS',
    keyboardHint: '/calc',
  },
  {
    type: 'derivation',
    label: 'Derivation',
    category: 'Mathematics',
    icon: GitBranch,
    description: 'Step-by-step algebraic manipulation with line-by-line justifications',
    badge: 'Steps',
    keyboardHint: '/derive',
  },
  {
    type: 'proof',
    label: 'Formal Proof',
    category: 'Mathematics',
    icon: ShieldCheck,
    description: 'Theorem hypothesis, sequence of inferential steps, and Q.E.D. conclusion',
    badge: 'Proof',
    keyboardHint: '/proof',
  },

  // Visualization
  {
    type: 'graph',
    label: 'Interactive Graph',
    category: 'Visualization',
    icon: LineChart,
    description: 'Dynamic JSXGraph SVG curve visualizer with derivative and integral shading',
    badge: 'Plotter',
    keyboardHint: '/graph',
  },
  {
    type: 'table',
    label: 'Coordinate Table',
    category: 'Visualization',
    icon: TableIcon,
    description: 'Ordered coordinate pairs (x, y) with automated regression curve fitting',
    badge: 'Data',
    keyboardHint: '/table',
  },

  // Structure & Foundation
  {
    type: 'section',
    label: 'Section Container',
    category: 'Structure',
    icon: FolderTree,
    description: 'Collapsible structural container grouping related mathematical derivations',
    badge: 'Topic',
    keyboardHint: '/section',
  },
  {
    type: 'definition',
    label: 'Definition',
    category: 'Structure',
    icon: BookMarked,
    description: 'Formal mathematical definition with notation and domain constraint',
    badge: 'Axiom',
    keyboardHint: '/def',
  },
  {
    type: 'result',
    label: 'Verified Result',
    category: 'Structure',
    icon: Award,
    description: 'Key mathematical finding, exact numerical outcome, or verified theorem',
    badge: 'Result',
    keyboardHint: '/result',
  },
  {
    type: 'paragraph',
    label: 'Mathematical Note',
    category: 'Structure',
    icon: FileText,
    description: 'Explanatory prose, background context, and analytical observations',
    badge: 'Text',
    keyboardHint: '/note',
  },
];

interface AddBlockModalProps {
  isOpen: boolean;
  insertIndex?: number | null;
  onClose: () => void;
  onSelect: (type: BlockType, insertIndex?: number | null) => void;
}

export default function AddBlockModal({
  isOpen,
  insertIndex,
  onClose,
  onSelect,
}: AddBlockModalProps) {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setSearch('');
      setSelectedCategory('All');
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const filteredOptions = useMemo(() => {
    const q = search.trim().toLowerCase();
    return BLOCK_OPTIONS.filter((opt) => {
      const matchesCategory =
        selectedCategory === 'All' || opt.category === selectedCategory;
      if (!matchesCategory) return false;
      if (!q) return true;
      return (
        opt.label.toLowerCase().includes(q) ||
        opt.description.toLowerCase().includes(q) ||
        opt.type.toLowerCase().includes(q) ||
        opt.category.toLowerCase().includes(q) ||
        (opt.keyboardHint && opt.keyboardHint.toLowerCase().includes(q))
      );
    });
  }, [search, selectedCategory]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Insert Mathematical Object"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-2xl border border-line bg-panel shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-line px-5 py-3.5 bg-field/30">
          <div>
            <h2 className="text-sm font-bold text-ink flex items-center gap-2">
              <Plus className="h-4 w-4 text-accent" />
              <span>Insert Mathematical Object</span>
            </h2>
            <p className="text-[11px] text-muted">
              {insertIndex !== undefined && insertIndex !== null
                ? `Inserting after position #${insertIndex + 1}`
                : 'Append to notebook workspace'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="grid h-7 w-7 place-items-center rounded-lg text-muted hover:bg-field hover:text-ink transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Search & Category Filter Bar */}
        <div className="border-b border-line p-3 space-y-2 bg-panel">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-muted pointer-events-none" />
            <input
              ref={inputRef}
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search objects: equation, calc, proof, graph, table, definition..."
              className="w-full rounded-xl border border-line bg-field pl-9 pr-3 py-1.5 text-xs text-ink placeholder:text-muted focus:border-accent focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 text-[11px]">
            {['All', 'Mathematics', 'Visualization', 'Structure'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-lg px-2.5 py-1 font-semibold transition-colors shrink-0 ${
                  selectedCategory === cat
                    ? 'bg-accent text-accent-ink shadow-xs'
                    : 'text-muted hover:bg-field hover:text-ink'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Options Grid */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {filteredOptions.length === 0 ? (
            <div className="py-12 text-center text-xs text-muted">
              No mathematical objects match &ldquo;{search}&rdquo;. Try &ldquo;equation&rdquo;, &ldquo;graph&rdquo;, or &ldquo;calc&rdquo;.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {filteredOptions.map((opt) => {
                const Icon = opt.icon;
                return (
                  <button
                    key={opt.type}
                    type="button"
                    onClick={() => {
                      onSelect(opt.type, insertIndex);
                      onClose();
                    }}
                    className="group flex items-start gap-3 rounded-xl border border-line bg-field/30 p-3 text-left transition-all hover:border-accent hover:bg-field hover:shadow-xs focus:outline-none focus:ring-1 focus:ring-accent"
                  >
                    <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-line bg-panel text-accent group-hover:bg-accent group-hover:text-accent-ink transition-colors">
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <span className="text-xs font-bold text-ink group-hover:text-accent transition-colors">
                          {opt.label}
                        </span>
                        {opt.badge && (
                          <span className="rounded bg-panel px-1.5 py-0.5 font-mono text-[9px] font-semibold text-muted border border-line/60">
                            {opt.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-muted line-clamp-2 leading-snug">
                        {opt.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer tips */}
        <div className="border-t border-line bg-field/20 px-5 py-2.5 flex items-center justify-between text-[11px] text-muted">
          <span>Click any object to insert it into your workspace</span>
          <span className="font-mono text-[10px]">Esc to dismiss</span>
        </div>
      </div>
    </div>
  );
}

