'use client';

import React, { useMemo } from 'react';
import type { MathBlock, TableContent, TableRowData } from '@/core/notebook/types';
import { computeLinearRegression, computeQuadraticRegression } from '@/core/math/regression';
import {
  Table as TableIcon,
  Plus,
  Trash2,
  Copy,
  Link2,
  ChevronUp,
  ChevronDown,
  Sparkles,
  TrendingUp,
} from 'lucide-react';

interface TableBlockCardProps {
  block: MathBlock;
  isFirst: boolean;
  isLast: boolean;
  onUpdate: (patch: Partial<TableContent>) => void;
  onUpdateMetadata: (patch: Partial<MathBlock['metadata']>) => void;
  onMove: (dir: -1 | 1) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onOpenLinkModal: () => void;
  onJumpToBlock: (targetBlockId: string) => void;
  onInsertRegressionEquation?: (latex: string) => void;
}

export default function TableBlockCard({
  block,
  isFirst,
  isLast,
  onUpdate,
  onUpdateMetadata,
  onMove,
  onDuplicate,
  onDelete,
  onOpenLinkModal,
  onJumpToBlock,
  onInsertRegressionEquation,
}: TableBlockCardProps) {
  const content = block.content as TableContent;
  const rows = content.rows || [];
  const model = content.model || 'linear';

  const handleAddRow = () => {
    const nextRows: TableRowData[] = [...rows, { x: '', y: '' }];
    onUpdate({ rows: nextRows });
  };

  const handleUpdateCell = (index: number, col: 'x' | 'y', val: string) => {
    const nextRows = rows.map((r, i) => (i === index ? { ...r, [col]: val } : r));
    onUpdate({ rows: nextRows });
  };

  const handleRemoveRow = (index: number) => {
    if (rows.length <= 1) return;
    const nextRows = rows.filter((_, i) => i !== index);
    onUpdate({ rows: nextRows });
  };

  // Convert string rows to numeric points for regression
  const points = useMemo(() => {
    return rows
      .map((r) => ({ x: parseFloat(r.x), y: parseFloat(r.y) }))
      .filter((p) => !isNaN(p.x) && !isNaN(p.y));
  }, [rows]);

  // Compute regression fit
  const regression = useMemo(() => {
    if (model === 'linear') {
      return computeLinearRegression(points);
    } else if (model === 'quadratic') {
      return computeQuadraticRegression(points);
    }
    return null;
  }, [points, model]);

  return (
    <div
      id={`block-${block.id}`}
      className="group rounded-2xl border border-line bg-panel shadow-xs transition-all hover:border-purple-500/40 hover:shadow-sm"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 bg-field/30 px-4 py-2.5 rounded-t-2xl">
        <div className="flex items-center gap-2.5 flex-wrap">
          <span className="flex items-center gap-1.5 rounded-md border border-purple-500/30 bg-purple-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-purple-400">
            <TableIcon className="h-3 w-3" />
            <span>Coordinate Table</span>
            <span className="opacity-60">#{block.position + 1}</span>
          </span>

          <input
            type="text"
            value={block.metadata?.label || content.caption || ''}
            onChange={(e) => {
              onUpdateMetadata({ label: e.target.value });
              onUpdate({ caption: e.target.value });
            }}
            placeholder="Caption (e.g. Experimental Data)"
            className="rounded border border-transparent bg-transparent px-1.5 py-0.5 text-xs font-semibold text-ink hover:border-line focus:border-purple-500 focus:bg-field focus:outline-none"
          />

          {/* Relationship Pills */}
          {block.relationships && block.relationships.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap">
              {block.relationships.map((rel) => (
                <button
                  key={rel.targetBlockId + rel.type}
                  type="button"
                  onClick={() => onJumpToBlock(rel.targetBlockId)}
                  className="flex items-center gap-1 rounded-md border border-line bg-panel px-2 py-0.5 text-[10px] font-medium text-muted hover:border-accent hover:text-ink transition-colors"
                  title={`Jump to linked object (${rel.type})`}
                >
                  <Link2 className="h-2.5 w-2.5 text-accent" />
                  <span className="capitalize">{rel.type}:</span>
                  <span className="font-semibold">{rel.label || 'Target'}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
          <button
            type="button"
            onClick={onOpenLinkModal}
            title="Link to another mathematical object"
            className="flex items-center gap-1 rounded-md border border-line bg-field px-2 py-1 text-[11px] font-medium text-muted hover:border-purple-500 hover:text-ink transition-colors"
          >
            <Link2 className="h-3 w-3 text-purple-400" />
            <span>Link</span>
          </button>

          <button
            type="button"
            onClick={() => onMove(-1)}
            disabled={isFirst}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move up"
          >
            <ChevronUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onMove(1)}
            disabled={isLast}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move down"
          >
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDuplicate}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink"
            title="Duplicate table"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-danger"
            title="Delete table"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Main Table Content */}
      <div className="p-4 space-y-4">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-line text-muted">
                <th className="py-1.5 px-3 text-left font-mono font-bold w-12">#</th>
                <th className="py-1.5 px-3 text-left font-mono font-bold">X (Independent)</th>
                <th className="py-1.5 px-3 text-left font-mono font-bold">Y (Dependent)</th>
                <th className="w-8"></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr key={i} className="border-b border-line/40 hover:bg-field/20">
                  <td className="py-1.5 px-3 font-mono text-[11px] text-muted">{i + 1}</td>
                  <td className="py-1 px-3">
                    <input
                      type="text"
                      value={row.x}
                      onChange={(e) => handleUpdateCell(i, 'x', e.target.value)}
                      placeholder="0"
                      className="w-28 rounded-lg border border-line bg-field px-2.5 py-1 font-mono text-ink focus:border-purple-500 focus:outline-none"
                    />
                  </td>
                  <td className="py-1 px-3">
                    <input
                      type="text"
                      value={row.y}
                      onChange={(e) => handleUpdateCell(i, 'y', e.target.value)}
                      placeholder="0"
                      className="w-28 rounded-lg border border-line bg-field px-2.5 py-1 font-mono text-ink focus:border-purple-500 focus:outline-none"
                    />
                  </td>
                  <td className="py-1 px-2 text-center">
                    <button
                      type="button"
                      onClick={() => handleRemoveRow(i)}
                      disabled={rows.length <= 1}
                      className="text-muted hover:text-danger p-1 rounded disabled:opacity-20"
                      title="Remove row"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <button
          type="button"
          onClick={handleAddRow}
          className="flex items-center gap-1.5 rounded-lg border border-line bg-field px-3 py-1 text-xs font-semibold text-ink hover:border-purple-500 transition-colors"
        >
          <Plus className="h-3.5 w-3.5 text-purple-400" />
          <span>Add Data Point</span>
        </button>

        {/* Polynomial Regression Modeling Toolbar */}
        <div className="rounded-xl border border-line/80 bg-field/30 p-3.5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-purple-400" />
              <span className="text-xs font-bold text-ink">Polynomial Regression Fit</span>
            </div>

            {/* Model Selector */}
            <div className="flex rounded-lg border border-line bg-panel p-0.5 text-xs font-semibold">
              <button
                type="button"
                onClick={() => onUpdate({ model: 'none' })}
                className={`px-2.5 py-0.5 rounded ${model === 'none' ? 'bg-purple-500 text-white font-bold' : 'text-muted hover:text-ink'}`}
              >
                Off
              </button>
              <button
                type="button"
                onClick={() => onUpdate({ model: 'linear' })}
                className={`px-2.5 py-0.5 rounded ${model === 'linear' ? 'bg-purple-500 text-white font-bold' : 'text-muted hover:text-ink'}`}
              >
                Linear (y = mx + b)
              </button>
              <button
                type="button"
                onClick={() => onUpdate({ model: 'quadratic' })}
                className={`px-2.5 py-0.5 rounded ${model === 'quadratic' ? 'bg-purple-500 text-white font-bold' : 'text-muted hover:text-ink'}`}
              >
                Quadratic (ax² + bx + c)
              </button>
            </div>
          </div>

          {model !== 'none' && (
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-line/40">
              {regression ? (
                <>
                  <div className="flex items-baseline gap-3 flex-wrap text-xs">
                    <span className="text-muted font-medium">Model:</span>
                    <span className="font-mono font-bold text-purple-400">
                      {regression.equation}
                    </span>
                    <span className="rounded bg-panel px-2 py-0.5 font-mono text-[11px] text-muted border border-line">
                      R² = {regression.r2.toFixed(4)}
                    </span>
                  </div>

                  {onInsertRegressionEquation && (
                    <button
                      type="button"
                      onClick={() => onInsertRegressionEquation(regression.latex)}
                      className="flex items-center gap-1.5 rounded-lg bg-purple-500/20 border border-purple-500/30 px-2.5 py-1 text-xs font-bold text-purple-400 hover:bg-purple-500/30 transition-colors"
                    >
                      <Sparkles className="h-3 w-3" />
                      <span>Insert Regression Equation</span>
                    </button>
                  )}
                </>
              ) : (
                <div className="text-xs text-muted">
                  Requires at least {model === 'quadratic' ? '3' : '2'} distinct valid points for regression fit.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

