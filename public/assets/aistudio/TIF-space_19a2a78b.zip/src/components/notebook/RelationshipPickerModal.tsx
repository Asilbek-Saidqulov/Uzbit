'use client';

import React, { useState, useMemo } from 'react';
import type { MathBlock, BlockRelationship, RelationshipType } from '@/core/notebook/types';
import { Link2, Trash2, X, Check, ArrowRight } from 'lucide-react';

interface RelationshipPickerModalProps {
  isOpen: boolean;
  sourceBlock: MathBlock | null;
  allBlocks: MathBlock[];
  onClose: () => void;
  onAddRelationship: (sourceBlockId: string, relationship: BlockRelationship) => void;
  onRemoveRelationship: (sourceBlockId: string, targetBlockId: string) => void;
}

const RELATIONSHIP_TYPES: { type: RelationshipType; label: string; desc: string }[] = [
  { type: 'references', label: 'References', desc: 'Refers to or utilizes an equation, definition, or table' },
  { type: 'derivedFrom', label: 'Derived From', desc: 'Analytically derived from a predecessor equation or step' },
  { type: 'visualizedBy', label: 'Visualized By', desc: 'Has its geometric or graphical representation in target' },
  { type: 'produces', label: 'Produces', desc: 'Directly yields this verified outcome or deduction' },
  { type: 'calculates', label: 'Calculates', desc: 'Performs numerical or symbolic evaluation of target' },
];

export default function RelationshipPickerModal({
  isOpen,
  sourceBlock,
  allBlocks,
  onClose,
  onAddRelationship,
  onRemoveRelationship,
}: RelationshipPickerModalProps) {
  const [selectedTargetId, setSelectedTargetId] = useState<string>('');
  const [relType, setRelType] = useState<RelationshipType>('references');
  const [customLabel, setCustomLabel] = useState<string>('');

  // Eligible targets: all blocks except source
  const availableTargets = useMemo(() => {
    if (!sourceBlock) return [];
    return allBlocks.filter((b) => b.id !== sourceBlock.id);
  }, [allBlocks, sourceBlock]);

  if (!isOpen || !sourceBlock) return null;

  const currentRelationships = sourceBlock.relationships || [];

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTargetId) return;

    const rel: BlockRelationship = {
      targetBlockId: selectedTargetId,
      type: relType,
      label: customLabel.trim() || undefined,
    };

    onAddRelationship(sourceBlock.id, rel);
    setCustomLabel('');
    setSelectedTargetId('');
  };

  const getBlockSummary = (b: MathBlock): string => {
    const c = b.content as Record<string, any>;
    if (b.type === 'math') return c.latex ? `$${c.latex}$` : 'KaTeX Equation';
    if (b.type === 'calculation') return c.expression ? `Calc: ${c.expression}` : 'Calculation';
    if (b.type === 'derivation') return c.title || 'Analytical Derivation';
    if (b.type === 'proof') return c.theorem ? `Proof: ${c.theorem}` : 'Formal Proof';
    if (b.type === 'graph') return c.expression ? `Graph: y = ${c.expression}` : 'Interactive Graph';
    if (b.type === 'table') return c.caption || 'Coordinate Table';
    if (b.type === 'definition') return c.term ? `Def: ${c.term}` : 'Definition';
    if (b.type === 'result') return c.title || c.statement || 'Verified Result';
    if (b.type === 'section') return c.title || 'Section Container';
    if (b.type === 'heading') return c.text || 'Heading';
    if (b.type === 'paragraph') return (c.text || 'Text note').slice(0, 45);
    return b.type;
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Manage Mathematical Relationships"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl border border-line bg-panel shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-line px-5 py-3.5 bg-field/30">
          <div>
            <h2 className="text-sm font-bold text-ink flex items-center gap-2">
              <Link2 className="h-4 w-4 text-accent" />
              <span>Link Mathematical Objects</span>
            </h2>
            <p className="text-[11px] text-muted">
              Connect Block #{sourceBlock.position + 1} ({sourceBlock.type.toUpperCase()}) with other workspace entities
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close dialog"
            className="grid h-7 w-7 place-items-center rounded-lg text-muted hover:bg-field hover:text-ink transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Current Relationships */}
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-muted mb-2">
              Active Relationships ({currentRelationships.length})
            </div>
            {currentRelationships.length === 0 ? (
              <p className="rounded-xl border border-dashed border-line p-3 text-center text-xs text-muted">
                No active links for this object. Establish mathematical connections below.
              </p>
            ) : (
              <div className="space-y-1.5">
                {currentRelationships.map((r) => {
                  const target = allBlocks.find((b) => b.id === r.targetBlockId);
                  const targetLabel = target ? getBlockSummary(target) : r.targetBlockId;
                  return (
                    <div
                      key={r.targetBlockId + r.type}
                      className="flex items-center justify-between gap-2 rounded-xl border border-line bg-field/40 px-3 py-2 text-xs"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="rounded bg-accent/15 px-2 py-0.5 text-[10px] font-bold text-accent shrink-0">
                          {r.type}
                        </span>
                        <ArrowRight className="h-3 w-3 text-muted shrink-0" />
                        <span className="truncate text-ink font-medium">
                          {targetLabel}
                        </span>
                        {r.label && (
                          <span className="text-[10px] text-muted italic shrink-0">
                            ({r.label})
                          </span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemoveRelationship(sourceBlock.id, r.targetBlockId)}
                        title="Remove link"
                        className="text-muted hover:text-danger p-1 rounded transition-colors"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Create New Link Form */}
          <form onSubmit={handleCreate} className="space-y-3 rounded-xl border border-line bg-field/20 p-4">
            <div className="text-xs font-bold text-ink">Establish New Link</div>

            {/* Target Object Selector */}
            <div>
              <label className="block text-[11px] font-semibold text-muted mb-1">
                Target Object
              </label>
              <select
                value={selectedTargetId}
                onChange={(e) => setSelectedTargetId(e.target.value)}
                className="w-full rounded-xl border border-line bg-field px-3 py-1.5 text-xs text-ink focus:border-accent focus:outline-none"
                required
              >
                <option value="">Select an object in this notebook...</option>
                {availableTargets.map((b) => (
                  <option key={b.id} value={b.id}>
                    #{b.position + 1} [{b.type.toUpperCase()}] {getBlockSummary(b)}
                  </option>
                ))}
              </select>
            </div>

            {/* Link Type Selector */}
            <div>
              <label className="block text-[11px] font-semibold text-muted mb-1">
                Relationship Type
              </label>
              <select
                value={relType}
                onChange={(e) => setRelType(e.target.value as RelationshipType)}
                className="w-full rounded-xl border border-line bg-field px-3 py-1.5 text-xs text-ink focus:border-accent focus:outline-none"
              >
                {RELATIONSHIP_TYPES.map((rt) => (
                  <option key={rt.type} value={rt.type}>
                    {rt.label} — {rt.desc}
                  </option>
                ))}
              </select>
            </div>

            {/* Optional Context Label */}
            <div>
              <label className="block text-[11px] font-semibold text-muted mb-1">
                Description / Context (Optional)
              </label>
              <input
                type="text"
                value={customLabel}
                onChange={(e) => setCustomLabel(e.target.value)}
                placeholder="e.g. Primary curve, Step 3 factor, Analytical solution..."
                className="w-full rounded-xl border border-line bg-field px-3 py-1.5 text-xs text-ink placeholder:text-muted focus:border-accent focus:outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={!selectedTargetId}
              className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-accent px-4 py-2 text-xs font-bold text-accent-ink shadow-xs hover:opacity-90 disabled:opacity-40 transition-opacity"
            >
              <Check className="h-3.5 w-3.5" />
              <span>Link Objects</span>
            </button>
          </form>
        </div>

        {/* Footer */}
        <div className="border-t border-line bg-field/30 px-5 py-2.5 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-line bg-panel px-3 py-1 text-xs font-semibold text-ink hover:bg-field transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}

