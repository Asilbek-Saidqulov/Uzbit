'use client';

import { useState } from 'react';
import {
  ArrowLeft,
  Plus,
  Download,
  ListTree,
  Search,
  Check,
  Tag,
  Share2,
} from 'lucide-react';

interface NotebookHeaderProps {
  title: string;
  onTitleChange: (newTitle: string) => void;
  subject?: string;
  onSubjectChange?: (newSubject: string) => void;
  blockCount: number;
  savedStatus: 'saved' | 'saving';
  outlineOpen: boolean;
  onToggleOutline: () => void;
  searchOpen: boolean;
  onToggleSearch: () => void;
  onOpenAddModal: () => void;
  onExportMarkdown: () => void;
  onExportJSON: () => void;
  onBack: () => void;
}

export default function NotebookHeader({
  title,
  onTitleChange,
  subject = 'Mathematics',
  onSubjectChange,
  blockCount,
  savedStatus,
  outlineOpen,
  onToggleOutline,
  searchOpen,
  onToggleSearch,
  onOpenAddModal,
  onExportMarkdown,
  onExportJSON,
  onBack,
}: NotebookHeaderProps) {
  const [exportOpen, setExportOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleShare = () => {
    try {
      navigator.clipboard?.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } catch {}
  };

  return (
    <header className="flex h-13 shrink-0 items-center justify-between border-b border-line bg-panel px-3 sm:px-5 shadow-xs select-none">
      {/* Left: Navigation Back + Title + Subject */}
      <div className="flex items-center gap-2.5 sm:gap-3.5 overflow-hidden flex-1 mr-2">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 rounded-lg border border-line bg-field/60 px-2.5 py-1 text-xs font-semibold text-muted hover:border-accent/40 hover:text-ink transition-colors shrink-0 focus-ring"
          title="Return to Workspace"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Workspace</span>
        </button>

        <div className="h-4 w-px bg-line shrink-0" />

        <div className="flex flex-col min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={title}
              onChange={(e) => onTitleChange(e.target.value)}
              className="bg-transparent text-sm font-bold text-ink focus:outline-none focus:border-b focus:border-accent truncate"
              placeholder="Untitled Mathematical Workspace..."
            />
            {onSubjectChange && (
              <span className="hidden md:inline-flex items-center rounded-md border border-line/60 bg-field/50 px-2 py-0.5 text-[10px] font-semibold text-muted">
                {subject}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 text-[10px] text-muted">
            <span>{blockCount} structured objects</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  savedStatus === 'saved' ? 'bg-emerald-400' : 'bg-amber-400 animate-pulse'
                }`}
              />
              <span>{savedStatus === 'saved' ? 'Saved' : 'Saving...'}</span>
            </span>
          </div>
        </div>
      </div>

      {/* Right Controls: Search, Outline Toggle, Add Block, Export */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        {/* Search Toggle */}
        <button
          type="button"
          onClick={onToggleSearch}
          className={`grid h-8 w-8 place-items-center rounded-lg border transition-colors focus-ring ${
            searchOpen
              ? 'border-accent bg-accent/15 text-accent'
              : 'border-line/70 bg-field/50 text-muted hover:text-ink hover:bg-field'
          }`}
          title="Search within notebook"
          aria-label="Search within notebook"
        >
          <Search className="h-3.5 w-3.5" />
        </button>

        {/* Outline Navigator Toggle */}
        <button
          type="button"
          onClick={onToggleOutline}
          className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-semibold transition-colors focus-ring ${
            outlineOpen
              ? 'border-accent bg-accent/15 text-accent'
              : 'border-line/70 bg-field/50 text-muted hover:text-ink hover:bg-field'
          }`}
          title="Toggle Object Outline"
          aria-label="Toggle Object Outline"
        >
          <ListTree className="h-3.5 w-3.5" />
          <span className="hidden md:inline">Outline</span>
        </button>

        {/* Add Mathematical Object */}
        <button
          type="button"
          onClick={onOpenAddModal}
          className="flex items-center gap-1.5 rounded-xl bg-accent px-3 py-1.5 text-xs font-semibold text-accent-ink shadow-xs hover:opacity-90 transition-opacity focus-ring"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>Add Object</span>
        </button>

        {/* Share Button */}
        <button
          type="button"
          onClick={handleShare}
          className="hidden sm:grid h-8 w-8 place-items-center rounded-lg border border-line bg-field/50 text-muted hover:text-ink hover:border-accent/40 focus-ring"
          title="Copy link"
        >
          {copiedLink ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Share2 className="h-3.5 w-3.5" />}
        </button>

        {/* Export Menu */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setExportOpen(!exportOpen)}
            className="flex h-8 items-center gap-1 rounded-lg border border-line bg-field/50 px-2 text-xs font-semibold text-muted hover:text-ink hover:border-accent/40 focus-ring"
            title="Export Notebook"
          >
            <Download className="h-3.5 w-3.5" />
            <span className="hidden lg:inline">Export</span>
            <span className="text-[10px]">▾</span>
          </button>
          {exportOpen && (
            <div
              className="absolute right-0 top-9 z-50 flex w-40 flex-col overflow-hidden rounded-xl border border-line bg-panel py-1 shadow-2xl animate-modal"
              onMouseLeave={() => setExportOpen(false)}
            >
              <button
                type="button"
                onClick={() => {
                  onExportMarkdown();
                  setExportOpen(false);
                }}
                className="px-3.5 py-2 text-left text-xs font-medium text-ink hover:bg-field transition-colors"
              >
                Markdown Document (.md)
              </button>
              <button
                type="button"
                onClick={() => {
                  onExportJSON();
                  setExportOpen(false);
                }}
                className="px-3.5 py-2 text-left text-xs font-medium text-ink hover:bg-field transition-colors"
              >
                TIFspace Schema (.json)
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

