'use client';

import React from 'react';
import type { MathBlock, SectionContent } from '@/core/notebook/types';
import {
  FolderTree,
  ChevronDown,
  ChevronRight,
  Trash2,
  Copy,
  ChevronUp,
} from 'lucide-react';

interface SectionBlockCardProps {
  block: MathBlock;
  childCount?: number;
  isFirst: boolean;
  isLast: boolean;
  onUpdate: (patch: Partial<SectionContent>) => void;
  onMove: (dir: -1 | 1) => void;
  onDuplicate: () => void;
  onDelete: () => void;
}

export default function SectionBlockCard({
  block,
  childCount = 0,
  isFirst,
  isLast,
  onUpdate,
  onMove,
  onDuplicate,
  onDelete,
}: SectionBlockCardProps) {
  const content = block.content as SectionContent;
  const isCollapsed = !!content.isCollapsed;

  const toggleCollapse = () => {
    onUpdate({ isCollapsed: !isCollapsed });
  };

  return (
    <div
      id={`block-${block.id}`}
      className="group rounded-2xl border-2 border-line/80 bg-field/30 shadow-xs transition-all hover:border-accent/40"
    >
      <div className="flex flex-wrap items-center justify-between gap-3 p-4">
        {/* Toggle & Title */}
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <button
            type="button"
            onClick={toggleCollapse}
            aria-label={isCollapsed ? 'Expand section' : 'Collapse section'}
            className="grid h-8 w-8 place-items-center rounded-xl border border-line bg-panel text-muted hover:text-accent hover:border-accent transition-colors"
          >
            {isCollapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronDown className="h-4 w-4" />
            )}
          </button>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="flex items-center gap-1 rounded bg-field px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-muted border border-line">
                <FolderTree className="h-3 w-3 text-accent" />
                <span>Section</span>
              </span>
              {childCount > 0 && (
                <span className="rounded bg-panel px-2 py-0.5 text-[10px] font-semibold text-muted border border-line">
                  {childCount} {childCount === 1 ? 'object' : 'objects'}
                </span>
              )}
            </div>
            <input
              type="text"
              value={content.title || ''}
              onChange={(e) => onUpdate({ title: e.target.value })}
              placeholder="Section Topic (e.g. Part I: Polynomial Roots & Extrema)"
              className="w-full bg-transparent text-base font-extrabold text-ink placeholder:text-muted focus:outline-none"
            />
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
          <button
            type="button"
            onClick={() => onMove(-1)}
            disabled={isFirst}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move section up"
          >
            <ChevronUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onMove(1)}
            disabled={isLast}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move section down"
          >
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDuplicate}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink"
            title="Duplicate section"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-danger"
            title="Delete section"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Description / Subtext if not collapsed */}
      {!isCollapsed && (
        <div className="px-4 pb-3 -mt-1">
          <input
            type="text"
            value={content.description || ''}
            onChange={(e) => onUpdate({ description: e.target.value })}
            placeholder="Optional section description or summary..."
            className="w-full rounded-lg border border-transparent bg-transparent px-2 py-1 text-xs text-muted hover:border-line focus:border-line focus:bg-panel focus:outline-none"
          />
        </div>
      )}
    </div>
  );
}

