'use client';

import { useMemo, useState } from 'react';
import type { EmbeddedGraphContent } from '@/core/notebook/types';
import { mathEngine } from '@/core/math/engine';
import { LineChart, Sliders, Eye, EyeOff, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import MathView from '@/components/MathView';

interface Props {
  content: EmbeddedGraphContent;
  onChange: (updated: Partial<EmbeddedGraphContent>) => void;
  editable?: boolean;
}

export default function EmbeddedGraphBlock({ content, onChange, editable = true }: Props) {
  const [zoom, setZoom] = useState(1);
  const [exprInput, setExprInput] = useState(content.expression || 'x^2 - 4');
  const [showControls, setShowControls] = useState(false);

  const xMin = (content.viewport?.xMin ?? -6) / zoom;
  const xMax = (content.viewport?.xMax ?? 6) / zoom;
  const yMin = (content.viewport?.yMin ?? -6) / zoom;
  const yMax = (content.viewport?.yMax ?? 6) / zoom;

  const width = 640;
  const height = 320;

  const toPxX = (x: number) => ((x - xMin) / (xMax - xMin)) * width;
  const toPxY = (y: number) => height - ((y - yMin) / (yMax - yMin)) * height;

  // Evaluate function curve points
  const { pathD, derivPathD, integralPolygon } = useMemo(() => {
    const samples = 200;
    const dx = (xMax - xMin) / samples;
    const pts: [number, number][] = [];
    const derivPts: [number, number][] = [];

    // Numerical differentiation step
    const h = 0.001;

    for (let i = 0; i <= samples; i++) {
      const x = xMin + i * dx;
      const res = mathEngine.evaluate(content.expression || 'x', { variables: { x } });
      if (res.status === 'success' && Number.isFinite(res.approximation)) {
        pts.push([x, res.approximation]);

        if (content.derivativeVisible) {
          const resH1 = mathEngine.evaluate(content.expression || 'x', { variables: { x: x + h } });
          const resH0 = mathEngine.evaluate(content.expression || 'x', { variables: { x: x - h } });
          if (resH1.status === 'success' && resH0.status === 'success') {
            const dy = (resH1.approximation - resH0.approximation) / (2 * h);
            derivPts.push([x, dy]);
          }
        }
      }
    }

    // Build SVG path string
    const buildD = (points: [number, number][]) => {
      let d = '';
      for (let i = 0; i < points.length; i++) {
        const px = toPxX(points[i][0]);
        const py = toPxY(points[i][1]);
        if (!Number.isFinite(px) || !Number.isFinite(py) || py < -100 || py > height + 100) {
          continue;
        }
        if (!d) d = `M ${px} ${py}`;
        else d += ` L ${px} ${py}`;
      }
      return d;
    };

    // Build integral shaded polygon if enabled
    let polyD = '';
    if (content.integralVisible && content.integralBounds) {
      const a = content.integralBounds.a;
      const b = content.integralBounds.b;
      const intSamples = 60;
      const intDx = (b - a) / intSamples;
      const intPts: [number, number][] = [];

      for (let i = 0; i <= intSamples; i++) {
        const x = a + i * intDx;
        const res = mathEngine.evaluate(content.expression || 'x', { variables: { x } });
        if (res.status === 'success' && Number.isFinite(res.approximation)) {
          intPts.push([x, res.approximation]);
        }
      }

      if (intPts.length > 0) {
        polyD = `M ${toPxX(a)} ${toPxY(0)}`;
        for (const pt of intPts) {
          polyD += ` L ${toPxX(pt[0])} ${toPxY(pt[1])}`;
        }
        polyD += ` L ${toPxX(b)} ${toPxY(0)} Z`;
      }
    }

    return {
      pathD: buildD(pts),
      derivPathD: buildD(derivPts),
      integralPolygon: polyD,
    };
  }, [content.expression, content.derivativeVisible, content.integralVisible, content.integralBounds, xMin, xMax, yMin, yMax, width, height]);

  // Axes coordinates
  const originX = toPxX(0);
  const originY = toPxY(0);

  const handleApplyExpr = () => {
    onChange({ expression: exprInput });
  };

  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-panel shadow-sm">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between border-b border-line bg-field/50 px-4 py-2.5 text-xs">
        <div className="flex items-center gap-2">
          <LineChart className="h-4 w-4 text-accent" />
          <span className="font-bold text-ink">Embedded Graph:</span>
          <span className="font-mono text-xs text-accent">
            <MathView math={`y = ${content.expression || 'x'}`} />
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Zoom controls */}
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(4, z * 1.25))}
            className="grid h-7 w-7 place-items-center rounded-lg border border-line text-muted hover:bg-panel hover:text-ink"
            title="Zoom in"
          >
            <ZoomIn className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.25, z / 1.25))}
            className="grid h-7 w-7 place-items-center rounded-lg border border-line text-muted hover:bg-panel hover:text-ink"
            title="Zoom out"
          >
            <ZoomOut className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoom(1)}
            className="grid h-7 w-7 place-items-center rounded-lg border border-line text-muted hover:bg-panel hover:text-ink"
            title="Reset zoom"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>

          {editable && (
            <button
              type="button"
              onClick={() => setShowControls(!showControls)}
              className={`flex items-center gap-1 rounded-lg border px-2 py-1 font-semibold transition-colors ${
                showControls
                  ? 'border-accent bg-accent/15 text-accent'
                  : 'border-line text-muted hover:bg-panel hover:text-ink'
              }`}
            >
              <Sliders className="h-3 w-3" />
              <span>Configure</span>
            </button>
          )}
        </div>
      </div>

      {/* Embedded Controls Drawer */}
      {editable && showControls && (
        <div className="flex flex-wrap items-center gap-3 border-b border-line bg-field/30 px-4 py-2.5 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-medium text-muted">Expression:</span>
            <input
              type="text"
              value={exprInput}
              onChange={(e) => setExprInput(e.target.value)}
              onBlur={handleApplyExpr}
              onKeyDown={(e) => e.key === 'Enter' && handleApplyExpr()}
              placeholder="e.g. x^2 - 4"
              className="rounded-lg border border-line bg-panel px-2.5 py-1 font-mono text-xs text-ink focus:border-accent focus:outline-none"
            />
          </div>

          <label className="flex cursor-pointer items-center gap-1.5 font-medium text-muted hover:text-ink">
            <input
              type="checkbox"
              checked={content.derivativeVisible ?? false}
              onChange={(e) => onChange({ derivativeVisible: e.target.checked })}
              className="rounded text-accent focus:ring-0"
            />
            <span className="text-emerald-400">Show Derivative f′(x)</span>
          </label>

          <label className="flex cursor-pointer items-center gap-1.5 font-medium text-muted hover:text-ink">
            <input
              type="checkbox"
              checked={content.integralVisible ?? false}
              onChange={(e) =>
                onChange({
                  integralVisible: e.target.checked,
                  integralBounds: content.integralBounds || { a: 0, b: 2 },
                })
              }
              className="rounded text-accent focus:ring-0"
            />
            <span className="text-blue-400">Shaded Area [0, 2]</span>
          </label>
        </div>
      )}

      {/* SVG Canvas Plotter */}
      <div className="relative w-full overflow-hidden bg-canvas/60">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="h-64 w-full select-none"
          preserveAspectRatio="none"
        >
          {/* Grid lines */}
          {[-4, -2, 2, 4].map((gridX) => (
            <line
              key={`gx-${gridX}`}
              x1={toPxX(gridX)}
              y1={0}
              x2={toPxX(gridX)}
              y2={height}
              stroke="currentColor"
              className="stroke-line/30"
              strokeDasharray="2,2"
            />
          ))}
          {[-4, -2, 2, 4].map((gridY) => (
            <line
              key={`gy-${gridY}`}
              x1={0}
              y1={toPxY(gridY)}
              x2={width}
              y2={toPxY(gridY)}
              stroke="currentColor"
              className="stroke-line/30"
              strokeDasharray="2,2"
            />
          ))}

          {/* Coordinate Axes */}
          <line
            x1={0}
            y1={originY}
            x2={width}
            y2={originY}
            stroke="currentColor"
            className="stroke-line"
            strokeWidth="1.5"
          />
          <line
            x1={originX}
            y1={0}
            x2={originX}
            y2={height}
            stroke="currentColor"
            className="stroke-line"
            strokeWidth="1.5"
          />

          {/* Shaded Integral Polygon */}
          {integralPolygon && (
            <path d={integralPolygon} fill="#3b82f6" fillOpacity="0.25" />
          )}

          {/* Function Curve */}
          {pathD && (
            <path
              d={pathD}
              fill="none"
              stroke="#60a5fa"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}

          {/* Derivative Curve */}
          {content.derivativeVisible && derivPathD && (
            <path
              d={derivPathD}
              fill="none"
              stroke="#10b981"
              strokeWidth="2"
              strokeDasharray="4,3"
              strokeLinecap="round"
            />
          )}
        </svg>

        {/* Legend */}
        <div className="absolute bottom-2 right-2 flex items-center gap-2 rounded-lg border border-line bg-panel/90 px-2.5 py-1 text-[10px] shadow-sm backdrop-blur">
          <span className="flex items-center gap-1 text-blue-400">
            <span className="h-1.5 w-3 rounded-full bg-blue-400 inline-block" />
            <span>f(x)</span>
          </span>
          {content.derivativeVisible && (
            <span className="flex items-center gap-1 text-emerald-400">
              <span className="h-1.5 w-3 rounded-full bg-emerald-400 inline-block" />
              <span>f′(x)</span>
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
