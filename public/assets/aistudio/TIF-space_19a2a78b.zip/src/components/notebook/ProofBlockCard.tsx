'use client';

import React, { useState } from 'react';
import type { MathBlock, ProofContent, ProofStep } from '@/core/notebook/types';
import MathView from '@/components/MathView';
import {
  ShieldCheck,
  Plus,
  Trash2,
  Copy,
  Link2,
  ChevronUp,
  ChevronDown,
  CheckCircle2,
  Award,
} from 'lucide-react';

interface ProofBlockCardProps {
  block: MathBlock;
  isFirst: boolean;
  isLast: boolean;
  onUpdate: (patch: Partial<ProofContent>) => void;
  onUpdateMetadata: (patch: Partial<MathBlock['metadata']>) => void;
  onMove: (dir: -1 | 1) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onOpenLinkModal: () => void;
  onJumpToBlock: (targetBlockId: string) => void;
}

export default function ProofBlockCard({
  block,
  isFirst,
  isLast,
  onUpdate,
  onUpdateMetadata,
  onMove,
  onDuplicate,
  onDelete,
  onOpenLinkModal,
  onJumpToBlock,
}: ProofBlockCardProps) {
  const content = block.content as ProofContent;
  const steps = content.steps || [];

  const handleAddStep = () => {
    const newStep: ProofStep = {
      id: `ps-${Date.now()}`,
      expr: '',
      reason: 'Deductive step or theorem application',
      verified: true,
    };
    onUpdate({ steps: [...steps, newStep] });
  };

  const handleUpdateStep = (index: number, patch: Partial<ProofStep>) => {
    const nextSteps = steps.map((s, i) => (i === index ? { ...s, ...patch } : s));
    onUpdate({ steps: nextSteps });
  };

  const handleRemoveStep = (index: number) => {
    if (steps.length <= 1) return;
    const nextSteps = steps.filter((_, i) => i !== index);
    onUpdate({ steps: nextSteps });
  };

  return (
    <div
      id={`block-${block.id}`}
      className="group rounded-2xl border border-line bg-panel shadow-xs transition-all hover:border-emerald-500/40 hover:shadow-sm"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 bg-field/30 px-4 py-2.5 rounded-t-2xl">
        <div className="flex items-center gap-2.5 flex-wrap">
          <span className="flex items-center gap-1.5 rounded-md border border-emerald-500/30 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-400">
            <ShieldCheck className="h-3 w-3" />
            <span>Formal Proof</span>
            <span className="opacity-60">#{block.position + 1}</span>
          </span>

          <input
            type="text"
            value={block.metadata?.label || ''}
            onChange={(e) => onUpdateMetadata({ label: e.target.value })}
            placeholder="Proof Title (e.g. Fundamental Identity)"
            className="rounded border border-transparent bg-transparent px-1.5 py-0.5 text-xs font-semibold text-ink hover:border-line focus:border-emerald-500 focus:bg-field focus:outline-none"
          />

          {/* Relationship Pills */}
          {block.relationships && block.relationships.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap">
              {block.relationships.map((rel) => (
                <button
                  key={rel.targetBlockId + rel.type}
                  type="button"
                  onClick={() => onJumpToBlock(rel.targetBlockId)}
                  className="flex items-center gap-1 rounded-md border border-line bg-panel px-2 py-0.5 text-[10px] font-medium text-muted hover:border-accent hover:text-ink transition-colors"
                  title={`Jump to linked object (${rel.type})`}
                >
                  <Link2 className="h-2.5 w-2.5 text-accent" />
                  <span className="capitalize">{rel.type}:</span>
                  <span className="font-semibold">{rel.label || 'Target'}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
          <button
            type="button"
            onClick={onOpenLinkModal}
            title="Link to another mathematical object"
            className="flex items-center gap-1 rounded-md border border-line bg-field px-2 py-1 text-[11px] font-medium text-muted hover:border-emerald-500 hover:text-ink transition-colors"
          >
            <Link2 className="h-3 w-3 text-emerald-400" />
            <span>Link</span>
          </button>

          <button
            type="button"
            onClick={() => onMove(-1)}
            disabled={isFirst}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move up"
          >
            <ChevronUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onMove(1)}
            disabled={isLast}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move down"
          >
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDuplicate}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink"
            title="Duplicate proof"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-danger"
            title="Delete proof"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 space-y-4">
        {/* Theorem / Claim */}
        <div className="rounded-xl border border-line/80 bg-field/30 p-3">
          <label className="block text-[10px] uppercase font-bold tracking-wider text-emerald-400 mb-1">
            Theorem / Proposition Statement
          </label>
          <input
            type="text"
            value={content.theorem || ''}
            onChange={(e) => onUpdate({ theorem: e.target.value })}
            placeholder="e.g. Fundamental Theorem of Calculus or a^2 + b^2 = c^2"
            className="w-full bg-transparent text-sm font-semibold text-ink placeholder:text-muted focus:outline-none"
          />
        </div>

        {/* Steps List */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between text-[11px] font-bold text-muted uppercase tracking-wider">
            <span>Inferential Steps ({steps.length})</span>
            <button
              type="button"
              onClick={handleAddStep}
              className="flex items-center gap-1 font-semibold text-emerald-400 hover:underline capitalize"
            >
              <Plus className="h-3 w-3" />
              <span>Add Step</span>
            </button>
          </div>

          {steps.map((step, idx) => (
            <div
              key={step.id || idx}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 rounded-xl border border-line/60 bg-field/20 p-2.5"
            >
              {/* Step Number */}
              <div className="flex items-center gap-2 shrink-0">
                <span className="grid h-5 w-5 place-items-center rounded-full bg-emerald-500/20 text-[10px] font-bold text-emerald-400">
                  {idx + 1}
                </span>
                <button
                  type="button"
                  onClick={() => handleUpdateStep(idx, { verified: !step.verified })}
                  title={step.verified ? 'Verified inferential step' : 'Mark as verified'}
                  className="text-emerald-400 hover:opacity-80"
                >
                  <CheckCircle2 className={`h-4 w-4 ${step.verified ? 'text-emerald-400' : 'text-muted/40'}`} />
                </button>
              </div>

              {/* Formula input */}
              <div className="flex-1 min-w-0">
                <input
                  type="text"
                  value={step.expr}
                  onChange={(e) => handleUpdateStep(idx, { expr: e.target.value })}
                  placeholder="Formula (e.g. \int a\,dx = a x + C)"
                  className="w-full rounded-lg border border-line bg-panel px-2.5 py-1 font-mono text-xs text-ink focus:border-emerald-500 focus:outline-none"
                />
                {step.expr && (
                  <div className="mt-1 px-1 overflow-x-auto text-xs text-ink">
                    <MathView math={step.expr} />
                  </div>
                )}
              </div>

              {/* Justification input */}
              <div className="w-full sm:w-56 shrink-0 flex items-center gap-1.5">
                <input
                  type="text"
                  value={step.reason || ''}
                  onChange={(e) => handleUpdateStep(idx, { reason: e.target.value })}
                  placeholder="Axiom / Justification"
                  className="w-full rounded-lg border border-line bg-panel px-2 py-1 text-xs text-muted focus:border-emerald-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => handleRemoveStep(idx)}
                  disabled={steps.length <= 1}
                  className="text-muted hover:text-danger p-1 rounded disabled:opacity-20"
                  title="Remove step"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Conclusion / Q.E.D. */}
        <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3 flex items-start gap-2.5">
          <Award className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <label className="block text-[10px] uppercase font-bold tracking-wider text-emerald-400 mb-1">
              Conclusion / Q.E.D.
            </label>
            <input
              type="text"
              value={content.conclusion || ''}
              onChange={(e) => onUpdate({ conclusion: e.target.value })}
              placeholder="Q.E.D. The statement follows by induction / algebraic substitution."
              className="w-full bg-transparent text-xs text-ink font-medium focus:outline-none"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

