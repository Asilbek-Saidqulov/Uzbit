'use client';

import React from 'react';
import type { MathBlock, EmbeddedGraphContent } from '@/core/notebook/types';
import EmbeddedGraphBlock from '@/components/notebook/EmbeddedGraphBlock';
import {
  LineChart,
  Copy,
  Trash2,
  Link2,
  ChevronUp,
  ChevronDown,
  ExternalLink,
} from 'lucide-react';

interface GraphBlockCardProps {
  block: MathBlock;
  isFirst: boolean;
  isLast: boolean;
  onUpdate: (patch: Partial<EmbeddedGraphContent>) => void;
  onUpdateMetadata: (patch: Partial<MathBlock['metadata']>) => void;
  onMove: (dir: -1 | 1) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onOpenLinkModal: () => void;
  onJumpToBlock: (targetBlockId: string) => void;
  onOpenInLab?: (expression: string) => void;
}

export default function GraphBlockCard({
  block,
  isFirst,
  isLast,
  onUpdate,
  onUpdateMetadata,
  onMove,
  onDuplicate,
  onDelete,
  onOpenLinkModal,
  onJumpToBlock,
  onOpenInLab,
}: GraphBlockCardProps) {
  const content = block.content as EmbeddedGraphContent;

  return (
    <div
      id={`block-${block.id}`}
      className="group rounded-2xl border border-line bg-panel shadow-xs transition-all hover:border-blue-500/40 hover:shadow-sm"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 bg-field/30 px-4 py-2.5 rounded-t-2xl">
        <div className="flex items-center gap-2.5 flex-wrap">
          <span className="flex items-center gap-1.5 rounded-md border border-blue-500/30 bg-blue-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-blue-400">
            <LineChart className="h-3 w-3" />
            <span>Interactive Graph</span>
            <span className="opacity-60">#{block.position + 1}</span>
          </span>

          <input
            type="text"
            value={block.metadata?.label || ''}
            onChange={(e) => onUpdateMetadata({ label: e.target.value })}
            placeholder="Plot Label (e.g. Parabolic Trajectory)"
            className="rounded border border-transparent bg-transparent px-1.5 py-0.5 text-xs font-semibold text-ink hover:border-line focus:border-blue-500 focus:bg-field focus:outline-none"
          />

          {/* Relationship Pills */}
          {block.relationships && block.relationships.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap">
              {block.relationships.map((rel) => (
                <button
                  key={rel.targetBlockId + rel.type}
                  type="button"
                  onClick={() => onJumpToBlock(rel.targetBlockId)}
                  className="flex items-center gap-1 rounded-md border border-line bg-panel px-2 py-0.5 text-[10px] font-medium text-muted hover:border-accent hover:text-ink transition-colors"
                  title={`Jump to linked object (${rel.type})`}
                >
                  <Link2 className="h-2.5 w-2.5 text-accent" />
                  <span className="capitalize">{rel.type}:</span>
                  <span className="font-semibold">{rel.label || 'Target'}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
          {onOpenInLab && content.expression && (
            <button
              type="button"
              onClick={() => onOpenInLab(content.expression)}
              title="Open full interactive plot in Visual Lab"
              className="flex items-center gap-1 rounded-md border border-line bg-field px-2 py-1 text-[11px] font-medium text-accent hover:border-accent hover:text-ink transition-colors"
            >
              <ExternalLink className="h-3 w-3" />
              <span>Visual Lab</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenLinkModal}
            title="Link to another mathematical object"
            className="flex items-center gap-1 rounded-md border border-line bg-field px-2 py-1 text-[11px] font-medium text-muted hover:border-blue-500 hover:text-ink transition-colors"
          >
            <Link2 className="h-3 w-3 text-blue-400" />
            <span>Link</span>
          </button>

          <button
            type="button"
            onClick={() => onMove(-1)}
            disabled={isFirst}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move up"
          >
            <ChevronUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onMove(1)}
            disabled={isLast}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move down"
          >
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDuplicate}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink"
            title="Duplicate graph"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-danger"
            title="Delete graph"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Main Graph Body */}
      <div className="p-4">
        <EmbeddedGraphBlock content={content} onChange={onUpdate} />
      </div>
    </div>
  );
}

