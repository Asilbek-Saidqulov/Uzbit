'use client';

import React, { useState } from 'react';
import type { MathBlock, MathBlockContent, BlockRelationship } from '@/core/notebook/types';
import MathView from '@/components/MathView';
import { mathEngine } from '@/core/math/engine';
import {
  Copy,
  Check,
  LineChart,
  Edit2,
  CheckCircle2,
  Link2,
  Trash2,
  ChevronUp,
  ChevronDown,
  Sparkles,
} from 'lucide-react';

interface MathBlockCardProps {
  block: MathBlock;
  isFirst: boolean;
  isLast: boolean;
  onUpdate: (patch: Partial<MathBlockContent>) => void;
  onUpdateMetadata: (patch: Partial<MathBlock['metadata']>) => void;
  onMove: (dir: -1 | 1) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onOpenLinkModal: () => void;
  onJumpToBlock: (targetBlockId: string) => void;
  onPlot?: (latex: string) => void;
}

export default function MathBlockCard({
  block,
  isFirst,
  isLast,
  onUpdate,
  onUpdateMetadata,
  onMove,
  onDuplicate,
  onDelete,
  onOpenLinkModal,
  onJumpToBlock,
  onPlot,
}: MathBlockCardProps) {
  const content = block.content as MathBlockContent;
  const [isEditing, setIsEditing] = useState(!content.latex);
  const [copied, setCopied] = useState(false);

  // Evaluate for live preview if expression has numbers
  const evalResult = content.showEvaluation
    ? mathEngine.evaluate(content.latex || '0')
    : null;

  const handleCopy = () => {
    if (!content.latex) return;
    navigator.clipboard?.writeText(content.latex);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const hasPlotVariables = content.latex && /[xy]/.test(content.latex);

  return (
    <div
      id={`block-${block.id}`}
      className="group rounded-2xl border border-line bg-panel shadow-xs transition-all hover:border-accent/40 hover:shadow-sm"
    >
      {/* Object Card Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line/60 bg-field/30 px-4 py-2.5 rounded-t-2xl">
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Entity Badge */}
          <span className="flex items-center gap-1.5 rounded-md border border-accent/30 bg-accent/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent">
            <Sparkles className="h-3 w-3" />
            <span>Equation</span>
            <span className="opacity-60">#{block.position + 1}</span>
          </span>

          {/* Label / Name */}
          <input
            type="text"
            value={block.metadata?.label || content.name || ''}
            onChange={(e) => {
              onUpdateMetadata({ label: e.target.value });
              onUpdate({ name: e.target.value });
            }}
            placeholder="Label (e.g. f(x) or Quadratic Formula)"
            className="rounded border border-transparent bg-transparent px-1.5 py-0.5 text-xs font-semibold text-ink hover:border-line focus:border-accent focus:bg-field focus:outline-none"
          />

          {/* Relationship Pills */}
          {block.relationships && block.relationships.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap">
              {block.relationships.map((rel) => (
                <button
                  key={rel.targetBlockId + rel.type}
                  type="button"
                  onClick={() => onJumpToBlock(rel.targetBlockId)}
                  className="flex items-center gap-1 rounded-md border border-line bg-panel px-2 py-0.5 text-[10px] font-medium text-muted hover:border-accent hover:text-ink transition-colors"
                  title={`Jump to linked object (${rel.type})`}
                >
                  <Link2 className="h-2.5 w-2.5 text-accent" />
                  <span className="capitalize">{rel.type}:</span>
                  <span className="font-semibold">{rel.label || 'Target'}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
          <button
            type="button"
            onClick={onOpenLinkModal}
            title="Link to another mathematical object"
            className="flex items-center gap-1 rounded-md border border-line bg-field px-2 py-1 text-[11px] font-medium text-muted hover:border-accent hover:text-ink transition-colors"
          >
            <Link2 className="h-3 w-3 text-accent" />
            <span>Link</span>
          </button>

          <button
            type="button"
            onClick={() => onMove(-1)}
            disabled={isFirst}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move up"
          >
            <ChevronUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onMove(1)}
            disabled={isLast}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink disabled:opacity-20"
            title="Move down"
          >
            <ChevronDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDuplicate}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-ink"
            title="Duplicate equation"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={onDelete}
            className="grid h-6 w-6 place-items-center rounded text-muted hover:text-danger"
            title="Delete equation"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-4 space-y-3">
        {isEditing ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] text-muted">
              <span>Enter standard LaTeX equation:</span>
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="font-semibold text-accent hover:underline flex items-center gap-1"
              >
                <Check className="h-3 w-3" />
                <span>Render Math</span>
              </button>
            </div>
            <textarea
              rows={2}
              value={content.latex}
              onChange={(e) => onUpdate({ latex: e.target.value })}
              placeholder="e.g. f(x) = x^2 - 4   or   x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}"
              className="w-full rounded-xl border border-line bg-field px-3 py-2 font-mono text-xs text-ink focus:border-accent focus:outline-none"
              autoFocus
            />
          </div>
        ) : (
          <div
            onClick={() => setIsEditing(true)}
            className="cursor-pointer rounded-xl border border-dashed border-transparent hover:border-line/70 p-3 transition-colors text-center"
            title="Click to edit LaTeX"
          >
            <div className="overflow-x-auto py-2 text-lg text-ink font-serif">
              <MathView math={content.latex || 'f(x) = ...'} displayMode />
            </div>
          </div>
        )}

        {/* Optional Description / Domain Constraints */}
        <div className="flex items-center gap-2 text-[11px]">
          <span className="text-muted font-medium">Domain / Notes:</span>
          <input
            type="text"
            value={content.description || ''}
            onChange={(e) => onUpdate({ description: e.target.value })}
            placeholder="e.g. x ∈ ℝ, a ≠ 0, or roots at ±2"
            className="flex-1 rounded border border-transparent bg-transparent px-1.5 py-0.5 text-ink hover:border-line focus:border-accent focus:bg-field focus:outline-none"
          />
        </div>

        {/* Live Evaluation Preview */}
        {evalResult?.status === 'success' && (
          <div className="flex items-center justify-between rounded-xl border border-line/60 bg-field/30 px-3 py-2 text-xs">
            <span className="text-[11px] font-semibold text-muted">Numerical Evaluation:</span>
            <div className="flex items-center gap-2 font-mono">
              <span className="font-bold text-accent">
                {evalResult.exact || evalResult.formatted}
              </span>
              {evalResult.exact && evalResult.exact !== evalResult.formatted && (
                <span className="text-muted text-[11px]">(≈ {evalResult.formatted})</span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Contextual Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-t border-line/50 bg-field/20 px-4 py-2 rounded-b-2xl text-[11px]">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center gap-1 font-semibold text-muted hover:text-ink transition-colors"
          >
            <Edit2 className="h-3 w-3" />
            <span>{isEditing ? 'Done' : 'Edit LaTeX'}</span>
          </button>

          <div className="h-3 w-px bg-line" />

          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1 font-medium text-muted hover:text-ink transition-colors"
          >
            {copied ? <CheckCircle2 className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
            <span>{copied ? 'Copied LaTeX' : 'Copy LaTeX'}</span>
          </button>

          {hasPlotVariables && onPlot && (
            <>
              <div className="h-3 w-px bg-line" />
              <button
                type="button"
                onClick={() => onPlot(content.latex)}
                className="flex items-center gap-1 font-semibold text-accent hover:underline transition-colors"
              >
                <LineChart className="h-3 w-3" />
                <span>Plot in Visual Lab</span>
              </button>
            </>
          )}
        </div>

        <label className="flex items-center gap-1.5 text-muted cursor-pointer">
          <input
            type="checkbox"
            checked={content.showEvaluation !== false}
            onChange={(e) => onUpdate({ showEvaluation: e.target.checked })}
            className="rounded border-line text-accent focus:ring-accent"
          />
          <span>Auto-evaluate</span>
        </label>
      </div>
    </div>
  );
}

