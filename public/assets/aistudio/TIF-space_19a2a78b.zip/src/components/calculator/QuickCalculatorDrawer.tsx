'use client';

import { useState, useEffect, useRef } from 'react';
import { mathEngine, type AngleMode, type MathResult } from '@/core/math/engine';
import { appendMathBlockToActive } from '@/core/notebook/notebookStore';
import type { AppRoute } from '@/types/navigation';
import MathView from '@/components/MathView';
import {
  X,
  Copy,
  Check,
  LineChart,
  BookOpen,
  Delete,
  History,
  RotateCcw,
} from 'lucide-react';

interface QuickCalculatorDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (route: AppRoute, payload?: { expression?: string }) => void;
}

export default function QuickCalculatorDrawer({
  isOpen,
  onClose,
  onNavigate,
}: QuickCalculatorDrawerProps) {
  const [expression, setExpression] = useState('');
  const [angleMode, setAngleMode] = useState<AngleMode>('radians');
  const [precision, setPrecision] = useState(8);
  const [tab, setTab] = useState<'standard' | 'trig' | 'advanced'>('standard');
  const [copied, setCopied] = useState(false);
  const [evalResult, setEvalResult] = useState<MathResult | null>(null);
  const [lastAns, setLastAns] = useState<number | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  // Live evaluation
  useEffect(() => {
    if (!expression.trim()) {
      setEvalResult(null);
      return;
    }
    const vars: Record<string, number> = {};
    if (lastAns !== null) vars['ans'] = lastAns;
    const res = mathEngine.evaluate(expression, {
      angleMode,
      precision,
      variables: vars,
    });
    setEvalResult(res);
  }, [expression, angleMode, precision, lastAns]);

  const append = (str: string) => {
    setExpression((prev) => prev + str);
    inputRef.current?.focus();
  };

  const clear = () => {
    setExpression('');
    setEvalResult(null);
    inputRef.current?.focus();
  };

  const backspace = () => {
    setExpression((prev) => prev.slice(0, -1));
    inputRef.current?.focus();
  };

  const handleCalculate = () => {
    if (!expression.trim()) return;
    const vars: Record<string, number> = {};
    if (lastAns !== null) vars['ans'] = lastAns;
    const res = mathEngine.evaluate(expression, { angleMode, precision, variables: vars });
    setEvalResult(res);
    if (res.status === 'success') {
      setLastAns(res.approximation);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleInsertIntoNotebook = () => {
    if (!evalResult || evalResult.status !== 'success') return;
    const content = `${expression} = ${evalResult.exact || evalResult.formatted}`;
    appendMathBlockToActive(content);
    if (onNavigate) {
      onNavigate('workspace');
      onClose();
    }
  };

  const handlePlot = () => {
    if (onNavigate && expression.trim()) {
      onNavigate('lab', { expression });
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Quick Mathematical Calculator"
      className="fixed inset-0 z-50 flex justify-end"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Drawer Panel */}
      <div className="relative flex h-full w-full max-w-md flex-col border-l border-line bg-panel p-4 shadow-2xl z-10 animate-drawer">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-line">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-ink">
              Quick Calculator
            </span>
            <div className="flex rounded-md border border-line bg-field p-0.5 text-[10px]">
              <button
                type="button"
                onClick={() => setAngleMode('radians')}
                className={`px-2 py-0.5 font-bold rounded ${
                  angleMode === 'radians'
                    ? 'bg-accent text-accent-ink'
                    : 'text-muted hover:text-ink'
                }`}
              >
                RAD
              </button>
              <button
                type="button"
                onClick={() => setAngleMode('degrees')}
                className={`px-2 py-0.5 font-bold rounded ${
                  angleMode === 'degrees'
                    ? 'bg-accent text-accent-ink'
                    : 'text-muted hover:text-ink'
                }`}
              >
                DEG
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="grid h-7 w-7 place-items-center rounded-lg border border-line text-muted hover:text-ink hover:bg-field"
            aria-label="Close calculator"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Display screen */}
        <div className="mt-3 rounded-xl border border-line bg-field/60 p-3 shadow-inner space-y-2">
          <input
            ref={inputRef}
            type="text"
            value={expression}
            onChange={(e) => setExpression(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleCalculate();
              if (e.key === 'Escape') onClose();
            }}
            placeholder="Type expression (e.g. 1/3 + 1/6, sin(pi/4))..."
            className="w-full bg-transparent font-mono text-base text-ink placeholder-muted focus:outline-none"
          />

          {/* Result view */}
          <div className="flex min-h-[38px] items-baseline justify-between border-t border-line/50 pt-2">
            {evalResult?.status === 'success' ? (
              <div className="flex items-baseline gap-2 overflow-hidden">
                {evalResult.exact && evalResult.exact !== evalResult.formatted && (
                  <span className="font-bold text-accent text-lg">
                    <MathView math={evalResult.exactLaTeX || evalResult.exact} />
                  </span>
                )}
                <span className="font-mono text-lg font-bold text-ink">
                  ≈ {evalResult.formatted}
                </span>
              </div>
            ) : evalResult?.status === 'error' ? (
              <span className="font-mono text-xs text-danger">{evalResult.message}</span>
            ) : (
              <span className="font-mono text-base text-muted/40">0</span>
            )}

            {evalResult?.status === 'success' && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => handleCopy(evalResult.exact || evalResult.formatted)}
                  title="Copy result"
                  className="rounded p-1 text-muted hover:text-ink"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Contextual Action Bar */}
        {evalResult?.status === 'success' && (
          <div className="mt-2.5 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={handleInsertIntoNotebook}
              className="flex items-center gap-1.5 rounded-lg border border-line bg-field px-2.5 py-1 text-xs font-semibold text-ink hover:border-accent/40"
            >
              <BookOpen className="h-3 w-3 text-accent" />
              <span>Insert in Notebook</span>
            </button>

            {/[xy]/.test(expression) && (
              <button
                type="button"
                onClick={handlePlot}
                className="flex items-center gap-1.5 rounded-lg bg-accent/15 px-2.5 py-1 text-xs font-semibold text-accent hover:bg-accent/25"
              >
                <LineChart className="h-3 w-3" />
                <span>Plot in Lab</span>
              </button>
            )}
          </div>
        )}

        {/* Keypad category tabs */}
        <div className="mt-4 flex rounded-lg border border-line bg-field p-0.5 text-xs">
          <button
            type="button"
            onClick={() => setTab('standard')}
            className={`flex-1 py-1 font-semibold rounded-md ${
              tab === 'standard' ? 'bg-panel text-ink shadow-xs' : 'text-muted hover:text-ink'
            }`}
          >
            Arithmetic
          </button>
          <button
            type="button"
            onClick={() => setTab('trig')}
            className={`flex-1 py-1 font-semibold rounded-md ${
              tab === 'trig' ? 'bg-panel text-ink shadow-xs' : 'text-muted hover:text-ink'
            }`}
          >
            Trigonometry
          </button>
          <button
            type="button"
            onClick={() => setTab('advanced')}
            className={`flex-1 py-1 font-semibold rounded-md ${
              tab === 'advanced' ? 'bg-panel text-ink shadow-xs' : 'text-muted hover:text-ink'
            }`}
          >
            Advanced
          </button>
        </div>

        {/* Keypad Grid */}
        <div className="mt-3 flex-1 overflow-y-auto">
          {tab === 'standard' && (
            <div className="grid grid-cols-4 gap-1.5 font-mono">
              <button type="button" onClick={() => append('(')} className="key-btn">(</button>
              <button type="button" onClick={() => append(')')} className="key-btn">)</button>
              <button type="button" onClick={() => append('^')} className="key-btn">xʸ</button>
              <button type="button" onClick={clear} className="key-btn text-danger font-bold">C</button>

              <button type="button" onClick={() => append('7')} className="key-btn">7</button>
              <button type="button" onClick={() => append('8')} className="key-btn">8</button>
              <button type="button" onClick={() => append('9')} className="key-btn">9</button>
              <button type="button" onClick={() => append('/')} className="key-btn text-accent">÷</button>

              <button type="button" onClick={() => append('4')} className="key-btn">4</button>
              <button type="button" onClick={() => append('5')} className="key-btn">5</button>
              <button type="button" onClick={() => append('6')} className="key-btn">6</button>
              <button type="button" onClick={() => append('*')} className="key-btn text-accent">×</button>

              <button type="button" onClick={() => append('1')} className="key-btn">1</button>
              <button type="button" onClick={() => append('2')} className="key-btn">2</button>
              <button type="button" onClick={() => append('3')} className="key-btn">3</button>
              <button type="button" onClick={() => append('-')} className="key-btn text-accent">−</button>

              <button type="button" onClick={() => append('0')} className="key-btn">0</button>
              <button type="button" onClick={() => append('.')} className="key-btn">.</button>
              <button type="button" onClick={backspace} className="key-btn">⌫</button>
              <button type="button" onClick={() => append('+')} className="key-btn text-accent">+</button>

              <button
                type="button"
                onClick={handleCalculate}
                className="col-span-4 rounded-xl bg-accent py-2.5 text-sm font-bold text-accent-ink shadow-xs transition-opacity hover:opacity-90"
              >
                =
              </button>
            </div>
          )}

          {tab === 'trig' && (
            <div className="grid grid-cols-3 gap-1.5 font-mono text-xs">
              {['sin(', 'cos(', 'tan(', 'asin(', 'acos(', 'atan(', 'sinh(', 'cosh(', 'tanh(', 'pi', '2*pi', 'pi/2'].map((fn) => (
                <button
                  key={fn}
                  type="button"
                  onClick={() => append(fn)}
                  className="rounded-lg border border-line bg-field/50 py-2.5 font-medium text-ink hover:border-accent/40 hover:bg-field"
                >
                  {fn.replace('(', '')}
                </button>
              ))}
            </div>
          )}

          {tab === 'advanced' && (
            <div className="grid grid-cols-3 gap-1.5 font-mono text-xs">
              {[
                { label: 'n!', val: '!' },
                { label: 'nCr', val: 'nCr(' },
                { label: 'nPr', val: 'nPr(' },
                { label: 'ln', val: 'ln(' },
                { label: 'log₁₀', val: 'log(' },
                { label: 'log₂', val: 'log2(' },
                { label: '√x', val: 'sqrt(' },
                { label: '|x|', val: 'abs(' },
                { label: 'Ans', val: 'ans' },
              ].map((item) => (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => append(item.val)}
                  className="rounded-lg border border-line bg-field/50 py-2.5 font-medium text-ink hover:border-accent/40 hover:bg-field"
                >
                  {item.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="border-t border-line/60 pt-2.5 text-[11px] text-muted flex items-center justify-between">
          <span>Press Enter to calculate</span>
          <span className="font-mono">Esc to close</span>
        </div>
      </div>

      <style>{`
        .key-btn {
          border-radius: 0.75rem;
          border: 1px solid rgb(var(--line));
          background-color: rgb(var(--field) / 0.5);
          padding: 0.625rem 0;
          text-align: center;
          font-size: 0.875rem;
          color: rgb(var(--ink));
          transition: all 120ms ease;
        }
        .key-btn:hover {
          border-color: rgb(var(--accent) / 0.5);
          background-color: rgb(var(--field));
        }
        .key-btn:active {
          transform: scale(0.97);
        }
      `}</style>
    </div>
  );
}

