'use client';

import { useMemo } from 'react';
import katex from 'katex';

interface MathViewProps {
  math: string;
  displayMode?: boolean;
  className?: string;
}

/**
 * Converts common plaintext mathematical shorthand into valid KaTeX markup.
 */
export function formatToLaTeX(raw: string): string {
  if (!raw) return '';
  let s = raw.trim();

  // If already standard LaTeX
  if (s.includes('\\frac') || s.includes('\\int') || s.includes('\\sum') || s.includes('\\sqrt')) {
    return s;
  }

  // Handle integrals: e.g. ∫[a, b] f(x) dx or ∫ f(x) dx
  s = s.replace(/∫\s*\[\s*([^,\]]+)\s*,\s*([^\]]+)\s*\]/g, '\\int_{$1}^{$2}');
  s = s.replace(/∫/g, '\\int');

  // Handle ±
  s = s.replace(/±/g, '\\pm ');

  // Handle square roots: √(expr) or \sqrt
  s = s.replace(/√\(([^)]+)\)/g, '\\sqrt{$1}');
  s = s.replace(/√([a-zA-Z0-9]+)/g, '\\sqrt{$1}');

  // Handle Greek symbols
  s = s.replace(/\bpi\b|π/g, '\\pi ');
  s = s.replace(/\bphi\b|φ/g, '\\phi ');
  s = s.replace(/\btheta\b|θ/g, '\\theta ');
  s = s.replace(/\balpha\b|α/g, '\\alpha ');
  s = s.replace(/\bbeta\b|β/g, '\\beta ');
  s = s.replace(/\bgamma\b|γ/g, '\\gamma ');

  // Handle powers: x^2, (a+b)^2
  s = s.replace(/\^([0-9a-zA-Z]+)/g, '^{$1}');
  s = s.replace(/²/g, '^{2}');
  s = s.replace(/³/g, '^{3}');

  // Handle multiplication · or *
  s = s.replace(/\s*·\s*|\s*\*\s*/g, ' \\cdot ');

  // Fractions: (a) / (b) or simple a/b
  s = s.replace(/\(([^)]+)\)\s*\/\s*\(([^)]+)\)/g, '\\frac{$1}{$2}');
  s = s.replace(/([a-zA-Z0-9_\^\{\}]+)\s*\/\s*([a-zA-Z0-9_\^\{\}]+)/g, '\\frac{$1}{$2}');

  // Relations <=, >=, !=
  s = s.replace(/<=/g, ' \\le ');
  s = s.replace(/>=/g, ' \\ge ');
  s = s.replace(/!=/g, ' \\ne ');
  s = s.replace(/≈/g, ' \\approx ');

  return s;
}

export default function MathView({ math, displayMode = false, className = '' }: MathViewProps) {
  const html = useMemo(() => {
    const latex = formatToLaTeX(math);
    try {
      return katex.renderToString(latex, {
        displayMode,
        throwOnError: false,
        strict: false,
      });
    } catch {
      return `<span class="font-mono">${math}</span>`;
    }
  }, [math, displayMode]);

  return (
    <span
      className={`inline-block select-text ${displayMode ? 'my-1 block text-center' : ''} ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
