'use client';

import { useState } from 'react';
import type { AppRoute, ReferenceTab } from '@/types/navigation';
import FormulaLibraryView from '@/modules/formulas/FormulaLibraryView';
import MathExplorerView from '@/modules/explorer/MathExplorerView';
import PracticeReviewView from '@/modules/practice/PracticeReviewView';
import { Library, Compass, GraduationCap } from 'lucide-react';

interface ReferenceHubProps {
  initialTab?: ReferenceTab;
  onNavigate: (route: AppRoute, payload?: { expression?: string }) => void;
}

export default function ReferenceHub({
  initialTab = 'formulas',
  onNavigate,
}: ReferenceHubProps) {
  const [activeTab, setActiveTab] = useState<ReferenceTab>(initialTab);

  return (
    <div className="flex h-full flex-col overflow-hidden bg-canvas">
      {/* Sub-Header Navigation Switcher */}
      <div className="flex h-11 shrink-0 items-center justify-between border-b border-line bg-panel/80 px-3 sm:px-4 backdrop-blur-xs select-none">
        <div className="flex items-center gap-1.5 sm:gap-2">
          <div className="flex rounded-lg border border-line bg-field p-0.5 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('formulas')}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1 transition-all ${
                activeTab === 'formulas'
                  ? 'bg-panel text-ink shadow-xs font-bold'
                  : 'text-muted hover:text-ink'
              }`}
            >
              <Library className="h-3.5 w-3.5 text-violet-400" />
              <span>Formula Catalog</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('explorer')}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1 transition-all ${
                activeTab === 'explorer'
                  ? 'bg-panel text-ink shadow-xs font-bold'
                  : 'text-muted hover:text-ink'
              }`}
            >
              <Compass className="h-3.5 w-3.5 text-accent" />
              <span>Concept Explorer</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('practice')}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1 transition-all ${
                activeTab === 'practice'
                  ? 'bg-panel text-ink shadow-xs font-bold'
                  : 'text-muted hover:text-ink'
              }`}
            >
              <GraduationCap className="h-3.5 w-3.5 text-emerald-400" />
              <span>Practice & Review</span>
            </button>
          </div>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-xs text-muted">
          <span>Mathematical Knowledge & Self-Assessment</span>
        </div>
      </div>

      {/* Main Reference Viewport */}
      <div className="relative flex-1 min-h-0 min-w-0 overflow-hidden">
        {activeTab === 'formulas' && <FormulaLibraryView onNavigate={onNavigate} />}
        {activeTab === 'explorer' && <MathExplorerView onNavigate={onNavigate} />}
        {activeTab === 'practice' && <PracticeReviewView onNavigate={onNavigate} />}
      </div>
    </div>
  );
}

