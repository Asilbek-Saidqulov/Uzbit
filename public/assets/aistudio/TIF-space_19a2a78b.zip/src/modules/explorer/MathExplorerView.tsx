'use client';

import { useState, useMemo } from 'react';
import type { AppRoute } from '@/types/navigation';
import MathView from '@/components/MathView';
import {
  Compass,
  BookOpen,
  ChevronRight,
  Sparkles,
  ArrowRight,
  Sliders,
  CheckCircle2,
  ExternalLink,
  Layers,
  Search,
} from 'lucide-react';

interface MathExplorerViewProps {
  onNavigate: (route: AppRoute, payload?: { expression?: string }) => void;
}

interface ConceptTopic {
  id: string;
  title: string;
  subject: 'Calculus' | 'Linear Algebra' | 'Trigonometry' | 'Statistics' | 'Geometry';
  level: 'Introductory' | 'Intermediate' | 'Advanced';
  equation: string;
  definition: string;
  intuition: string;
  theorem: string;
  presetExpression?: string;
  sliderParam?: { name: string; min: number; max: number; step: number; default: number; unit?: string };
}

const CONCEPTS: ConceptTopic[] = [
  {
    id: 'c-calc-1',
    title: 'The Derivative as Instantaneous Velocity',
    subject: 'Calculus',
    level: 'Introductory',
    equation: 'f\'(x) = \\lim_{h \\to 0} \\frac{f(x + h) - f(x)}{h}',
    definition: 'The derivative represents the limiting secant line slope as the interval h shrinks toward zero, yielding the exact tangent rate of change.',
    intuition: 'If position is s(t), the derivative s\'(t) represents instantaneous speedometer speed at that exact millisecond.',
    theorem: 'Differentiability implies continuity: if f\'(x) exists at x = a, then f(x) must be continuous at x = a.',
    presetExpression: 'x^2 - 4',
    sliderParam: { name: 'x', min: -4, max: 4, step: 0.5, default: 2 },
  },
  {
    id: 'c-calc-2',
    title: 'Definite Riemann Integration & Signed Area',
    subject: 'Calculus',
    level: 'Intermediate',
    equation: '\\int_{a}^{b} f(x)\\,dx = \\lim_{n \\to \\infty} \\sum_{i=1}^{n} f(x_i^*)\\,\\Delta x',
    definition: 'Definite integration partitions an interval into infinitely many infinitesimal rectangles of width Δx, accumulating net signed area under f(x).',
    intuition: 'Areas above the x-axis contribute positive volume, while regions below the axis subtract from the total sum.',
    theorem: 'Mean Value Theorem for Integrals: There exists c in [a, b] such that f(c)(b - a) = \\int_a^b f(x) dx.',
    presetExpression: 'x^2 - 4',
    sliderParam: { name: 'Upper Bound b', min: 0, max: 5, step: 0.5, default: 2 },
  },
  {
    id: 'c-trig-1',
    title: 'Unit Circle Trigonometry & Radian Angle Metric',
    subject: 'Trigonometry',
    level: 'Introductory',
    equation: '\\cos^2(\\theta) + \\sin^2(\\theta) = 1',
    definition: 'On a circle of radius 1 centered at (0, 0), any angle θ intersects the perimeter at coordinates (x, y) = (cos θ, sin θ).',
    intuition: 'Because radius is 1, the Pythagorean hypotenuse is always 1, making sin and cos fundamental orthogonal projections.',
    theorem: 'Euler\'s formula: e^{i\\theta} = \\cos(\\theta) + i\\sin(\\theta).',
    presetExpression: 'sin(x)',
    sliderParam: { name: 'θ (radians)', min: 0, max: 6.28, step: 0.314, default: 1.57 },
  },
  {
    id: 'c-geom-1',
    title: 'Pythagorean Metric & Euclidean Distance',
    subject: 'Geometry',
    level: 'Introductory',
    equation: 'd(P, Q) = \\sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}',
    definition: 'In 2D flat space, the straight-line shortest path between two points follows directly from the Pythagorean theorem on orthogonal legs dx and dy.',
    intuition: 'Diagonal travel is always less than the sum of orthogonal Manhattan steps: d <= |dx| + |dy|.',
    theorem: 'Triangle Inequality: In any Euclidean triangle with sides a, b, c, a + b >= c.',
    presetExpression: 'sqrt(x)',
  },
  {
    id: 'c-stat-1',
    title: 'Ordinary Least Squares Regression & Residual Variance',
    subject: 'Statistics',
    level: 'Intermediate',
    equation: 'S(m, b) = \\sum_{i=1}^{n} \\left(y_i - (m x_i + b)\\right)^2',
    definition: 'The best-fit linear model minimizes the sum of squared vertical distances between observed data coordinates and predicted values.',
    intuition: 'Squaring penalizes large outliers more heavily and prevents positive and negative residuals from canceling out.',
    theorem: 'Gauss-Markov Theorem: Under mild assumptions, OLS estimators are the Best Linear Unbiased Estimators (BLUE).',
    presetExpression: '2x + 1',
  },
  {
    id: 'c-la-1',
    title: 'Vector Orthogonal Projections',
    subject: 'Linear Algebra',
    level: 'Intermediate',
    equation: '\\text{proj}_{\\mathbf{u}}(\\mathbf{v}) = \\frac{\\mathbf{u} \\cdot \\mathbf{v}}{\\|\\mathbf{u}\\|^2}\\,\\mathbf{u}',
    definition: 'Decomposes an arbitrary vector v into two mutually orthogonal components: one lying along the direction of u, and one perpendicular to u.',
    intuition: 'The projection represents the "shadow" that vector v casts onto the line spanned by vector u.',
    theorem: 'Orthogonality principle: The error vector e = v - proj_u(v) satisfies e · u = 0.',
    presetExpression: 'x',
  },
];

export default function MathExplorerView({ onNavigate }: MathExplorerViewProps) {
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [search, setSearch] = useState('');
  const [activeConceptId, setActiveConceptId] = useState<string | null>(CONCEPTS[0].id);
  const [sliderVal, setSliderVal] = useState<number>(2);

  const subjects = ['All', 'Calculus', 'Trigonometry', 'Geometry', 'Statistics', 'Linear Algebra'];

  const filtered = CONCEPTS.filter((c) => {
    const matchSub = selectedSubject === 'All' || c.subject === selectedSubject;
    const matchSearch =
      !search.trim() ||
      c.title.toLowerCase().includes(search.toLowerCase()) ||
      c.definition.toLowerCase().includes(search.toLowerCase());
    return matchSub && matchSearch;
  });

  const activeConcept = CONCEPTS.find((c) => c.id === activeConceptId) || CONCEPTS[0];

  const dynamicMetrics = useMemo(() => {
    if (activeConcept.id === 'c-calc-1') {
      const x0 = sliderVal;
      const y0 = x0 * x0 - 4;
      const slope = 2 * x0;
      return {
        title: 'Instantaneous Dynamic State at x',
        items: [
          { label: 'Evaluation x', val: `${x0}` },
          { label: 'Value f(x)', val: `${y0.toFixed(2)}` },
          { label: 'Derivative Slope f\'(x)', val: `${slope.toFixed(2)}` },
          { label: 'Tangent Line', val: `y = ${slope.toFixed(2)}x + ${(y0 - slope * x0).toFixed(2)}` },
        ],
      };
    }
    if (activeConcept.id === 'c-calc-2') {
      const b = sliderVal;
      const signedArea = (b * b * b) / 3 - 4 * b;
      return {
        title: 'Definite Riemann Sum Result',
        items: [
          { label: 'Lower Bound a', val: '0' },
          { label: 'Upper Bound b', val: `${b}` },
          { label: 'Antiderivative F(b)', val: `(${b}³)/3 - 4(${b})` },
          { label: 'Net Signed Area', val: `${signedArea.toFixed(3)} units²` },
        ],
      };
    }
    if (activeConcept.id === 'c-trig-1') {
      const theta = sliderVal;
      const cosVal = Math.cos(theta);
      const sinVal = Math.sin(theta);
      const deg = Math.round((theta * 180) / Math.PI);
      return {
        title: 'Unit Circle Geometric State',
        items: [
          { label: 'Angle θ', val: `${theta} rad (${deg}°)` },
          { label: 'x = cos(θ)', val: `${cosVal.toFixed(4)}` },
          { label: 'y = sin(θ)', val: `${sinVal.toFixed(4)}` },
          { label: 'cos²θ + sin²θ', val: `${(cosVal * cosVal + sinVal * sinVal).toFixed(4)}` },
        ],
      };
    }
    return null;
  }, [activeConcept.id, sliderVal]);

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-6xl space-y-6">
        {/* Header */}
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">
                Math Explorer & Concept Studio
              </h1>
              <span className="flex items-center gap-1 rounded-full bg-accent/15 px-2.5 py-0.5 text-xs font-semibold text-accent">
                <Sparkles className="h-3 w-3" />
                <span>Interactive Taxonomy</span>
              </span>
            </div>
            <p className="text-xs text-muted sm:text-sm">
              Discover foundational mathematical concepts with geometric intuition, theorems, interactive parameters, and 1-click lab exploration.
            </p>
          </div>
        </div>

        {/* Filter bar */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-muted" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search concepts, theorems, or keywords..."
              className="w-full rounded-xl border border-line bg-panel py-2.5 pl-10 pr-4 text-xs text-ink placeholder-muted focus:border-accent focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {subjects.map((sub) => (
              <button
                key={sub}
                type="button"
                onClick={() => setSelectedSubject(sub)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors shrink-0 ${
                  selectedSubject === sub
                    ? 'bg-accent text-accent-ink shadow-sm'
                    : 'bg-field text-muted hover:bg-line/40 hover:text-ink'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        </div>

        {/* Main Grid: Concept Cards List (5 cols) + Deep-Dive Interactive Workbench (7 cols) */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Concept Topics List */}
          <div className="space-y-3 lg:col-span-5">
            {filtered.map((c) => {
              const isSelected = c.id === activeConcept.id;
              return (
                <div
                  key={c.id}
                  onClick={() => {
                    setActiveConceptId(c.id);
                    if (c.sliderParam) setSliderVal(c.sliderParam.default);
                  }}
                  className={`group cursor-pointer rounded-2xl border p-4 transition-all ${
                    isSelected
                      ? 'border-accent bg-field/90 shadow-md'
                      : 'border-line bg-panel hover:border-accent/40 hover:bg-field/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="rounded-md border border-line/60 bg-panel px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent">
                      {c.subject}
                    </span>
                    <span className="rounded-full bg-field px-2 py-0.5 text-[10px] font-medium text-muted">
                      {c.level}
                    </span>
                  </div>

                  <h3 className="mt-2 text-sm font-bold text-ink group-hover:text-accent transition-colors">
                    {c.title}
                  </h3>

                  <div className="mt-2 text-xs text-accent">
                    <MathView math={c.equation} />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Deep-Dive Interactive Workbench */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl border border-line bg-panel p-6 shadow-sm space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-line">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-accent">
                    {activeConcept.subject} • {activeConcept.level}
                  </span>
                  <h2 className="text-lg font-bold text-ink mt-0.5">{activeConcept.title}</h2>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('lab', { expression: activeConcept.presetExpression || 'x^2 - 4' })}
                  className="flex items-center gap-1.5 rounded-xl bg-accent px-3.5 py-1.5 text-xs font-semibold text-accent-ink shadow-sm hover:opacity-90"
                >
                  <span>Open in Visual Lab</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Main Formula Callout */}
              <div className="rounded-xl border border-line/80 bg-field/80 p-4 text-center shadow-inner">
                <div className="text-xl text-ink font-serif">
                  <MathView math={activeConcept.equation} displayMode />
                </div>
              </div>

              {/* Interactive Parameter Slider if available */}
              {activeConcept.sliderParam && (
                <div className="rounded-xl border border-accent/25 bg-accent/5 p-4 space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <div className="flex items-center gap-1.5 text-accent">
                      <Sliders className="h-3.5 w-3.5" />
                      <span>Dynamic Parameter: {activeConcept.sliderParam.name}</span>
                    </div>
                    <span className="font-mono text-sm font-bold text-ink">{sliderVal}</span>
                  </div>

                  <input
                    type="range"
                    min={activeConcept.sliderParam.min}
                    max={activeConcept.sliderParam.max}
                    step={activeConcept.sliderParam.step}
                    value={sliderVal}
                    onChange={(e) => setSliderVal(parseFloat(e.target.value))}
                    className="w-full accent-accent cursor-pointer"
                  />

                  <div className="flex justify-between text-[10px] text-muted font-mono">
                    <span>Min: {activeConcept.sliderParam.min}</span>
                    <span>Evaluation Point: {activeConcept.sliderParam.name} = {sliderVal}</span>
                    <span>Max: {activeConcept.sliderParam.max}</span>
                  </div>

                  {/* Real-time Dynamic Math Readout */}
                  {dynamicMetrics && (
                    <div className="mt-3 border-t border-accent/20 pt-2.5">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-accent mb-1.5">
                        {dynamicMetrics.title}
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        {dynamicMetrics.items.map((item, idx) => (
                          <div key={idx} className="rounded-lg border border-accent/20 bg-panel/80 p-2 font-mono">
                            <span className="text-[10px] text-muted block">{item.label}</span>
                            <span className="font-bold text-ink text-xs">{item.val}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Conceptual Definition */}
              <div className="space-y-1">
                <h4 className="text-xs font-bold uppercase tracking-wider text-muted">Mathematical Definition</h4>
                <p className="text-xs text-ink/90 leading-relaxed font-sans">{activeConcept.definition}</p>
              </div>

              {/* Geometric & Physical Intuition */}
              <div className="space-y-1">
                <h4 className="text-xs font-bold uppercase tracking-wider text-muted">Geometric Intuition</h4>
                <p className="text-xs text-muted leading-relaxed font-sans">{activeConcept.intuition}</p>
              </div>

              {/* Central Theorem Card */}
              <div className="rounded-xl border-l-4 border-emerald-500 bg-emerald-500/10 p-3.5 space-y-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                  Fundamental Theorem & Proof Outline
                </span>
                <p className="text-xs text-ink/90 leading-relaxed font-serif">
                  <MathView math={activeConcept.theorem} />
                </p>
              </div>

              {/* Cross-Module Quick Actions */}
              <div className="border-t border-line/60 pt-4 flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="text-muted text-[11px]">Next Steps:</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onNavigate('calculator')}
                    className="rounded-lg border border-line bg-field px-3 py-1.5 font-semibold text-ink hover:border-accent/40"
                  >
                    Test in Calculator
                  </button>
                  <button
                    type="button"
                    onClick={() => onNavigate('workspace')}
                    className="rounded-lg border border-line bg-field px-3 py-1.5 font-semibold text-ink hover:border-accent/40"
                  >
                    Create Study Notebook
                  </button>
                  <button
                    type="button"
                    onClick={() => onNavigate('practice')}
                    className="rounded-lg bg-accent/15 px-3 py-1.5 font-semibold text-accent hover:bg-accent/25"
                  >
                    Practice Problems →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
