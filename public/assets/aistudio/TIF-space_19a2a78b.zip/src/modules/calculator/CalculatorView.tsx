'use client';

import { useState, useEffect, useRef } from 'react';
import { mathEngine, type AngleMode, type MathResult } from '@/core/math/engine';
import { appendMathBlockToActive } from '@/core/notebook/notebookStore';
import type { AppRoute } from '@/types/navigation';
import MathView from '@/components/MathView';
import {
  Delete,
  RotateCcw,
  Copy,
  Check,
  Download,
  Share2,
  Sparkles,
  ArrowRight,
  History,
  Sliders,
  ChevronRight,
  BookOpen,
  LineChart,
} from 'lucide-react';

interface HistoryItem {
  id: string;
  expression: string;
  exact?: string;
  approximation: number;
  formatted: string;
  angleMode: AngleMode;
  timestamp: string;
}

interface CalculatorViewProps {
  onNavigate?: (route: AppRoute, payload?: { expression?: string }) => void;
}

export default function CalculatorView({ onNavigate }: CalculatorViewProps = {}) {
  const [expression, setExpression] = useState('');
  const [angleMode, setAngleMode] = useState<AngleMode>('radians');
  const [precision, setPrecision] = useState(8);
  const [activeTab, setActiveTab] = useState<'standard' | 'trig' | 'advanced'>('standard');
  const [lastAnswer, setLastAnswer] = useState<number | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [evalResult, setEvalResult] = useState<MathResult | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);

  // Persistent History
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('tifspace_calc_history');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'h-1',
        expression: '1/3 + 1/6',
        exact: '1/2',
        approximation: 0.5,
        formatted: '0.5',
        angleMode: 'radians',
        timestamp: '3:05 AM',
      },
      {
        id: 'h-2',
        expression: 'sin(pi / 6)',
        exact: '1/2',
        approximation: 0.5,
        formatted: '0.5',
        angleMode: 'radians',
        timestamp: '3:02 AM',
      },
      {
        id: 'h-3',
        expression: '5!',
        exact: '120',
        approximation: 120,
        formatted: '120',
        angleMode: 'radians',
        timestamp: '3:00 AM',
      },
    ];
  });

  useEffect(() => {
    try {
      localStorage.setItem('tifspace_calc_history', JSON.stringify(history));
    } catch {}
  }, [history]);

  // Live evaluation preview as student types
  useEffect(() => {
    if (!expression.trim()) {
      setEvalResult(null);
      return;
    }
    const vars: Record<string, number> = {};
    if (lastAnswer !== null) vars['ans'] = lastAnswer;

    const res = mathEngine.evaluate(expression, {
      angleMode,
      precision,
      variables: vars,
    });
    setEvalResult(res);
  }, [expression, angleMode, precision, lastAnswer]);

  const append = (str: string) => {
    setExpression((prev) => prev + str);
    inputRef.current?.focus();
  };

  const clear = () => {
    setExpression('');
    setEvalResult(null);
    inputRef.current?.focus();
  };

  const backspace = () => {
    setExpression((prev) => prev.slice(0, -1));
    inputRef.current?.focus();
  };

  const handleCalculate = () => {
    if (!expression.trim()) return;

    const vars: Record<string, number> = {};
    if (lastAnswer !== null) vars['ans'] = lastAnswer;

    const res = mathEngine.evaluate(expression, {
      angleMode,
      precision,
      variables: vars,
    });

    setEvalResult(res);

    if (res.status === 'success') {
      setLastAnswer(res.approximation);
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      const newItem: HistoryItem = {
        id: `h-${Date.now()}`,
        expression,
        exact: res.exact,
        approximation: res.approximation,
        formatted: res.formatted,
        angleMode,
        timestamp: timeStr,
      };

      setHistory((prev) => [newItem, ...prev.slice(0, 29)]);
    }
  };

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleCalculate();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      clear();
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleInsertHistory = (item: HistoryItem) => {
    setExpression(item.expression);
    inputRef.current?.focus();
  };

  const handleInsertResult = (val: string) => {
    setExpression((prev) => prev + val);
    inputRef.current?.focus();
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-5xl space-y-6">
        {/* Module Title & Mode Pill */}
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">
                Scientific & Symbolic Calculator
              </h1>
              <span className="rounded-full bg-emerald-500/15 px-2.5 py-0.5 text-xs font-semibold text-emerald-400">
                Phase 2 Core Engine
              </span>
            </div>
            <p className="text-xs text-muted sm:text-sm">
              Non-eval mathematical engine with exact rational reduction, right-associative powers, and dual exact/decimal representations.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Angle Mode Toggle */}
            <div className="flex rounded-xl border border-line bg-panel p-1 text-xs">
              <button
                type="button"
                onClick={() => setAngleMode('radians')}
                className={`rounded-lg px-3 py-1 font-semibold transition-all ${
                  angleMode === 'radians'
                    ? 'bg-accent text-accent-ink shadow-sm'
                    : 'text-muted hover:text-ink'
                }`}
              >
                RAD (π)
              </button>
              <button
                type="button"
                onClick={() => setAngleMode('degrees')}
                className={`rounded-lg px-3 py-1 font-semibold transition-all ${
                  angleMode === 'degrees'
                    ? 'bg-accent text-accent-ink shadow-sm'
                    : 'text-muted hover:text-ink'
                }`}
              >
                DEG (°)
              </button>
            </div>
          </div>
        </div>

        {/* Main Grid: Calculator Studio (3 cols) + History (2 cols) */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
          {/* Keypad & Expression Viewport (3 cols) */}
          <div className="space-y-4 lg:col-span-3">
            {/* High-visibility display panel */}
            <div className="rounded-2xl border border-line bg-panel p-5 shadow-sm">
              <div className="flex items-center justify-between text-xs text-muted pb-2 border-b border-line/60">
                <div className="flex items-center gap-2">
                  <span className="font-semibold uppercase tracking-wider">
                    Mode: <span className="text-accent">{angleMode.toUpperCase()}</span>
                  </span>
                  {lastAnswer !== null && (
                    <span className="rounded bg-field px-1.5 py-0.5 font-mono text-[10px] text-muted">
                      Ans = {lastAnswer}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-[11px] text-muted">Precision:</span>
                  <select
                    value={precision}
                    onChange={(e) => setPrecision(Number(e.target.value))}
                    aria-label="Calculator decimal precision"
                    className="rounded-md border border-line bg-field px-1.5 py-0.5 font-mono text-[11px] text-ink focus:border-accent focus:outline-none cursor-pointer"
                  >
                    <option value={4}>4 Digits</option>
                    <option value={6}>6 Digits</option>
                    <option value={8}>8 Digits</option>
                    <option value={12}>12 Digits</option>
                    <option value={16}>16 Digits</option>
                  </select>
                </div>
              </div>

              {/* Editable Input Field */}
              <div className="mt-3 relative flex items-center justify-between gap-3">
                <input
                  ref={inputRef}
                  type="text"
                  value={expression}
                  onChange={(e) => setExpression(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Type an expression e.g. 1/3 + 1/6, sin(90), or x^2 - 4..."
                  className="w-full bg-transparent font-mono text-lg text-ink placeholder-muted focus:outline-none"
                  autoFocus
                />
                {onNavigate && expression.trim() && /[xy]/.test(expression) && (
                  <button
                    type="button"
                    onClick={() => onNavigate('lab', { expression })}
                    className="flex shrink-0 items-center gap-1.5 rounded-lg bg-accent/15 px-2.5 py-1 text-xs font-semibold text-accent hover:bg-accent/25 transition-colors"
                    title="Open function in Visual Lab"
                  >
                    <LineChart className="h-3.5 w-3.5" />
                    <span>Plot in Lab</span>
                  </button>
                )}
              </div>

              {/* Dual Output Results Display */}
              <div className="mt-4 flex min-h-[56px] flex-col justify-end border-t border-line/60 pt-3">
                {evalResult?.status === 'success' ? (
                  <div className="flex items-baseline justify-between gap-4">
                    <div className="flex items-baseline gap-3 overflow-hidden">
                      {evalResult.exact && evalResult.exact !== evalResult.formatted && (
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-bold uppercase tracking-wider text-accent/80">Exact:</span>
                          <span className="text-xl font-bold text-accent">
                            <MathView math={evalResult.exactLaTeX || evalResult.exact} />
                          </span>
                        </div>
                      )}
                      <div className="flex items-baseline gap-1.5 truncate">
                        <span className="text-xs text-muted">≈</span>
                        <span className="font-mono text-2xl font-extrabold text-ink truncate">
                          {evalResult.formatted}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleCopy('current', evalResult.exact || evalResult.formatted)}
                      title="Copy result"
                      className="flex shrink-0 items-center gap-1 rounded-lg border border-line bg-field px-2.5 py-1 text-xs font-medium text-muted hover:border-accent/40 hover:text-ink"
                    >
                      {copiedId === 'current' ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                ) : evalResult?.status === 'error' ? (
                  <div className="flex items-center gap-2 text-danger">
                    <span className="text-xs font-bold uppercase tracking-wider">Error:</span>
                    <span className="font-mono text-xs">{evalResult.message}</span>
                  </div>
                ) : (
                  <span className="font-mono text-2xl font-bold text-muted/40">0</span>
                )}
              </div>
            </div>

            {/* Keypad Category Tabs */}
            <div className="flex items-center gap-2 border-b border-line pb-2">
              <button
                type="button"
                onClick={() => setActiveTab('standard')}
                className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition-all ${
                  activeTab === 'standard'
                    ? 'bg-accent text-accent-ink shadow-sm'
                    : 'text-muted hover:bg-field hover:text-ink'
                }`}
              >
                Standard Arithmetic
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('trig')}
                className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition-all ${
                  activeTab === 'trig'
                    ? 'bg-accent text-accent-ink shadow-sm'
                    : 'text-muted hover:bg-field hover:text-ink'
                }`}
              >
                Trigonometry & Hyperbolic
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('advanced')}
                className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition-all ${
                  activeTab === 'advanced'
                    ? 'bg-accent text-accent-ink shadow-sm'
                    : 'text-muted hover:bg-field hover:text-ink'
                }`}
              >
                Advanced & Combinatorics
              </button>
            </div>

            {/* Standard Keypad */}
            {activeTab === 'standard' && (
              <div className="grid grid-cols-5 gap-2">
                <button
                  type="button"
                  onClick={() => append('(')}
                  className="rounded-xl border border-line bg-panel py-3 text-xs font-semibold text-ink hover:bg-field"
                >
                  (
                </button>
                <button
                  type="button"
                  onClick={() => append(')')}
                  className="rounded-xl border border-line bg-panel py-3 text-xs font-semibold text-ink hover:bg-field"
                >
                  )
                </button>
                <button
                  type="button"
                  onClick={() => append('^')}
                  className="rounded-xl border border-line bg-panel py-3 text-xs font-semibold text-ink hover:bg-field"
                >
                  xʸ
                </button>
                <button
                  type="button"
                  onClick={() => append('sqrt(')}
                  className="rounded-xl border border-line bg-panel py-3 text-xs font-semibold text-ink hover:bg-field"
                >
                  √
                </button>
                <button
                  type="button"
                  onClick={clear}
                  className="rounded-xl border border-line bg-danger/10 py-3 text-xs font-bold text-danger hover:bg-danger/20"
                >
                  AC
                </button>

                {['7', '8', '9', '/'].map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => append(k)}
                    className={`rounded-xl border border-line py-3 text-sm font-semibold transition-colors ${
                      k === '/' ? 'bg-field text-accent' : 'bg-panel text-ink hover:bg-field'
                    }`}
                  >
                    {k}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={backspace}
                  className="grid place-items-center rounded-xl border border-line bg-field py-3 text-xs font-semibold text-muted hover:text-ink"
                >
                  <Delete className="h-4 w-4" />
                </button>

                {['4', '5', '6', '*'].map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => append(k)}
                    className={`rounded-xl border border-line py-3 text-sm font-semibold transition-colors ${
                      k === '*' ? 'bg-field text-accent' : 'bg-panel text-ink hover:bg-field'
                    }`}
                  >
                    {k}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => append('pi')}
                  className="rounded-xl border border-line bg-field py-3 text-sm font-semibold text-accent hover:border-accent/40"
                >
                  π
                </button>

                {['1', '2', '3', '-'].map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => append(k)}
                    className={`rounded-xl border border-line py-3 text-sm font-semibold transition-colors ${
                      k === '-' ? 'bg-field text-accent' : 'bg-panel text-ink hover:bg-field'
                    }`}
                  >
                    {k}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => append('e')}
                  className="rounded-xl border border-line bg-field py-3 text-sm font-semibold text-accent hover:border-accent/40"
                >
                  e
                </button>

                <button
                  type="button"
                  onClick={() => append('0')}
                  className="col-span-2 rounded-xl border border-line bg-panel py-3 text-sm font-semibold text-ink hover:bg-field"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={() => append('.')}
                  className="rounded-xl border border-line bg-panel py-3 text-sm font-semibold text-ink hover:bg-field"
                >
                  .
                </button>
                <button
                  type="button"
                  onClick={() => append('+')}
                  className="rounded-xl border border-line bg-field py-3 text-sm font-semibold text-accent hover:border-accent/40"
                >
                  +
                </button>
                <button
                  type="button"
                  onClick={handleCalculate}
                  className="rounded-xl bg-accent py-3 text-sm font-bold text-accent-ink shadow-sm transition-opacity hover:opacity-90"
                >
                  =
                </button>
              </div>
            )}

            {/* Trigonometry Keypad */}
            {activeTab === 'trig' && (
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: 'sin', val: 'sin(' },
                  { label: 'cos', val: 'cos(' },
                  { label: 'tan', val: 'tan(' },
                  { label: 'asin (sin⁻¹)', val: 'asin(' },
                  { label: 'acos (cos⁻¹)', val: 'acos(' },
                  { label: 'atan (tan⁻¹)', val: 'atan(' },
                  { label: 'sinh', val: 'sinh(' },
                  { label: 'cosh', val: 'cosh(' },
                  { label: 'tanh', val: 'tanh(' },
                  { label: 'π (pi)', val: 'pi' },
                  { label: '2π', val: '2pi' },
                  { label: 'π/2', val: 'pi/2' },
                ].map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => append(item.val)}
                    className="rounded-xl border border-line bg-panel py-3 text-xs font-semibold text-ink transition-colors hover:border-accent/40 hover:bg-field"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}

            {/* Advanced Keypad */}
            {activeTab === 'advanced' && (
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: 'n! (Factorial)', val: '!' },
                  { label: 'nCr (Combinations)', val: 'nCr(' },
                  { label: 'nPr (Permutations)', val: 'nPr(' },
                  { label: 'ln (Natural log)', val: 'ln(' },
                  { label: 'log₁₀', val: 'log(' },
                  { label: 'log₂', val: 'log2(' },
                  { label: 'cbrt (∛)', val: 'cbrt(' },
                  { label: '|x| (abs)', val: 'abs(' },
                  { label: 'floor', val: 'floor(' },
                  { label: 'ceil', val: 'ceil(' },
                  { label: 'φ (Golden ratio)', val: 'phi' },
                  { label: 'Ans (Previous)', val: 'ans' },
                ].map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => append(item.val)}
                    className="rounded-xl border border-line bg-panel py-3 text-xs font-semibold text-ink transition-colors hover:border-accent/40 hover:bg-field"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Persistent Calculation History Stack (2 cols) */}
          <div className="flex flex-col rounded-2xl border border-line bg-panel p-5 shadow-sm lg:col-span-2">
            <div className="flex items-center justify-between pb-3 border-b border-line">
              <div className="flex items-center gap-1.5">
                <History className="h-4 w-4 text-accent" />
                <span className="text-xs font-bold uppercase tracking-wider text-ink">Calculation History</span>
              </div>
              {history.length > 0 && (
                <button
                  type="button"
                  onClick={() => setHistory([])}
                  className="text-[11px] font-medium text-muted hover:text-danger transition-colors"
                >
                  Clear History
                </button>
              )}
            </div>

            <div className="min-h-[300px] max-h-[460px] flex-1 overflow-y-auto space-y-2.5 py-3">
              {history.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center text-xs text-muted">
                  <p>No calculation history yet</p>
                  <p className="mt-1 text-[11px]">Evaluations will automatically persist here</p>
                </div>
              ) : (
                history.map((item) => (
                  <div
                    key={item.id}
                    className="group rounded-xl border border-line/60 bg-field/40 p-3 transition-all hover:border-accent/40 hover:bg-field"
                  >
                    <div className="flex items-center justify-between text-[10px] text-muted mb-1">
                      <span className="rounded bg-panel px-1.5 py-0.2 font-mono uppercase">{item.angleMode}</span>
                      <span>{item.timestamp}</span>
                    </div>

                    <div
                      onClick={() => handleInsertHistory(item)}
                      className="cursor-pointer text-xs text-ink/85 hover:text-accent truncate font-mono"
                    >
                      <MathView math={item.expression} />
                    </div>

                    <div className="mt-1 flex items-baseline justify-between">
                      <div
                        onClick={() => handleInsertResult(item.exact || item.formatted)}
                        className="cursor-pointer text-sm font-bold text-ink hover:text-accent truncate"
                      >
                        = {item.exact ? (
                          <span className="inline-flex items-center gap-1.5">
                            <MathView math={item.exact} />
                            <span className="text-xs text-muted font-normal">≈ {item.formatted}</span>
                          </span>
                        ) : (
                          item.formatted
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        {onNavigate && (
                          <>
                            <button
                              type="button"
                              onClick={() => {
                                onNavigate('lab', { expression: item.expression });
                              }}
                              className="text-muted hover:text-accent transition-colors"
                              title="Plot in Visual Lab"
                            >
                              <LineChart className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                appendMathBlockToActive(`${item.expression} = ${item.exact || item.formatted}`);
                                onNavigate('workspace');
                              }}
                              className="text-muted hover:text-accent transition-colors"
                              title="Insert into Notebook document"
                            >
                              <BookOpen className="h-3.5 w-3.5" />
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => handleCopy(item.id, item.exact || item.formatted)}
                          className="text-muted hover:text-ink transition-colors"
                          title="Copy result"
                        >
                          {copiedId === item.id ? (
                            <Check className="h-3 w-3 text-emerald-400" />
                          ) : (
                            <Copy className="h-3 w-3" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="border-t border-line/60 pt-3 text-[11px] text-muted flex items-center justify-between">
              <span>Click any entry to load expression</span>
              <kbd className="rounded border border-line bg-field px-1.5 py-0.5 font-mono text-[9px]">Enter = calc</kbd>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
