'use client';

import React, { useState, useEffect, useRef } from 'react';
import type {
  MathDocument,
  MathBlock,
  BlockType,
  BlockRelationship,
  HeadingContent,
  ParagraphContent,
  MathBlockContent,
  CalculationContent,
  ProofContent,
  DerivationContent,
  DefinitionContent,
  ResultContent,
  EmbeddedGraphContent,
  TableContent,
  CalloutContent,
  SectionContent,
} from '@/core/notebook/types';
import { saveDocument, createBlock } from '@/core/notebook/notebookStore';
import { exportToMarkdown, exportToLaTeX } from '@/core/notebook/exportUtils';
import MathView from '@/components/MathView';
import type { AppRoute } from '@/types/navigation';

// Structured Notebook Components
import NotebookHeader from '@/components/notebook/NotebookHeader';
import NotebookOutline from '@/components/notebook/NotebookOutline';
import AddBlockModal from '@/components/notebook/AddBlockModal';
import RelationshipPickerModal from '@/components/notebook/RelationshipPickerModal';

// Block Cards
import MathBlockCard from '@/components/notebook/MathBlockCard';
import CalculationBlockCard from '@/components/notebook/CalculationBlockCard';
import ProofBlockCard from '@/components/notebook/ProofBlockCard';
import TableBlockCard from '@/components/notebook/TableBlockCard';
import DefinitionBlockCard from '@/components/notebook/DefinitionBlockCard';
import ResultBlockCard from '@/components/notebook/ResultBlockCard';
import GraphBlockCard from '@/components/notebook/GraphBlockCard';
import DerivationBlockCard from '@/components/notebook/DerivationBlockCard';
import SectionBlockCard from '@/components/notebook/SectionBlockCard';

import {
  Plus,
  Trash2,
  Copy,
  ChevronUp,
  ChevronDown,
  Sparkles,
  Calculator,
  ShieldCheck,
  LineChart,
  Eye,
  FileText,
  AlertCircle,
} from 'lucide-react';

interface Props {
  document: MathDocument;
  onBack: () => void;
  onUpdate: (doc: MathDocument) => void;
  onNavigate?: (route: AppRoute, payload?: { expression?: string }) => void;
}

export default function NotebookEditor({
  document: initialDoc,
  onBack,
  onUpdate,
  onNavigate,
}: Props) {
  const [doc, setDoc] = useState<MathDocument>(initialDoc);
  const [title, setTitle] = useState(initialDoc.title);
  const [savedStatus, setSavedStatus] = useState<'saved' | 'saving'>('saved');

  // UI Panels & Modals
  const [outlineOpen, setOutlineOpen] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const [activeBlockId, setActiveBlockId] = useState<string | null>(null);

  // Add Block Modal
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [insertIndex, setInsertIndex] = useState<number | null>(null);

  // Relationship Modal
  const [relationshipSourceBlock, setRelationshipSourceBlock] = useState<MathBlock | null>(null);

  // Sync when initialDoc changes
  useEffect(() => {
    setTitle(initialDoc.title);
    setDoc(initialDoc);
  }, [initialDoc]);

  const commitDoc = (updatedDoc: MathDocument) => {
    setSavedStatus('saving');
    setDoc(updatedDoc);
    saveDocument(updatedDoc);
    onUpdate(updatedDoc);
    setTimeout(() => setSavedStatus('saved'), 350);
  };

  const handleTitleChange = (newTitle: string) => {
    setTitle(newTitle);
    commitDoc({ ...doc, title: newTitle });
  };

  const handleUpdateBlockContent = (blockId: string, patch: Record<string, unknown>) => {
    const nextBlocks = doc.blocks.map((b) =>
      b.id === blockId ? { ...b, content: { ...b.content, ...patch }, updatedAt: new Date().toISOString() } : b
    );
    commitDoc({ ...doc, blocks: nextBlocks });
  };

  const handleUpdateBlockMetadata = (blockId: string, patch: Partial<MathBlock['metadata']>) => {
    const nextBlocks = doc.blocks.map((b) =>
      b.id === blockId ? { ...b, metadata: { ...b.metadata, ...patch }, updatedAt: new Date().toISOString() } : b
    );
    commitDoc({ ...doc, blocks: nextBlocks });
  };

  const handleAddBlock = (type: BlockType, afterIndex?: number | null) => {
    const targetIdx = afterIndex !== undefined && afterIndex !== null ? afterIndex + 1 : doc.blocks.length;
    const newBlock = createBlock(type, targetIdx);

    const nextBlocks = [
      ...doc.blocks.slice(0, targetIdx),
      newBlock,
      ...doc.blocks.slice(targetIdx),
    ].map((b, i) => ({ ...b, position: i }));

    commitDoc({ ...doc, blocks: nextBlocks });
    setActiveBlockId(newBlock.id);

    // Scroll to new block
    setTimeout(() => {
      const el = window.document.getElementById(`block-${newBlock.id}`);
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  };

  const handleMoveBlock = (index: number, dir: -1 | 1) => {
    const targetIdx = index + dir;
    if (targetIdx < 0 || targetIdx >= doc.blocks.length) return;

    const nextBlocks = [...doc.blocks];
    const temp = nextBlocks[index];
    nextBlocks[index] = nextBlocks[targetIdx];
    nextBlocks[targetIdx] = temp;

    const indexed = nextBlocks.map((b, i) => ({ ...b, position: i }));
    commitDoc({ ...doc, blocks: indexed });
  };

  const handleDuplicateBlock = (index: number) => {
    const src = doc.blocks[index];
    const duplicated: MathBlock = {
      ...src,
      id: `b-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      position: index + 1,
      content: JSON.parse(JSON.stringify(src.content)),
      metadata: src.metadata ? JSON.parse(JSON.stringify(src.metadata)) : undefined,
      relationships: src.relationships ? JSON.parse(JSON.stringify(src.relationships)) : undefined,
    };

    const nextBlocks = [
      ...doc.blocks.slice(0, index + 1),
      duplicated,
      ...doc.blocks.slice(index + 1),
    ].map((b, i) => ({ ...b, position: i }));

    commitDoc({ ...doc, blocks: nextBlocks });
  };

  const handleDeleteBlock = (blockId: string) => {
    if (doc.blocks.length <= 1) return;
    const nextBlocks = doc.blocks
      .filter((b) => b.id !== blockId)
      .map((b, i) => ({ ...b, position: i }));
    commitDoc({ ...doc, blocks: nextBlocks });
  };

  const handleAddRelationship = (sourceBlockId: string, rel: BlockRelationship) => {
    const nextBlocks = doc.blocks.map((b) => {
      if (b.id === sourceBlockId) {
        const existing = b.relationships || [];
        // Prevent duplicate link to same target
        const filtered = existing.filter((r) => r.targetBlockId !== rel.targetBlockId);
        return { ...b, relationships: [...filtered, rel] };
      }
      return b;
    });
    commitDoc({ ...doc, blocks: nextBlocks });
    // Update active modal block reference
    const updatedSource = nextBlocks.find((b) => b.id === sourceBlockId);
    if (updatedSource) setRelationshipSourceBlock(updatedSource);
  };

  const handleRemoveRelationship = (sourceBlockId: string, targetBlockId: string) => {
    const nextBlocks = doc.blocks.map((b) => {
      if (b.id === sourceBlockId) {
        const existing = b.relationships || [];
        return { ...b, relationships: existing.filter((r) => r.targetBlockId !== targetBlockId) };
      }
      return b;
    });
    commitDoc({ ...doc, blocks: nextBlocks });
    // Update active modal block reference
    const updatedSource = nextBlocks.find((b) => b.id === sourceBlockId);
    if (updatedSource) setRelationshipSourceBlock(updatedSource);
  };

  const handleJumpToBlock = (targetBlockId: string) => {
    setActiveBlockId(targetBlockId);
    const el = window.document.getElementById(`block-${targetBlockId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('ring-2', 'ring-accent');
      setTimeout(() => el.classList.remove('ring-2', 'ring-accent'), 1400);
    }
  };

  const handleInsertRegressionEquation = (tableIndex: number, latex: string) => {
    const newMathBlock: MathBlock = {
      id: `b-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      type: 'math',
      position: tableIndex + 1,
      metadata: { label: 'Regression Model Equation' },
      relationships: [
        {
          targetBlockId: doc.blocks[tableIndex].id,
          type: 'derivedFrom',
          label: 'Fitted to Coordinate Table',
        },
      ],
      content: {
        latex,
        name: 'y(x)',
        description: 'Least-squares polynomial regression fit',
        showEvaluation: true,
      },
    };

    const nextBlocks = [
      ...doc.blocks.slice(0, tableIndex + 1),
      newMathBlock,
      ...doc.blocks.slice(tableIndex + 1),
    ].map((b, i) => ({ ...b, position: i }));

    commitDoc({ ...doc, blocks: nextBlocks });
    handleJumpToBlock(newMathBlock.id);
  };

  // Export handlers
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(doc, null, 2));
    const a = window.document.createElement('a');
    a.href = dataStr;
    a.download = `${doc.title.toLowerCase().replace(/[^a-z0-9]/g, '-')}.tifspace.json`;
    a.click();
  };

  const handleExportMarkdown = () => {
    const md = exportToMarkdown(doc);
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const a = window.document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${doc.title.toLowerCase().replace(/[^a-z0-9]/g, '-')}.md`;
    a.click();
  };

  const handleExportLaTeX = () => {
    const tex = exportToLaTeX(doc);
    const blob = new Blob([tex], { type: 'application/x-tex;charset=utf-8' });
    const a = window.document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${doc.title.toLowerCase().replace(/[^a-z0-9]/g, '-')}.tex`;
    a.click();
  };

  // Compute collapsed sections mask
  // A block is hidden if the closest preceding section is collapsed
  const blockVisibility = React.useMemo(() => {
    const visible: boolean[] = [];
    let currentSectionCollapsed = false;

    for (let i = 0; i < doc.blocks.length; i++) {
      const b = doc.blocks[i];
      if (b.type === 'section') {
        const sContent = b.content as SectionContent;
        currentSectionCollapsed = !!sContent.isCollapsed;
        visible.push(true); // Section header itself is always visible
      } else {
        visible.push(!currentSectionCollapsed);
      }
    }
    return visible;
  }, [doc.blocks]);

  // Compute number of child blocks per section
  const sectionChildCounts = React.useMemo(() => {
    const counts: { [key: string]: number } = {};
    let currentSecId: string | null = null;

    for (const b of doc.blocks) {
      if (b.type === 'section') {
        currentSecId = b.id;
        counts[currentSecId] = 0;
      } else if (currentSecId) {
        counts[currentSecId] = (counts[currentSecId] || 0) + 1;
      }
    }
    return counts;
  }, [doc.blocks]);

  return (
    <div className="flex h-full flex-col overflow-hidden bg-canvas">
      {/* 1. Structured Notebook Header */}
      <NotebookHeader
        title={title}
        subject={doc.subject}
        blockCount={doc.blocks.length}
        savedStatus={savedStatus}
        outlineOpen={outlineOpen}
        searchOpen={searchOpen}
        onBack={onBack}
        onTitleChange={handleTitleChange}
        onToggleOutline={() => setOutlineOpen(!outlineOpen)}
        onToggleSearch={() => {
          setSearchOpen(!searchOpen);
          if (!outlineOpen) setOutlineOpen(true);
        }}
        onAddBlockClick={() => {
          setInsertIndex(null);
          setAddModalOpen(true);
        }}
        onExportMarkdown={handleExportMarkdown}
        onExportJSON={handleExportJSON}
        onExportLaTeX={handleExportLaTeX}
      />

      {/* 2. Workspace Body (Outline Navigator + Structured Canvas) */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Left Navigator / Outline Drawer */}
        <NotebookOutline
          blocks={doc.blocks}
          activeBlockId={activeBlockId}
          isOpen={outlineOpen}
          onSelectBlock={handleJumpToBlock}
          onAddBlock={() => {
            setInsertIndex(null);
            setAddModalOpen(true);
          }}
          onClose={() => setOutlineOpen(false)}
        />

        {/* Central Mathematical Canvas */}
        <main className="flex-1 overflow-y-auto px-4 py-8 sm:px-8 lg:px-16" id="notebook-canvas">
          <div className="mx-auto max-w-4xl space-y-4">
            {/* Empty Workspace State */}
            {doc.blocks.length === 0 ? (
              <div className="rounded-3xl border border-line bg-panel/60 p-12 text-center shadow-xs">
                <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-accent/15 text-accent">
                  <Sparkles className="h-7 w-7" />
                </div>
                <h3 className="text-base font-bold text-ink">
                  Mathematical Workspace Ready
                </h3>
                <p className="mt-1 text-xs text-muted max-w-md mx-auto leading-relaxed">
                  Build your mathematical workspace by assembling structured entities: equations, real-time calculations, formal proofs, and coordinate curves.
                </p>

                <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-lg mx-auto">
                  <button
                    type="button"
                    onClick={() => handleAddBlock('math')}
                    className="flex flex-col items-center gap-2 rounded-2xl border border-line bg-field/50 p-4 hover:border-accent hover:bg-field transition-all"
                  >
                    <Sparkles className="h-5 w-5 text-accent" />
                    <span className="text-xs font-bold text-ink">+ Equation</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddBlock('calculation')}
                    className="flex flex-col items-center gap-2 rounded-2xl border border-line bg-field/50 p-4 hover:border-amber-500 hover:bg-field transition-all"
                  >
                    <Calculator className="h-5 w-5 text-amber-400" />
                    <span className="text-xs font-bold text-ink">+ Calculation</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddBlock('proof')}
                    className="flex flex-col items-center gap-2 rounded-2xl border border-line bg-field/50 p-4 hover:border-emerald-500 hover:bg-field transition-all"
                  >
                    <ShieldCheck className="h-5 w-5 text-emerald-400" />
                    <span className="text-xs font-bold text-ink">+ Formal Proof</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAddBlock('graph')}
                    className="flex flex-col items-center gap-2 rounded-2xl border border-line bg-field/50 p-4 hover:border-blue-500 hover:bg-field transition-all"
                  >
                    <LineChart className="h-5 w-5 text-blue-400" />
                    <span className="text-xs font-bold text-ink">+ Graph</span>
                  </button>
                </div>
              </div>
            ) : (
              doc.blocks.map((block, idx) => {
                const isVisible = blockVisibility[idx];
                if (!isVisible) return null;

                const isFirst = idx === 0;
                const isLast = idx === doc.blocks.length - 1;

                return (
                  <React.Fragment key={block.id}>
                    {/* In-Between Insertion Handle */}
                    <div className="group/divider relative flex items-center justify-center py-1 opacity-0 hover:opacity-100 focus-within:opacity-100 transition-opacity">
                      <div className="absolute inset-x-0 h-px bg-dashed border-t border-line" />
                      <button
                        type="button"
                        onClick={() => {
                          setInsertIndex(idx - 1);
                          setAddModalOpen(true);
                        }}
                        className="relative z-10 flex items-center gap-1 rounded-full border border-line bg-panel px-2.5 py-0.5 text-[10px] font-semibold text-muted hover:border-accent hover:text-accent shadow-xs transition-colors"
                      >
                        <Plus className="h-3 w-3" />
                        <span>Insert Object</span>
                      </button>
                    </div>

                    {/* Block Card Renderers */}
                    {block.type === 'section' && (
                      <SectionBlockCard
                        block={block}
                        childCount={sectionChildCounts[block.id] || 0}
                        isFirst={isFirst}
                        isLast={isLast}
                        onUpdate={(patch) => handleUpdateBlockContent(block.id, patch)}
                        onMove={(dir) => handleMoveBlock(idx, dir)}
                        onDuplicate={() => handleDuplicateBlock(idx)}
                        onDelete={() => handleDeleteBlock(block.id)}
                      />
                    )}

                    {block.type === 'math' && (
                      <MathBlockCard
                        block={block}
                        isFirst={isFirst}
                        isLast={isLast}
                        onUpdate={(patch) => handleUpdateBlockContent(block.id, patch)}
                        onUpdateMetadata={(patch) => handleUpdateBlockMetadata(block.id, patch)}
                        onMove={(dir) => handleMoveBlock(idx, dir)}
                        onDuplicate={() => handleDuplicateBlock(idx)}
                        onDelete={() => handleDeleteBlock(block.id)}
                        onOpenLinkModal={() => setRelationshipSourceBlock(block)}
                        onJumpToBlock={handleJumpToBlock}
                        onPlot={(expr) => onNavigate?.('lab', { expression: expr })}
                      />
                    )}

                    {block.type === 'calculation' && (
                      <CalculationBlockCard
                        block={block}
                        isFirst={isFirst}
                        isLast={isLast}
                        onUpdate={(patch) => handleUpdateBlockContent(block.id, patch)}
                        onUpdateMetadata={(patch) => handleUpdateBlockMetadata(block.id, patch)}
                        onMove={(dir) => handleMoveBlock(idx, dir)}
                        onDuplicate={() => handleDuplicateBlock(idx)}
                        onDelete={() => handleDeleteBlock(block.id)}
                        onOpenLinkModal={() => setRelationshipSourceBlock(block)}
                        onJumpToBlock={handleJumpToBlock}
                      />
                    )}

                    {block.type === 'proof' && (
                      <ProofBlockCard
                        block={block}
                        isFirst={isFirst}
                        isLast={isLast}
                        onUpdate={(patch) => handleUpdateBlockContent(block.id, patch)}
                        onUpdateMetadata={(patch) => handleUpdateBlockMetadata(block.id, patch)}
                        onMove={(dir) => handleMoveBlock(idx, dir)}
                        onDuplicate={() => handleDuplicateBlock(idx)}
                        onDelete={() => handleDeleteBlock(block.id)}
                        onOpenLinkModal={() => setRelationshipSourceBlock(block)}
                        onJumpToBlock={handleJumpToBlock}
                      />
                    )}

                    {block.type === 'table' && (
                      <TableBlockCard
                        block={block}
                        isFirst={isFirst}
                        isLast={isLast}
                        onUpdate={(patch) => handleUpdateBlockContent(block.id, patch)}
                        onUpdateMetadata={(patch) => handleUpdateBlockMetadata(block.id, patch)}
                        onMove={(dir) => handleMoveBlock(idx, dir)}
                        onDuplicate={() => handleDuplicateBlock(idx)}
                        onDelete={() => handleDeleteBlock(block.id)}
                        onOpenLinkModal={() => setRelationshipSourceBlock(block)}
                        onJumpToBlock={handleJumpToBlock}
                        onInsertRegressionEquation={(latex) => handleInsertRegressionEquation(idx, latex)}
                      />
                    )}

                    {block.type === 'definition' && (
                      <DefinitionBlockCard
                        block={block}
                        isFirst={isFirst}
                        isLast={isLast}
                        onUpdate={(patch) => handleUpdateBlockContent(block.id, patch)}
                        onUpdateMetadata={(patch) => handleUpdateBlockMetadata(block.id, patch)}
                        onMove={(dir) => handleMoveBlock(idx, dir)}
                        onDuplicate={() => handleDuplicateBlock(idx)}
                        onDelete={() => handleDeleteBlock(block.id)}
                        onOpenLinkModal={() => setRelationshipSourceBlock(block)}
                        onJumpToBlock={handleJumpToBlock}
                      />
                    )}

                    {block.type === 'result' && (
                      <ResultBlockCard
                        block={block}
                        isFirst={isFirst}
                        isLast={isLast}
                        onUpdate={(patch) => handleUpdateBlockContent(block.id, patch)}
                        onUpdateMetadata={(patch) => handleUpdateBlockMetadata(block.id, patch)}
                        onMove={(dir) => handleMoveBlock(idx, dir)}
                        onDuplicate={() => handleDuplicateBlock(idx)}
                        onDelete={() => handleDeleteBlock(block.id)}
                        onOpenLinkModal={() => setRelationshipSourceBlock(block)}
                        onJumpToBlock={handleJumpToBlock}
                      />
                    )}

                    {block.type === 'graph' && (
                      <GraphBlockCard
                        block={block}
                        isFirst={isFirst}
                        isLast={isLast}
                        onUpdate={(patch) => handleUpdateBlockContent(block.id, patch)}
                        onUpdateMetadata={(patch) => handleUpdateBlockMetadata(block.id, patch)}
                        onMove={(dir) => handleMoveBlock(idx, dir)}
                        onDuplicate={() => handleDuplicateBlock(idx)}
                        onDelete={() => handleDeleteBlock(block.id)}
                        onOpenLinkModal={() => setRelationshipSourceBlock(block)}
                        onJumpToBlock={handleJumpToBlock}
                        onOpenInLab={(expr) => onNavigate?.('lab', { expression: expr })}
                      />
                    )}

                    {block.type === 'derivation' && (
                      <DerivationBlockCard
                        block={block}
                        isFirst={isFirst}
                        isLast={isLast}
                        onUpdate={(patch) => handleUpdateBlockContent(block.id, patch)}
                        onUpdateMetadata={(patch) => handleUpdateBlockMetadata(block.id, patch)}
                        onMove={(dir) => handleMoveBlock(idx, dir)}
                        onDuplicate={() => handleDuplicateBlock(idx)}
                        onDelete={() => handleDeleteBlock(block.id)}
                        onOpenLinkModal={() => setRelationshipSourceBlock(block)}
                        onJumpToBlock={handleJumpToBlock}
                      />
                    )}

                    {block.type === 'heading' && (
                      <div id={`block-${block.id}`} className="group relative rounded-2xl border border-transparent hover:border-line bg-panel/30 p-3 transition-colors">
                        <HeadingBlockRenderer
                          content={block.content as HeadingContent}
                          onChange={(patch) => handleUpdateBlockContent(block.id, patch)}
                        />
                        <div className="absolute top-2 right-2 hidden group-hover:flex items-center gap-1 rounded-lg border border-line bg-panel p-1">
                          <button type="button" onClick={() => handleMoveBlock(idx, -1)} disabled={isFirst} className="p-1 text-muted hover:text-ink disabled:opacity-20"><ChevronUp className="h-3 w-3" /></button>
                          <button type="button" onClick={() => handleMoveBlock(idx, 1)} disabled={isLast} className="p-1 text-muted hover:text-ink disabled:opacity-20"><ChevronDown className="h-3 w-3" /></button>
                          <button type="button" onClick={() => handleDuplicateBlock(idx)} className="p-1 text-muted hover:text-ink"><Copy className="h-3 w-3" /></button>
                          <button type="button" onClick={() => handleDeleteBlock(block.id)} className="p-1 text-muted hover:text-danger"><Trash2 className="h-3 w-3" /></button>
                        </div>
                      </div>
                    )}

                    {block.type === 'paragraph' && (
                      <div id={`block-${block.id}`} className="group relative rounded-2xl border border-transparent hover:border-line bg-panel/30 p-3 transition-colors">
                        <ParagraphBlockRenderer
                          content={block.content as ParagraphContent}
                          onChange={(patch) => handleUpdateBlockContent(block.id, patch)}
                        />
                        <div className="absolute top-2 right-2 hidden group-hover:flex items-center gap-1 rounded-lg border border-line bg-panel p-1">
                          <button type="button" onClick={() => handleMoveBlock(idx, -1)} disabled={isFirst} className="p-1 text-muted hover:text-ink disabled:opacity-20"><ChevronUp className="h-3 w-3" /></button>
                          <button type="button" onClick={() => handleMoveBlock(idx, 1)} disabled={isLast} className="p-1 text-muted hover:text-ink disabled:opacity-20"><ChevronDown className="h-3 w-3" /></button>
                          <button type="button" onClick={() => handleDuplicateBlock(idx)} className="p-1 text-muted hover:text-ink"><Copy className="h-3 w-3" /></button>
                          <button type="button" onClick={() => handleDeleteBlock(block.id)} className="p-1 text-muted hover:text-danger"><Trash2 className="h-3 w-3" /></button>
                        </div>
                      </div>
                    )}

                    {block.type === 'callout' && (
                      <div id={`block-${block.id}`} className="group relative">
                        <CalloutBlockRenderer
                          content={block.content as CalloutContent}
                          onChange={(patch) => handleUpdateBlockContent(block.id, patch)}
                        />
                        <div className="absolute top-2 right-2 hidden group-hover:flex items-center gap-1 rounded-lg border border-line bg-panel p-1">
                          <button type="button" onClick={() => handleMoveBlock(idx, -1)} disabled={isFirst} className="p-1 text-muted hover:text-ink disabled:opacity-20"><ChevronUp className="h-3 w-3" /></button>
                          <button type="button" onClick={() => handleMoveBlock(idx, 1)} disabled={isLast} className="p-1 text-muted hover:text-ink disabled:opacity-20"><ChevronDown className="h-3 w-3" /></button>
                          <button type="button" onClick={() => handleDuplicateBlock(idx)} className="p-1 text-muted hover:text-ink"><Copy className="h-3 w-3" /></button>
                          <button type="button" onClick={() => handleDeleteBlock(block.id)} className="p-1 text-muted hover:text-danger"><Trash2 className="h-3 w-3" /></button>
                        </div>
                      </div>
                    )}

                    {block.type === 'divider' && (
                      <div id={`block-${block.id}`} className="py-2">
                        <hr className="border-line/70" />
                      </div>
                    )}
                  </React.Fragment>
                );
              })
            )}

            {/* Bottom Add Object Bar */}
            {doc.blocks.length > 0 && (
              <div className="flex justify-center pt-6 pb-16">
                <button
                  type="button"
                  onClick={() => {
                    setInsertIndex(doc.blocks.length - 1);
                    setAddModalOpen(true);
                  }}
                  className="flex items-center gap-2 rounded-2xl border border-line bg-panel px-5 py-2.5 text-xs font-bold text-ink shadow-sm hover:border-accent hover:text-accent transition-all"
                >
                  <Plus className="h-4 w-4 text-accent" />
                  <span>Insert Mathematical Object</span>
                </button>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Categorized Add Block Modal */}
      <AddBlockModal
        isOpen={addModalOpen}
        insertIndex={insertIndex}
        onClose={() => {
          setAddModalOpen(false);
          setInsertIndex(null);
        }}
        onSelect={(type, index) => handleAddBlock(type, index)}
      />

      {/* Mathematical Relationships Link Modal */}
      <RelationshipPickerModal
        isOpen={!!relationshipSourceBlock}
        sourceBlock={relationshipSourceBlock}
        allBlocks={doc.blocks}
        onClose={() => setRelationshipSourceBlock(null)}
        onAddRelationship={handleAddRelationship}
        onRemoveRelationship={handleRemoveRelationship}
      />
    </div>
  );
}

/** Heading renderer */
function HeadingBlockRenderer({
  content,
  onChange,
}: {
  content: HeadingContent;
  onChange: (patch: Partial<HeadingContent>) => void;
}) {
  const level = content.level || 2;
  const classes =
    level === 1
      ? 'text-2xl font-extrabold text-ink tracking-tight'
      : level === 2
      ? 'text-xl font-bold text-ink tracking-tight'
      : 'text-base font-bold text-ink';

  return (
    <div className="flex items-center gap-2">
      <input
        type="text"
        value={content.text}
        onChange={(e) => onChange({ text: e.target.value })}
        className={`w-full bg-transparent focus:outline-none ${classes}`}
        placeholder="Section Heading..."
      />
      <div className="flex rounded-md border border-line bg-field p-0.5 text-[10px] shrink-0">
        {[1, 2, 3].map((lvl) => (
          <button
            key={lvl}
            type="button"
            onClick={() => onChange({ level: lvl as any })}
            className={`px-1.5 py-0.5 font-bold rounded ${
              level === lvl ? 'bg-accent text-accent-ink' : 'text-muted hover:text-ink'
            }`}
          >
            H{lvl}
          </button>
        ))}
      </div>
    </div>
  );
}

/** Paragraph renderer */
function ParagraphBlockRenderer({
  content,
  onChange,
}: {
  content: ParagraphContent;
  onChange: (patch: Partial<ParagraphContent>) => void;
}) {
  const [editing, setEditing] = useState(false);

  return (
    <div onClick={() => !editing && setEditing(true)}>
      {editing ? (
        <textarea
          value={content.text}
          onChange={(e) => onChange({ text: e.target.value })}
          onBlur={() => setEditing(false)}
          rows={2}
          className="w-full resize-y rounded-xl border border-line bg-panel p-2.5 text-xs text-ink leading-relaxed placeholder-muted focus:border-accent focus:outline-none font-sans"
          placeholder="Type mathematical notes, rationale, observations..."
          autoFocus
        />
      ) : (
        <div className="cursor-text rounded-xl p-2 text-xs text-ink leading-relaxed min-h-[2rem]">
          {content.text ? (
            <MathView math={content.text} />
          ) : (
            <span className="text-muted italic">Click to add mathematical explanation...</span>
          )}
        </div>
      )}
    </div>
  );
}

/** Callout renderer */
function CalloutBlockRenderer({
  content,
  onChange,
}: {
  content: CalloutContent;
  onChange: (patch: Partial<CalloutContent>) => void;
}) {
  const kind = content.kind || 'note';
  const borderClass =
    kind === 'theorem'
      ? 'border-accent bg-accent/10 text-accent'
      : kind === 'definition'
      ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400'
      : 'border-blue-500 bg-blue-500/10 text-blue-400';

  return (
    <div className={`rounded-2xl border-l-4 p-4 shadow-xs ${borderClass}`}>
      <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider">
        <input
          type="text"
          value={content.title || kind}
          onChange={(e) => onChange({ title: e.target.value })}
          className="bg-transparent font-bold focus:outline-none"
        />
      </div>
      <div className="mt-2 text-xs text-ink leading-relaxed font-serif">
        <textarea
          rows={2}
          value={content.text}
          onChange={(e) => onChange({ text: e.target.value })}
          className="w-full bg-transparent resize-y focus:outline-none text-ink text-xs font-serif leading-relaxed"
          placeholder="Statement text or property..."
        />
      </div>
    </div>
  );
}
