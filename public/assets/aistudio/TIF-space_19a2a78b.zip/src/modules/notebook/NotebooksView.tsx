'use client';

import { useState, useEffect } from 'react';
import type { AppRoute } from '@/types/navigation';
import type { MathDocument } from '@/core/notebook/types';
import {
  getDocuments,
  createDocument,
  deleteDocument,
  duplicateDocument,
} from '@/core/notebook/notebookStore';
import NotebookEditor from './NotebookEditor';
import {
  BookOpen,
  Plus,
  Trash2,
  Copy,
  Clock,
  ArrowRight,
  Search,
  Sparkles,
  FileText,
} from 'lucide-react';

interface NotebooksViewProps {
  onNavigate: (route: AppRoute) => void;
}

export default function NotebooksView({ onNavigate }: NotebooksViewProps) {
  const [documents, setDocuments] = useState<MathDocument[]>([]);
  const [activeDocId, setActiveDocId] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const refreshDocs = () => {
    setDocuments(getDocuments());
  };

  useEffect(() => {
    refreshDocs();
  }, []);

  const handleCreateNew = () => {
    const newDoc = createDocument('New Mathematical Exploration');
    refreshDocs();
    setActiveDocId(newDoc.id);
  };

  const handleDuplicate = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    duplicateDocument(id);
    refreshDocs();
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this notebook?')) {
      deleteDocument(id);
      refreshDocs();
      if (activeDocId === id) setActiveDocId(null);
    }
  };

  const filtered = documents.filter((d) => {
    const q = search.toLowerCase().trim();
    if (!q) return true;
    return (
      d.title.toLowerCase().includes(q) ||
      (d.tags && d.tags.some((t) => t.toLowerCase().includes(q)))
    );
  });

  const activeDoc = documents.find((d) => d.id === activeDocId);

  // If a notebook is open, render NotebookEditor
  if (activeDoc) {
    return (
      <NotebookEditor
        document={activeDoc}
        onBack={() => {
          setActiveDocId(null);
          refreshDocs();
        }}
        onUpdate={() => refreshDocs()}
        onNavigate={onNavigate}
      />
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-5xl space-y-6">
        {/* Header */}
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">
                Mathematical Notebooks
              </h1>
              <span className="flex items-center gap-1 rounded-full bg-accent/15 px-2.5 py-0.5 text-xs font-semibold text-accent">
                <Sparkles className="h-3 w-3" />
                <span>Structured Blocks</span>
              </span>
            </div>
            <p className="text-xs text-muted sm:text-sm">
              Create and edit structured mathematical notebooks with embedded KaTeX equations, derivation steps, coordinate tables, and live graphs.
            </p>
          </div>

          <button
            type="button"
            onClick={handleCreateNew}
            className="flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-xs font-semibold text-accent-ink shadow-sm transition-all hover:opacity-90"
          >
            <Plus className="h-4 w-4" />
            <span>New Notebook</span>
          </button>
        </div>

        {/* Search Filter */}
        <div className="relative">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-muted" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search notebooks by title or tag..."
            className="w-full rounded-xl border border-line bg-panel py-2.5 pl-10 pr-4 text-xs text-ink placeholder-muted focus:border-accent focus:outline-none"
          />
        </div>

        {/* Notebook Cards Grid */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((nb) => {
            const dateStr = new Date(nb.updatedAt).toLocaleDateString([], {
              month: 'short',
              day: 'numeric',
            });

            return (
              <div
                key={nb.id}
                onClick={() => setActiveDocId(nb.id)}
                className="group flex cursor-pointer flex-col justify-between rounded-2xl border border-line bg-panel p-5 transition-all hover:border-accent/50 hover:bg-field/40 hover:shadow-lg"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="grid h-10 w-10 place-items-center rounded-xl border border-line bg-field text-accent">
                      <BookOpen className="h-5 w-5" />
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        onClick={(e) => handleDuplicate(e, nb.id)}
                        className="grid h-7 w-7 place-items-center rounded text-muted hover:text-ink hover:bg-panel"
                        title="Duplicate notebook"
                      >
                        <Copy className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handleDelete(e, nb.id)}
                        className="grid h-7 w-7 place-items-center rounded text-muted hover:text-danger hover:bg-panel"
                        title="Delete notebook"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-ink group-hover:text-accent transition-colors">
                      {nb.title}
                    </h3>
                    <p className="mt-1 text-xs text-muted">
                      {nb.blocks?.length || 0} blocks
                    </p>
                  </div>
                </div>

                <div className="mt-5 border-t border-line/60 pt-3">
                  <div className="flex flex-wrap gap-1.5 mb-2.5">
                    {nb.tags?.map((t) => (
                      <span key={t} className="rounded-md bg-field px-2 py-0.5 text-[10px] text-muted">
                        #{t}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-muted">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      <span>{dateStr}</span>
                    </span>
                    <span className="flex items-center gap-1 font-semibold text-accent group-hover:translate-x-0.5 transition-transform">
                      <span>Open Document</span>
                      <ArrowRight className="h-3 w-3" />
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
