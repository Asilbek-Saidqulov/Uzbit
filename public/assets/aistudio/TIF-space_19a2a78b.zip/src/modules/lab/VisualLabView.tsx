'use client';

import { useState } from 'react';
import type { AppRoute, LabTab } from '@/types/navigation';
import type { Theme } from '@/lib/theme';
import GraphingLab from '@/modules/graphing/GraphingLab';
import GeometryLabView from '@/modules/geometry/GeometryLabView';
import { LineChart, Shapes } from 'lucide-react';

interface VisualLabViewProps {
  theme?: Theme;
  onToggleTheme?: () => void;
  initialTab?: LabTab;
  initialExpression?: string;
  onNavigate: (route: AppRoute, payload?: { expression?: string }) => void;
}

export default function VisualLabView({
  theme,
  onToggleTheme,
  initialTab = 'graphing',
  initialExpression,
  onNavigate,
}: VisualLabViewProps) {
  const [activeTab, setActiveTab] = useState<LabTab>(initialTab);

  return (
    <div className="flex h-full flex-col overflow-hidden bg-canvas">
      {/* Sub-Header Lab Navigation Switcher */}
      <div className="flex h-11 shrink-0 items-center justify-between border-b border-line bg-panel/80 px-3 sm:px-4 backdrop-blur-xs select-none">
        <div className="flex items-center gap-1.5 sm:gap-2">
          <div className="flex rounded-lg border border-line bg-field p-0.5 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('graphing')}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1 transition-all ${
                activeTab === 'graphing'
                  ? 'bg-panel text-ink shadow-xs font-bold'
                  : 'text-muted hover:text-ink'
              }`}
            >
              <LineChart className="h-3.5 w-3.5 text-accent" />
              <span>Function Graphing</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('geometry')}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1 transition-all ${
                activeTab === 'geometry'
                  ? 'bg-panel text-ink shadow-xs font-bold'
                  : 'text-muted hover:text-ink'
              }`}
            >
              <Shapes className="h-3.5 w-3.5 text-amber-400" />
              <span>Geometry Sandbox</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-muted">
          <span className="hidden sm:inline">
            {activeTab === 'graphing'
              ? 'JSXGraph · Adaptive Quadrature & Analysis'
              : 'Euclidean Vector Construction Engine'}
          </span>
        </div>
      </div>

      {/* Main Studio Viewport */}
      <div className="relative flex-1 min-h-0 min-w-0 overflow-hidden">
        {activeTab === 'graphing' ? (
          <GraphingLab
            theme={theme}
            onToggleTheme={onToggleTheme}
            initialExpression={initialExpression}
          />
        ) : (
          <GeometryLabView onNavigate={onNavigate} />
        )}
      </div>
    </div>
  );
}

