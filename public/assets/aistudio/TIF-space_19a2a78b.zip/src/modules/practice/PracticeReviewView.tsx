'use client';

import { useState } from 'react';
import type { AppRoute } from '@/types/navigation';
import MathView from '@/components/MathView';
import {
  GraduationCap,
  CheckCircle2,
  XCircle,
  ArrowRight,
  Sparkles,
  Flame,
  Award,
  RotateCcw,
  Target,
} from 'lucide-react';

interface PracticeReviewViewProps {
  onNavigate: (route: AppRoute, payload?: { expression?: string }) => void;
}

interface Question {
  id: string;
  category: 'Calculus' | 'Trigonometry' | 'Algebra' | 'Geometry' | 'Statistics';
  title: string;
  prompt: string;
  equation: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  graphExpr?: string;
  calcExpr?: string;
}

const QUESTION_BANK: Question[] = [
  {
    id: 'q-1',
    category: 'Calculus',
    title: 'Definite Integration',
    prompt: 'Evaluate the exact value of the definite integral:',
    equation: '\\int_{0}^{2} (x^2 - 4)\\,dx',
    options: ['-\\frac{16}{3}', '-4', '\\frac{16}{3}', '-\\frac{8}{3}'],
    correctIndex: 0,
    explanation: '\\int_{0}^{2} (x^2 - 4)\\,dx = \\left[ \\frac{x^3}{3} - 4x \\right]_{0}^{2} = \\left(\\frac{8}{3} - 8\\right) - 0 = -\\frac{16}{3} \\approx -5.333',
    graphExpr: 'f(x) = x^2 - 4',
  },
  {
    id: 'q-2',
    category: 'Calculus',
    title: 'Numerical Differentiation',
    prompt: 'Find the slope of the tangent line to f(x) at x = 3:',
    equation: 'f(x) = x^2 - 4 \\quad \\text{at } x = 3',
    options: ['2', '6', '5', '9'],
    correctIndex: 1,
    explanation: 'f\'(x) = \\frac{d}{dx}(x^2 - 4) = 2x. \\quad \\text{Evaluating at } x = 3: \\; f\'(3) = 2(3) = 6.',
    graphExpr: 'f(x) = x^2 - 4',
  },
  {
    id: 'q-3',
    category: 'Trigonometry',
    title: 'Trigonometric Exact Values',
    prompt: 'Determine the exact sum of the trigonometric ratios:',
    equation: '\\sin\\left(\\frac{\\pi}{4}\\right) + \\cos\\left(\\frac{\\pi}{4}\\right)',
    options: ['\\sqrt{2}', '1', '\\frac{\\sqrt{2}}{2}', '2'],
    correctIndex: 0,
    explanation: '\\sin\\left(\\frac{\\pi}{4}\\right) = \\frac{\\sqrt{2}}{2}, \\quad \\cos\\left(\\frac{\\pi}{4}\\right) = \\frac{\\sqrt{2}}{2}. \\quad \\text{Sum} = \\frac{\\sqrt{2}}{2} + \\frac{\\sqrt{2}}{2} = \\sqrt{2} \\approx 1.4142.',
    graphExpr: 'y = sin(x) + cos(x)',
  },
  {
    id: 'q-4',
    category: 'Algebra',
    title: 'Quadratic Discriminant',
    prompt: 'What is the discriminant Δ of the quadratic polynomial?',
    equation: 'P(x) = 2x^2 - 4x + 2',
    options: ['0', '16', '-16', '32'],
    correctIndex: 0,
    explanation: '\\Delta = b^2 - 4ac = (-4)^2 - 4(2)(2) = 16 - 16 = 0. Since \\Delta = 0, the polynomial has exactly one real double root at x = 1.',
    graphExpr: 'y = 2x^2 - 4x + 2',
  },
  {
    id: 'q-5',
    category: 'Geometry',
    title: 'Hypotenuse Length',
    prompt: 'Compute the exact hypotenuse length of a right triangle with legs a = 3 and b = 4:',
    equation: 'c = \\sqrt{a^2 + b^2}',
    options: ['5', '7', '\\sqrt{7}', '25'],
    correctIndex: 0,
    explanation: 'c = \\sqrt{3^2 + 4^2} = \\sqrt{9 + 16} = \\sqrt{25} = 5.',
    calcExpr: 'sqrt(3^2 + 4^2)',
  },
  {
    id: 'q-6',
    category: 'Statistics',
    title: 'Sample Mean',
    prompt: 'Calculate the arithmetic mean of the dataset {2, 4, 6, 8, 10}:',
    equation: '\\bar{x} = \\frac{1}{n} \\sum_{i=1}^{n} x_i',
    options: ['6', '5', '30', '8'],
    correctIndex: 0,
    explanation: '\\bar{x} = \\frac{2 + 4 + 6 + 8 + 10}{5} = \\frac{30}{5} = 6.',
    calcExpr: '(2 + 4 + 6 + 8 + 10) / 5',
  },
  {
    id: 'q-7',
    category: 'Calculus',
    title: 'Chain Rule Differentiation',
    prompt: 'Find the first derivative of the composite function f(x) = sin(x²):',
    equation: '\\frac{d}{dx} \\sin(x^2)',
    options: ['2x\\cos(x^2)', '\\cos(x^2)', '2x\\sin(x^2)', '-\\cos(2x)'],
    correctIndex: 0,
    explanation: '\\text{By the chain rule: } \\frac{d}{dx}[f(g(x))] = f\'(g(x)) \\cdot g\'(x). \\quad \\text{Here } g(x)=x^2, \\, f(u)=\\sin(u) \\implies 2x\\cos(x^2).',
    graphExpr: 'y = sin(x^2)',
  },
  {
    id: 'q-8',
    category: 'Algebra',
    title: 'Logarithmic Quotient Property',
    prompt: 'Simplify the logarithmic difference into a single equivalent term:',
    equation: '\\ln(8) - \\ln(2)',
    options: ['\\ln(4)', '\\ln(6)', '4', '\\ln(16)'],
    correctIndex: 0,
    explanation: '\\ln(a) - \\ln(b) = \\ln\\left(\\frac{a}{b}\\right). \\quad \\ln\\left(\\frac{8}{2}\\right) = \\ln(4) = 2\\ln(2) \\approx 1.386.',
    calcExpr: 'ln(8) - ln(2)',
  },
  {
    id: 'q-9',
    category: 'Algebra',
    title: 'Vector Dot Product & Orthogonality',
    prompt: 'Compute the Euclidean dot product of vectors u = [3, -2] and v = [4, 6]:',
    equation: '\\mathbf{u} \\cdot \\mathbf{v} = (3)(4) + (-2)(6)',
    options: ['0', '24', '-12', '12'],
    correctIndex: 0,
    explanation: '(3)(4) + (-2)(6) = 12 - 12 = 0. Since the dot product is zero, the vectors are mutually orthogonal (perpendicular).',
    calcExpr: '3*4 + (-2)*6',
  },
  {
    id: 'q-10',
    category: 'Geometry',
    title: 'Circle Area Scaling Law',
    prompt: 'If the radius of a circle is tripled (r → 3r), by what factor does its surface area expand?',
    equation: 'A = \\pi r^2',
    options: ['9', '3', '6', '27'],
    correctIndex: 0,
    explanation: 'A_{\\text{new}} = \\pi (3r)^2 = 9\\pi r^2 = 9A. Geometric area scales quadrically with linear dimension scale: 3^2 = 9.',
    graphExpr: 'x^2 + y^2 = 9',
  },
];

export default function PracticeReviewView({ onNavigate }: PracticeReviewViewProps) {
  const [selectedCat, setSelectedCat] = useState<string>('All');
  const [activeQuestionIdx, setActiveQuestionIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);

  // Score tracker
  const [score, setScore] = useState({ correct: 0, total: 0, streak: 0 });

  const categories = ['All', 'Calculus', 'Trigonometry', 'Algebra', 'Geometry', 'Statistics'];

  const filteredQuestions = QUESTION_BANK.filter(
    (q) => selectedCat === 'All' || q.category === selectedCat
  );

  const safeIdx = Math.min(activeQuestionIdx, filteredQuestions.length - 1);
  const currentQ = filteredQuestions[safeIdx] || QUESTION_BANK[0];

  const handleSubmit = () => {
    if (selectedOption === null || submitted) return;
    setSubmitted(true);
    const isCorrect = selectedOption === currentQ.correctIndex;
    setScore((prev) => ({
      correct: isCorrect ? prev.correct + 1 : prev.correct,
      total: prev.total + 1,
      streak: isCorrect ? prev.streak + 1 : 0,
    }));
  };

  const handleNext = () => {
    setSubmitted(false);
    setSelectedOption(null);
    setActiveQuestionIdx((prev) => (prev + 1) % filteredQuestions.length);
  };

  const handleResetScore = () => {
    setScore({ correct: 0, total: 0, streak: 0 });
    setSubmitted(false);
    setSelectedOption(null);
    setActiveQuestionIdx(0);
  };

  const accuracy = score.total > 0 ? Math.round((score.correct / score.total) * 100) : 100;

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-4xl space-y-6">
        {/* Header */}
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">
                Practice & Review Studio
              </h1>
              <span className="flex items-center gap-1 rounded-full bg-violet-500/15 px-2.5 py-0.5 text-xs font-semibold text-violet-400">
                <Sparkles className="h-3 w-3" />
                <span>Adaptive Problem Bank</span>
              </span>
            </div>
            <p className="text-xs text-muted sm:text-sm">
              Sharpen your mathematical intuition with step-by-step calculus proofs, algebra, geometry, and real-time mastery tracking.
            </p>
          </div>

          {/* Live Progress Stats Banner */}
          <div className="flex items-center gap-3 rounded-2xl border border-line bg-panel p-2.5 px-4 shadow-sm text-xs">
            <div className="flex items-center gap-1.5">
              <Target className="h-4 w-4 text-accent" />
              <span className="text-muted">Accuracy:</span>
              <span className="font-mono font-bold text-ink">{score.total > 0 ? `${accuracy}%` : '—'}</span>
            </div>

            <div className="h-4 w-px bg-line" />

            <div className="flex items-center gap-1.5">
              <Award className="h-4 w-4 text-emerald-400" />
              <span className="text-muted">Score:</span>
              <span className="font-mono font-bold text-ink">{score.correct}/{score.total}</span>
            </div>

            {score.streak > 1 && (
              <>
                <div className="h-4 w-px bg-line" />
                <div className="flex items-center gap-1 text-amber-400 font-bold">
                  <Flame className="h-4 w-4" />
                  <span>{score.streak} streak</span>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Filter categories */}
        <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1">
          <div className="flex items-center gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  setSelectedCat(cat);
                  setActiveQuestionIdx(0);
                  setSubmitted(false);
                  setSelectedOption(null);
                }}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors shrink-0 ${
                  selectedCat === cat
                    ? 'bg-accent text-accent-ink shadow-sm'
                    : 'bg-panel border border-line text-muted hover:text-ink'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {score.total > 0 && (
            <button
              type="button"
              onClick={handleResetScore}
              className="text-[11px] text-muted hover:text-danger flex items-center gap-1 shrink-0"
            >
              <RotateCcw className="h-3 w-3" />
              <span>Reset stats</span>
            </button>
          )}
        </div>

        {/* Question card */}
        <div className="rounded-2xl border border-line bg-panel p-6 shadow-sm">
          <div className="flex items-center justify-between text-xs text-muted pb-3 border-b border-line">
            <div className="flex items-center gap-2">
              <span className="rounded-md border border-line/60 bg-field px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent">
                {currentQ.category}
              </span>
              <span className="font-semibold text-ink">{currentQ.title}</span>
            </div>
            <span>
              Question {safeIdx + 1} of {filteredQuestions.length}
            </span>
          </div>

          <div className="mt-4">
            <p className="text-sm font-medium text-ink/90">{currentQ.prompt}</p>
            <div className="my-3.5 rounded-xl border border-line/70 bg-field/60 py-4 text-center text-xl text-ink font-serif shadow-inner">
              <MathView math={currentQ.equation} displayMode />
            </div>
          </div>

          {/* Options */}
          <div className="mt-5 space-y-2.5">
            {currentQ.options.map((opt, i) => {
              const isSelected = selectedOption === i;
              const isCorrect = submitted && i === currentQ.correctIndex;
              const isWrong = submitted && isSelected && i !== currentQ.correctIndex;

              return (
                <button
                  key={i}
                  type="button"
                  disabled={submitted}
                  onClick={() => setSelectedOption(i)}
                  className={`flex w-full items-center justify-between rounded-xl border p-3.5 text-left text-sm transition-all ${
                    isCorrect
                      ? 'border-emerald-500 bg-emerald-500/15 text-emerald-400 font-bold shadow-sm'
                      : isWrong
                      ? 'border-danger bg-danger/15 text-danger font-bold'
                      : isSelected
                      ? 'border-accent bg-accent/15 text-accent font-semibold shadow-sm'
                      : 'border-line bg-field/40 text-ink hover:border-line hover:bg-field'
                  }`}
                >
                  <span className="font-serif text-base">
                    <MathView math={opt} />
                  </span>
                  {isCorrect && <CheckCircle2 className="h-4 w-4 text-emerald-400" />}
                  {isWrong && <XCircle className="h-4 w-4 text-danger" />}
                </button>
              );
            })}
          </div>

          {/* Step-by-Step Explanation */}
          {submitted && (
            <div className="mt-5 rounded-xl border border-line/70 bg-field/70 p-4 text-xs space-y-1.5">
              <span className="font-bold text-accent uppercase tracking-wider text-[11px]">
                Step-by-Step Analytical Proof:
              </span>
              <div className="text-ink text-sm leading-relaxed overflow-x-auto py-1">
                <MathView math={currentQ.explanation} displayMode />
              </div>
            </div>
          )}

          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-line/60 pt-4">
            <div className="flex items-center gap-2">
              {currentQ.graphExpr && (
                <button
                  type="button"
                  onClick={() => onNavigate('lab', { expression: currentQ.graphExpr })}
                  className="rounded-lg border border-line bg-field px-2.5 py-1 text-xs font-semibold text-muted hover:border-accent/40 hover:text-ink transition-colors flex items-center gap-1"
                >
                  <span>Verify in Visual Lab</span>
                  <ArrowRight className="h-3 w-3 text-accent" />
                </button>
              )}
              {currentQ.calcExpr && (
                <button
                  type="button"
                  onClick={() => onNavigate('calculator')}
                  className="rounded-lg border border-line bg-field px-2.5 py-1 text-xs font-semibold text-muted hover:border-accent/40 hover:text-ink transition-colors flex items-center gap-1"
                >
                  <span>Test in Calculator</span>
                  <ArrowRight className="h-3 w-3 text-accent" />
                </button>
              )}
            </div>

            {!submitted ? (
              <button
                type="button"
                disabled={selectedOption === null}
                onClick={handleSubmit}
                className="rounded-xl bg-accent px-5 py-2 text-xs font-bold text-accent-ink shadow-sm transition-opacity disabled:opacity-40"
              >
                Submit Answer
              </button>
            ) : (
              <button
                type="button"
                onClick={handleNext}
                className="flex items-center gap-1.5 rounded-xl bg-accent px-5 py-2 text-xs font-bold text-accent-ink shadow-sm hover:opacity-95"
              >
                <span>Next Question</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
