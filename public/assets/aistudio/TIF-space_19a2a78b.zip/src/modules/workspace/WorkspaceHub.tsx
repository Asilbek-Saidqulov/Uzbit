'use client';

import { useState, useEffect } from 'react';
import type { AppRoute } from '@/types/navigation';
import type { MathDocument } from '@/core/notebook/types';
import {
  getDocuments,
  createDocument,
  deleteDocument,
  duplicateDocument,
} from '@/core/notebook/notebookStore';
import { mathEngine, type MathResult } from '@/core/math/engine';
import NotebookEditor from '@/modules/notebook/NotebookEditor';
import MathView from '@/components/MathView';
import {
  BookOpen,
  Plus,
  Trash2,
  Copy,
  Clock,
  ArrowRight,
  Search,
  LineChart,
  Calculator,
  Compass,
} from 'lucide-react';

interface WorkspaceHubProps {
  onNavigate: (route: AppRoute, payload?: { expression?: string }) => void;
  initialNotebookId?: string;
  onOpenQuickCalc?: () => void;
}

export default function WorkspaceHub({
  onNavigate,
  initialNotebookId,
  onOpenQuickCalc,
}: WorkspaceHubProps) {
  const [documents, setDocuments] = useState<MathDocument[]>([]);
  const [activeDocId, setActiveDocId] = useState<string | null>(initialNotebookId || null);
  const [search, setSearch] = useState('');

  // Quick Math Launch Bar state
  const [quickExpr, setQuickExpr] = useState('');
  const [evalPreview, setEvalPreview] = useState<MathResult | null>(null);

  const refreshDocs = () => {
    setDocuments(getDocuments());
  };

  useEffect(() => {
    refreshDocs();
  }, []);

  // Live evaluation of quick expression input
  useEffect(() => {
    if (!quickExpr.trim()) {
      setEvalPreview(null);
      return;
    }
    const res = mathEngine.evaluate(quickExpr);
    setEvalPreview(res);
  }, [quickExpr]);

  const handleCreateNew = () => {
    const newDoc = createDocument('Mathematical Exploration');
    refreshDocs();
    setActiveDocId(newDoc.id);
  };

  const handleDuplicate = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    duplicateDocument(id);
    refreshDocs();
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Delete this mathematical notebook?')) {
      deleteDocument(id);
      refreshDocs();
      if (activeDocId === id) setActiveDocId(null);
    }
  };

  const activeDoc = documents.find((d) => d.id === activeDocId);

  // If a notebook is active, render full NotebookEditor
  if (activeDoc) {
    return (
      <NotebookEditor
        document={activeDoc}
        onBack={() => {
          setActiveDocId(null);
          refreshDocs();
        }}
        onUpdate={() => refreshDocs()}
      />
    );
  }

  const filteredDocs = documents.filter((d) => {
    const q = search.toLowerCase().trim();
    if (!q) return true;
    return (
      d.title.toLowerCase().includes(q) ||
      (d.tags && d.tags.some((t) => t.toLowerCase().includes(q)))
    );
  });

  const recentDoc = documents[0];

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-4xl space-y-6">
        {/* Workspace Quick Launch Desk */}
        <div className="rounded-2xl border border-line bg-panel p-5 shadow-xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-ink">
                Mathematical Workspace
              </h1>
              <p className="text-xs text-muted">
                Calculate, draft derivation steps, and create structured proofs
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onNavigate('lab')}
                className="flex items-center gap-1.5 rounded-xl border border-line bg-field/60 px-3 py-1.5 text-xs font-semibold text-ink hover:border-accent/40 transition-colors"
              >
                <LineChart className="h-3.5 w-3.5 text-accent" />
                <span>Visual Lab</span>
              </button>

              <button
                type="button"
                onClick={handleCreateNew}
                className="flex items-center gap-1.5 rounded-xl bg-accent px-3.5 py-1.5 text-xs font-semibold text-accent-ink shadow-xs hover:opacity-90 transition-opacity"
              >
                <Plus className="h-4 w-4" />
                <span>New Notebook</span>
              </button>
            </div>
          </div>

          {/* Instant Scratch Math Input */}
          <div className="relative rounded-xl border border-line/80 bg-field/60 p-2.5 transition-all focus-within:border-accent/60 focus-within:bg-field">
            <div className="flex items-center gap-2">
              <span className="font-serif italic text-accent font-bold px-1 select-none">f(x)</span>
              <input
                type="text"
                value={quickExpr}
                onChange={(e) => setQuickExpr(e.target.value)}
                placeholder="Type an equation or formula to test (e.g. x^2 - 4, 1/3 + 1/6, or sin(pi/3))..."
                className="flex-1 bg-transparent font-mono text-xs sm:text-sm text-ink placeholder-muted focus:outline-none"
              />

              {quickExpr.trim() && (
                <div className="flex items-center gap-1.5 shrink-0">
                  {/[xy]/.test(quickExpr) ? (
                    <button
                      type="button"
                      onClick={() => onNavigate('lab', { expression: quickExpr })}
                      className="flex items-center gap-1 rounded-lg bg-accent px-2.5 py-1 text-xs font-semibold text-accent-ink"
                    >
                      <LineChart className="h-3 w-3" />
                      <span>Plot Curve</span>
                    </button>
                  ) : evalPreview?.status === 'success' ? (
                    <button
                      type="button"
                      onClick={() => onOpenQuickCalc?.()}
                      className="flex items-center gap-1 rounded-lg border border-line bg-panel px-2.5 py-1 text-xs font-semibold text-ink hover:border-accent/40"
                    >
                      <Calculator className="h-3 w-3 text-accent" />
                      <span>Calculate</span>
                    </button>
                  ) : null}
                </div>
              )}
            </div>

            {/* Quick Result Preview */}
            {quickExpr.trim() && evalPreview && evalPreview.status === 'success' && (
              <div className="mt-2 flex items-center justify-between border-t border-line/50 pt-2 text-xs">
                <div className="flex items-baseline gap-2 font-mono">
                  <span className="text-muted">Result:</span>
                  {evalPreview.exact && evalPreview.exact !== evalPreview.formatted && (
                    <span className="font-bold text-accent">
                      <MathView math={evalPreview.exactLaTeX || evalPreview.exact} />
                    </span>
                  )}
                  <span className="font-bold text-ink">≈ {evalPreview.formatted}</span>
                </div>
                <span className="text-[10px] text-muted">Exact rational reduction</span>
              </div>
            )}
          </div>
        </div>

        {/* Continue Recent Work Callout */}
        {recentDoc && (
          <div
            onClick={() => setActiveDocId(recentDoc.id)}
            className="group cursor-pointer rounded-2xl border border-line bg-panel p-4 transition-all hover:border-accent/40 hover:bg-field/30 shadow-xs"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="flex h-2 w-2 rounded-full bg-emerald-400" />
                <span className="text-[10px] font-bold uppercase tracking-wider text-muted">
                  Resume Active Document
                </span>
              </div>
              <span className="flex items-center gap-1 text-xs font-semibold text-accent group-hover:translate-x-0.5 transition-transform">
                <span>Open</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </span>
            </div>

            <div className="mt-2">
              <h2 className="text-sm font-bold text-ink group-hover:text-accent transition-colors">
                {recentDoc.title}
              </h2>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted">
                <span>{recentDoc.blocks?.length || 0} mathematical blocks</span>
                <span>•</span>
                <span>Updated {new Date(recentDoc.updatedAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
                {recentDoc.tags?.map((t) => (
                  <span key={t} className="rounded bg-field px-1.5 py-0.2 text-[10px] font-mono text-muted">
                    #{t}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Notebooks Repository Section */}
        <section className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h2 className="text-xs font-bold uppercase tracking-wider text-muted">
              Mathematical Notebooks ({documents.length})
            </h2>

            {/* Notebooks Search */}
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-muted" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search notebooks by title or tag..."
                className="w-full rounded-xl border border-line bg-panel py-1.5 pl-9 pr-3 text-xs text-ink placeholder-muted focus:border-accent focus:outline-none"
              />
            </div>
          </div>

          {filteredDocs.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-line p-8 text-center space-y-2">
              <p className="text-xs text-muted">No notebooks found matching &ldquo;{search}&rdquo;</p>
              <button
                type="button"
                onClick={handleCreateNew}
                className="text-xs font-semibold text-accent hover:underline"
              >
                Create a new notebook
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {filteredDocs.map((nb) => {
                const dateStr = new Date(nb.updatedAt).toLocaleDateString([], {
                  month: 'short',
                  day: 'numeric',
                });

                return (
                  <div
                    key={nb.id}
                    onClick={() => setActiveDocId(nb.id)}
                    className="group relative flex cursor-pointer flex-col justify-between rounded-xl border border-line bg-panel p-4 transition-all hover:border-accent/40 hover:bg-field/30 shadow-xs"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <BookOpen className="h-4 w-4 text-accent" />
                          <span className="text-[11px] font-mono text-muted">{nb.blocks?.length || 0} blocks</span>
                        </div>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            type="button"
                            onClick={(e) => handleDuplicate(e, nb.id)}
                            className="rounded p-1 text-muted hover:text-ink hover:bg-field"
                            title="Duplicate notebook"
                          >
                            <Copy className="h-3 w-3" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleDelete(e, nb.id)}
                            className="rounded p-1 text-muted hover:text-danger hover:bg-field"
                            title="Delete notebook"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </div>

                      <h3 className="text-xs font-bold text-ink group-hover:text-accent transition-colors">
                        {nb.title}
                      </h3>

                      {nb.tags && nb.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {nb.tags.map((t) => (
                            <span key={t} className="rounded bg-field px-1.5 py-0.2 text-[9px] text-muted">
                              #{t}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="mt-3 flex items-center justify-between border-t border-line/50 pt-2 text-[10px] text-muted">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{dateStr}</span>
                      </span>
                      <span className="font-semibold text-accent">Open →</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

