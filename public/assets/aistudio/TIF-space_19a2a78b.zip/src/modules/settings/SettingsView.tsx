'use client';

import type { Theme } from '@/lib/theme';
import {
  Sun,
  Moon,
  Database,
  Sliders,
  Keyboard,
  Download,
  RotateCcw,
  Sparkles,
  Check,
} from 'lucide-react';
import { useState } from 'react';

interface SettingsViewProps {
  theme: Theme;
  onToggleTheme: () => void;
}

export default function SettingsView({ theme, onToggleTheme }: SettingsViewProps) {
  const [angleUnit, setAngleUnit] = useState<'radians' | 'degrees'>('radians');
  const [precision, setPrecision] = useState('8');
  const [detectPOIs, setDetectPOIs] = useState(true);
  const [cleared, setCleared] = useState(false);
  const [exported, setExported] = useState(false);

  const handleExportBackup = () => {
    try {
      const backupData = {
        timestamp: new Date().toISOString(),
        theme,
        notebooks: localStorage.getItem('tifspace_notebook_documents_v1') || '[]',
        calcHistory: localStorage.getItem('tifspace_calc_history') || '[]',
      };
      const blob = new Blob([JSON.stringify(backupData, null, 2)], {
        type: 'application/json',
      });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `tifspace-workspace-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      setExported(true);
      setTimeout(() => setExported(false), 2000);
    } catch {}
  };

  const handleClearCache = () => {
    if (confirm('Clear local cache and calculation history?')) {
      localStorage.removeItem('tifspace_active_route');
      localStorage.removeItem('tifspace_calc_history');
      setCleared(true);
      setTimeout(() => setCleared(false), 2000);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-3xl space-y-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">
              Settings & Preferences
            </h1>
            <span className="flex items-center gap-1 rounded-full bg-accent/15 px-2.5 py-0.5 text-xs font-semibold text-accent">
              <Sparkles className="h-3 w-3" />
              <span>Workspace Config</span>
            </span>
          </div>
          <p className="text-xs text-muted sm:text-sm">
            Customize mathematical notation, computation precision, appearance, and workspace persistence.
          </p>
        </div>

        {/* Appearance */}
        <div className="rounded-2xl border border-line bg-panel p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-line pb-3">
            <Sliders className="h-4 w-4 text-accent" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-ink">Appearance & Visuals</h2>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-ink">Color Theme</span>
              <p className="text-[11px] text-muted">Toggle between high-contrast Dark and crisp Light canvas.</p>
            </div>
            <button
              type="button"
              onClick={onToggleTheme}
              className="flex items-center gap-2 rounded-xl border border-line bg-field px-3 py-1.5 text-xs font-semibold text-ink hover:border-accent/40 transition-colors"
            >
              {theme === 'dark' ? <Moon className="h-3.5 w-3.5" /> : <Sun className="h-3.5 w-3.5" />}
              <span className="capitalize">{theme} Theme</span>
            </button>
          </div>
        </div>

        {/* Mathematical Engine Settings */}
        <div className="rounded-2xl border border-line bg-panel p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-line pb-3">
            <Keyboard className="h-4 w-4 text-accent" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-ink">Mathematical Engine</h2>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-ink">Default Trigonometric Angle Mode</span>
              <p className="text-[11px] text-muted">Initial mode for sin(θ), cos(θ), and tan(θ) in calculator and graphing.</p>
            </div>
            <div className="flex rounded-lg border border-line bg-field p-0.5 text-xs">
              <button
                type="button"
                onClick={() => setAngleUnit('radians')}
                className={`rounded-md px-2.5 py-1 font-semibold transition-colors ${
                  angleUnit === 'radians' ? 'bg-accent text-accent-ink shadow-sm' : 'text-muted hover:text-ink'
                }`}
              >
                Radians (π)
              </button>
              <button
                type="button"
                onClick={() => setAngleUnit('degrees')}
                className={`rounded-md px-2.5 py-1 font-semibold transition-colors ${
                  angleUnit === 'degrees' ? 'bg-accent text-accent-ink shadow-sm' : 'text-muted hover:text-ink'
                }`}
              >
                Degrees (°)
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-line/60 pt-3">
            <div>
              <span className="text-xs font-semibold text-ink">Decimal Display Precision</span>
              <p className="text-[11px] text-muted">Significant digits displayed for irrational approximations.</p>
            </div>
            <select
              value={precision}
              onChange={(e) => setPrecision(e.target.value)}
              className="rounded-lg border border-line bg-field px-3 py-1.5 text-xs font-semibold text-ink focus:border-accent focus:outline-none"
            >
              <option value="4">4 digits</option>
              <option value="6">6 digits</option>
              <option value="8">8 digits (Standard)</option>
              <option value="12">12 digits (High Precision)</option>
            </select>
          </div>

          <div className="flex items-center justify-between border-t border-line/60 pt-3">
            <div>
              <span className="text-xs font-semibold text-ink">Auto-Detect Points of Interest</span>
              <p className="text-[11px] text-muted">Highlight roots, extrema, and intersections automatically on curves.</p>
            </div>
            <label className="relative inline-flex cursor-pointer items-center">
              <input
                type="checkbox"
                checked={detectPOIs}
                onChange={(e) => setDetectPOIs(e.target.checked)}
                className="sr-only peer"
              />
              <div className="h-5 w-9 rounded-full bg-field peer peer-checked:bg-accent peer-checked:after:translate-x-full after:absolute after:top-[2px] after:left-[2px] after:h-4 after:w-4 after:rounded-full after:bg-white after:transition-all"></div>
            </label>
          </div>
        </div>

        {/* Workspace Storage & Backup */}
        <div className="rounded-2xl border border-line bg-panel p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-line pb-3">
            <Database className="h-4 w-4 text-accent" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-ink">Storage & Workspace Backup</h2>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-ink">Backup Workspace Documents</span>
              <p className="text-[11px] text-muted">Download all notebooks, calculation history, and settings as JSON.</p>
            </div>
            <button
              type="button"
              onClick={handleExportBackup}
              className="flex items-center gap-1.5 rounded-xl border border-line bg-field px-3 py-1.5 text-xs font-semibold text-ink hover:border-accent/40 transition-colors"
            >
              {exported ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Exported</span>
                </>
              ) : (
                <>
                  <Download className="h-3.5 w-3.5 text-muted" />
                  <span>Export Backup</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center justify-between border-t border-line/60 pt-3">
            <div>
              <span className="text-xs font-semibold text-ink">Reset Local Cache</span>
              <p className="text-[11px] text-muted">Clear stored evaluation history and temporary cached routes.</p>
            </div>
            <button
              type="button"
              onClick={handleClearCache}
              className="flex items-center gap-1.5 rounded-xl border border-line bg-field px-3 py-1.5 text-xs font-semibold text-muted hover:text-danger hover:border-danger/40 transition-colors"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>{cleared ? 'Cache Cleared!' : 'Clear Cache'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
