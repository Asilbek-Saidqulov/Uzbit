'use client';

import { useState } from 'react';
import type { AppRoute } from '@/types/navigation';
import MathView from '@/components/MathView';
import { appendMathBlockToActive } from '@/core/notebook/notebookStore';
import { Search, Copy, Check, ArrowRight, Sparkles, Code2, LineChart, BookOpen, Calculator } from 'lucide-react';

interface FormulaLibraryViewProps {
  onNavigate: (route: AppRoute, payload?: { expression?: string }) => void;
}

interface FormulaItem {
  id: string;
  title: string;
  category: 'Algebra' | 'Calculus' | 'Trigonometry' | 'Geometry' | 'Statistics';
  formula: string;
  latex?: string;
  calcExpr?: string;
  graphExpr?: string;
  description: string;
  variables: { name: string; meaning: string }[];
}

const FORMULAS_DATA: FormulaItem[] = [
  {
    id: 'f-1',
    title: 'Quadratic Equation Solution',
    category: 'Algebra',
    formula: 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}',
    graphExpr: 'y = x^2 - 2x - 3',
    calcExpr: '(-(-2) + sqrt((-2)^2 - 4*1*(-3))) / (2*1)',
    description: 'Finds the exact real or complex roots of a second-degree polynomial equation ax² + bx + c = 0.',
    variables: [
      { name: 'a, b, c', meaning: 'Polynomial coefficients where a ≠ 0' },
      { name: 'b² - 4ac', meaning: 'Discriminant Δ determining root multiplicity' },
    ],
  },
  {
    id: 'f-2',
    title: 'Fundamental Theorem of Calculus',
    category: 'Calculus',
    formula: '\\int_{a}^{b} f(x)\\,dx = F(b) - F(a)',
    graphExpr: 'f(x) = x^2 - 4',
    description: 'Connects the definite integral of a continuous function with its antiderivative function F(x).',
    variables: [
      { name: 'f(x)', meaning: 'Continuous integrand over interval [a, b]' },
      { name: 'F(x)', meaning: 'Antiderivative where dF/dx = f(x)' },
    ],
  },
  {
    id: 'f-3',
    title: 'Derivative by First Principles',
    category: 'Calculus',
    formula: 'f\'(x) = \\lim_{h \\to 0} \\frac{f(x + h) - f(x)}{h}',
    graphExpr: 'f(x) = x^3 - 3x',
    description: 'Formal definition of the instantaneous rate of change and tangent line slope to f(x).',
    variables: [
      { name: 'h', meaning: 'Infinitesimal horizontal increment towards 0' },
      { name: 'f\'(x)', meaning: 'Derivative function at coordinate x' },
    ],
  },
  {
    id: 'f-4',
    title: 'Euler\'s Identity',
    category: 'Calculus',
    formula: 'e^{i\\pi} + 1 = 0',
    graphExpr: 'y = cos(x)',
    calcExpr: 'cos(pi) + 1',
    description: 'Profound identity linking five fundamental mathematical constants (e, i, π, 1, 0).',
    variables: [
      { name: 'e', meaning: 'Base of natural logarithms ≈ 2.71828' },
      { name: 'i', meaning: 'Imaginary unit where i² = -1' },
      { name: 'π', meaning: 'Archimedes circle constant ≈ 3.14159' },
    ],
  },
  {
    id: 'f-5',
    title: 'Gaussian Normal Distribution',
    category: 'Statistics',
    formula: 'f(x) = \\frac{1}{\\sigma \\sqrt{2\\pi}}\\,e^{-\\frac{1}{2}\\left(\\frac{x - \\mu}{\\sigma}\\right)^2}',
    graphExpr: 'y = (1 / sqrt(2 * pi)) * e^(-0.5 * x^2)',
    description: 'Probability density function of the bell curve with mean μ and standard deviation σ.',
    variables: [
      { name: 'μ', meaning: 'Expected value / distribution center' },
      { name: 'σ', meaning: 'Standard deviation (distribution spread)' },
    ],
  },
  {
    id: 'f-6',
    title: 'Taylor Series Polynomial Expansion',
    category: 'Calculus',
    formula: 'f(x) = \\sum_{n=0}^{\\infty} \\frac{f^{(n)}(a)}{n!}\\,(x - a)^n',
    graphExpr: 'y = x - (x^3)/6 + (x^5)/120',
    description: 'Represents a smooth function as an infinite sum of polynomial power terms calculated from its derivatives at a point.',
    variables: [
      { name: 'f^(n)(a)', meaning: 'n-th order derivative evaluated at center point a' },
      { name: 'n!', meaning: 'Factorial denominator weighting term' },
    ],
  },
  {
    id: 'f-7',
    title: 'Pythagorean Theorem & Circle Relation',
    category: 'Geometry',
    formula: 'x^2 + y^2 = r^2',
    graphExpr: 'x^2 + y^2 = 25',
    description: 'Fundamental Euclidean metric relating coordinates (x, y) on the perimeter of a circle of radius r.',
    variables: [
      { name: 'x, y', meaning: 'Cartesian orthogonal coordinate distances' },
      { name: 'r', meaning: 'Circle radius / triangle hypotenuse' },
    ],
  },
  {
    id: 'f-8',
    title: 'Law of Cosines',
    category: 'Trigonometry',
    formula: 'c^2 = a^2 + b^2 - 2ab\\cos(\\gamma)',
    graphExpr: 'y = 2*cos(x) + 1',
    description: 'Generalizes the Pythagorean theorem to arbitrary triangles, relating all three sides and the interior angle γ.',
    variables: [
      { name: 'γ', meaning: 'Interior angle opposite side c' },
      { name: 'a, b, c', meaning: 'Triangle edge lengths' },
    ],
  },
  {
    id: 'f-9',
    title: 'Sigmoid Logistic Activation',
    category: 'Calculus',
    formula: '\\sigma(x) = \\frac{1}{1 + e^{-x}}',
    graphExpr: 'y = 1 / (1 + e^(-x))',
    description: 'Smooth S-shaped activation function mapping arbitrary real inputs onto the bounded unit interval (0, 1).',
    variables: [
      { name: 'x', meaning: 'Logit / linear combination value' },
      { name: 'σ(x)', meaning: 'Probability outcome in range (0, 1)' },
    ],
  },
  {
    id: 'f-10',
    title: 'Damped Harmonic Oscillation',
    category: 'Calculus',
    formula: 'x(t) = e^{-\\gamma t}\\,\\cos(\\omega t)',
    graphExpr: 'y = e^(-0.2 * x) * cos(3 * x)',
    description: 'Models oscillatory physical systems losing energy exponentially over time due to viscous damping.',
    variables: [
      { name: 'γ', meaning: 'Damping attenuation coefficient' },
      { name: 'ω', meaning: 'Angular oscillation frequency' },
    ],
  },
  {
    id: 'f-11',
    title: 'Compound Interest & Exponential Growth',
    category: 'Algebra',
    formula: 'A(t) = P\\,e^{rt}',
    graphExpr: 'y = 2 * e^(0.5 * x)',
    description: 'Governs continuous biological population expansion, nuclear decay rates, and continuous compound interest.',
    variables: [
      { name: 'P', meaning: 'Initial principal or population magnitude' },
      { name: 'r', meaning: 'Continuous annual or instantaneous growth rate' },
    ],
  },
  {
    id: 'f-12',
    title: 'Cauchy-Schwarz Inequality',
    category: 'Algebra',
    formula: '|\\mathbf{u} \\cdot \\mathbf{v}|^2 \\le (\\|\\mathbf{u}\\|^2)(\\|\\mathbf{v}\\|^2)',
    graphExpr: 'y = 2x + 1',
    description: 'Fundamental algebraic constraint proving the absolute inner product never exceeds the product of vector norms.',
    variables: [
      { name: 'u, v', meaning: 'Vectors in inner product space' },
      { name: '·', meaning: 'Inner dot product operation' },
    ],
  },
];

export default function FormulaLibraryView({ onNavigate }: FormulaLibraryViewProps) {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [addedNotebookId, setAddedNotebookId] = useState<string | null>(null);

  const categories = ['All', 'Algebra', 'Calculus', 'Geometry', 'Trigonometry', 'Statistics'];

  const filtered = FORMULAS_DATA.filter((f) => {
    const matchCat = selectedCategory === 'All' || f.category === selectedCategory;
    const matchSearch =
      !search.trim() ||
      f.title.toLowerCase().includes(search.toLowerCase()) ||
      f.formula.toLowerCase().includes(search.toLowerCase()) ||
      f.description.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const handleCopy = (id: string, formula: string) => {
    navigator.clipboard?.writeText(formula);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleAddToNotebook = (item: FormulaItem) => {
    appendMathBlockToActive(item.formula);
    setAddedNotebookId(item.id);
    setTimeout(() => setAddedNotebookId(null), 1800);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="mx-auto max-w-5xl space-y-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">
              Formula Library
            </h1>
            <span className="flex items-center gap-1 rounded-full bg-accent/15 px-2.5 py-0.5 text-xs font-semibold text-accent">
              <Sparkles className="h-3 w-3" />
              <span>KaTeX Typography</span>
            </span>
          </div>
          <p className="text-xs text-muted sm:text-sm">
            Curated mathematical formulas formatted with professional KaTeX typeset rendering, definitions, constraints, and 1-click lab exploration.
          </p>
        </div>

        {/* Search & Filters */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-muted" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search formulas by title, expression, or symbol (e.g. integral, euler, quadratic)..."
              className="w-full rounded-xl border border-line bg-panel py-2.5 pl-10 pr-4 text-xs text-ink placeholder-muted focus:border-accent focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors shrink-0 ${
                  selectedCategory === cat
                    ? 'bg-accent text-accent-ink shadow-sm'
                    : 'bg-field text-muted hover:bg-line/40 hover:text-ink'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Formulas Grid */}
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="group relative flex flex-col justify-between rounded-2xl border border-line bg-panel p-5 shadow-sm transition-all hover:border-accent/50 hover:shadow-lg"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="rounded-md border border-line/60 bg-field px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent">
                    {item.category}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleCopy(item.id, item.formula)}
                    className="flex items-center gap-1 rounded-lg border border-line/60 bg-field/60 px-2 py-1 text-[11px] font-medium text-muted transition-colors hover:border-accent/40 hover:text-ink"
                    title="Copy LaTeX"
                  >
                    {copiedId === item.id ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Code2 className="h-3 w-3" />
                        <span>LaTeX</span>
                      </>
                    )}
                  </button>
                </div>

                <h3 className="mt-2.5 text-sm font-bold text-ink">{item.title}</h3>

                {/* Decorated Mathematical Formula Display */}
                <div className="relative mt-3.5 overflow-x-auto rounded-xl border border-line/80 bg-field/70 px-4 py-4 text-center shadow-inner transition-colors group-hover:border-accent/40 group-hover:bg-field/90">
                  <div className="text-lg text-ink font-serif antialiased">
                    <MathView math={item.formula} displayMode />
                  </div>
                </div>

                <p className="mt-3.5 text-xs text-muted leading-relaxed">{item.description}</p>

                {item.variables.length > 0 && (
                  <div className="mt-3.5 space-y-1 rounded-xl border border-line/40 bg-field/40 p-2.5 text-[11px]">
                    {item.variables.map((v, i) => (
                      <div key={i} className="flex gap-2">
                        <span className="font-mono font-semibold text-accent shrink-0">{v.name}:</span>
                        <span className="text-muted">{v.meaning}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-line/60 pt-3">
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleAddToNotebook(item)}
                    className="flex items-center gap-1 rounded-lg border border-line bg-field px-2.5 py-1 text-xs font-semibold text-muted hover:border-accent/40 hover:text-ink transition-colors"
                    title="Append formula to active notebook"
                  >
                    {addedNotebookId === item.id ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-400" />
                        <span className="text-emerald-400">Added!</span>
                      </>
                    ) : (
                      <>
                        <BookOpen className="h-3 w-3" />
                        <span>+ Notebook</span>
                      </>
                    )}
                  </button>

                  {item.calcExpr && (
                    <button
                      type="button"
                      onClick={() => onNavigate('calculator')}
                      className="flex items-center gap-1 rounded-lg border border-line bg-field px-2 py-1 text-xs font-semibold text-muted hover:border-accent/40 hover:text-ink transition-colors"
                      title="Calculate numerical value"
                    >
                      <Calculator className="h-3 w-3" />
                      <span className="hidden sm:inline">Calc</span>
                    </button>
                  )}
                </div>

                {item.graphExpr && (
                  <button
                    type="button"
                    onClick={() => onNavigate('lab', { expression: item.graphExpr })}
                    className="flex items-center gap-1.5 rounded-lg bg-accent/15 px-3 py-1 text-xs font-semibold text-accent hover:bg-accent/25 transition-colors"
                  >
                    <LineChart className="h-3.5 w-3.5" />
                    <span>Plot Curve</span>
                    <ArrowRight className="h-3.5 w-3.5 ml-0.5" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
