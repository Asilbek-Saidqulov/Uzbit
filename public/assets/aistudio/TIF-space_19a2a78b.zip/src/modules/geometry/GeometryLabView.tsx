'use client';

import { useState, useRef, useMemo } from 'react';
import type { AppRoute } from '@/types/navigation';
import {
  distance,
  midpoint,
  angleBetween,
  triangleArea,
  type GeoPoint,
  type GeoSegment,
  type GeoCircle,
  type GeoPolygon,
  type GeoLine,
} from '@/core/geometry/geometryMath';
import MathView from '@/components/MathView';
import {
  Shapes,
  CircleDot,
  Ruler,
  Compass,
  RotateCcw,
  Sparkles,
  MousePointer,
  Trash2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Info,
  ChevronRight,
  Play,
  Layers,
} from 'lucide-react';

interface GeometryLabViewProps {
  onNavigate: (route: AppRoute) => void;
}

type ToolMode = 'select' | 'point' | 'segment' | 'circle' | 'polygon' | 'midpoint' | 'bisector';

export default function GeometryLabView({ onNavigate }: GeometryLabViewProps) {
  const [tool, setTool] = useState<ToolMode>('select');
  const [selectedPointId, setSelectedPointId] = useState<string | null>(null);
  const [selectedObj, setSelectedObj] = useState<{ type: string; id: string } | null>(null);
  const [showInspector, setShowInspector] = useState(true);

  // Construction state
  const [points, setPoints] = useState<GeoPoint[]>([
    { id: 'p1', name: 'A', x: -2, y: -1.5 },
    { id: 'p2', name: 'B', x: 2, y: -1.5 },
    { id: 'p3', name: 'C', x: 0, y: 1.964 }, // Equilateral triangle
  ]);

  const [segments, setSegments] = useState<GeoSegment[]>([
    { id: 's1', name: 'c', p1Id: 'p1', p2Id: 'p2', color: '#3b82f6' },
    { id: 's2', name: 'a', p1Id: 'p2', p2Id: 'p3', color: '#3b82f6' },
    { id: 's3', name: 'b', p1Id: 'p3', p2Id: 'p1', color: '#3b82f6' },
  ]);

  const [circles, setCircles] = useState<GeoCircle[]>([]);
  const [polygons, setPolygons] = useState<GeoPolygon[]>([
    { id: 'poly1', name: '△ABC', pointIds: ['p1', 'p2', 'p3'], color: '#3b82f6' },
  ]);
  const [lines, setLines] = useState<GeoLine[]>([]);

  // Pending creation buffer
  const [pendingPointIds, setPendingPointIds] = useState<string[]>([]);

  // Dragging state
  const [draggingPointId, setDraggingPointId] = useState<string | null>(null);

  // Canvas Viewport Coordinate Mapping
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const svgRef = useRef<SVGSVGElement>(null);

  const width = 800;
  const height = 500;
  const scale = 50 * zoom; // 50px per math unit

  const toSvgX = (x: number) => width / 2 + pan.x + x * scale;
  const toSvgY = (y: number) => height / 2 + pan.y - y * scale;
  const toMathX = (svgX: number) => (svgX - width / 2 - pan.x) / scale;
  const toMathY = (svgY: number) => -(svgY - height / 2 - pan.y) / scale;

  // Point map for instant lookup
  const pointMap = useMemo(() => {
    const map = new Map<string, GeoPoint>();
    for (const p of points) map.set(p.id, p);
    return map;
  }, [points]);

  // Click on canvas background
  const handleCanvasClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const rawX = rect.width > 0 ? ((e.clientX - rect.left) / rect.width) * width : e.clientX - rect.left;
    const rawY = rect.height > 0 ? ((e.clientY - rect.top) / rect.height) * height : e.clientY - rect.top;
    const mX = Math.round(toMathX(rawX) * 10) / 10;
    const mY = Math.round(toMathY(rawY) * 10) / 10;

    if (tool === 'point') {
      const nextLetter = String.fromCharCode(65 + (points.length % 26));
      const newPoint: GeoPoint = {
        id: `p-${Date.now()}`,
        name: nextLetter,
        x: mX,
        y: mY,
      };
      setPoints((prev) => [...prev, newPoint]);
    } else if (tool === 'select') {
      setSelectedObj(null);
      setSelectedPointId(null);
    }
  };

  // Click on a point during multi-step tool
  const handlePointClick = (e: React.MouseEvent, pId: string) => {
    e.stopPropagation();

    if (tool === 'select') {
      setSelectedPointId(pId);
      setSelectedObj({ type: 'point', id: pId });
      return;
    }

    if (tool === 'segment') {
      if (pendingPointIds.length === 0) {
        setPendingPointIds([pId]);
      } else {
        const first = pendingPointIds[0];
        if (first !== pId) {
          const p1 = pointMap.get(first);
          const p2 = pointMap.get(pId);
          const segName = p1 && p2 ? `${p1.name}${p2.name}` : `seg-${segments.length + 1}`;
          setSegments((prev) => [
            ...prev,
            { id: `s-${Date.now()}`, name: segName, p1Id: first, p2Id: pId, color: '#3b82f6' },
          ]);
        }
        setPendingPointIds([]);
      }
    } else if (tool === 'circle') {
      if (pendingPointIds.length === 0) {
        setPendingPointIds([pId]);
      } else {
        const center = pendingPointIds[0];
        if (center !== pId) {
          setCircles((prev) => [
            ...prev,
            { id: `c-${Date.now()}`, name: `Circle(${pointMap.get(center)?.name || ''})`, centerId: center, radiusPointId: pId, color: '#ec4899' },
          ]);
        }
        setPendingPointIds([]);
      }
    } else if (tool === 'midpoint') {
      if (pendingPointIds.length === 0) {
        setPendingPointIds([pId]);
      } else {
        const p1 = pointMap.get(pendingPointIds[0]);
        const p2 = pointMap.get(pId);
        if (p1 && p2 && p1.id !== p2.id) {
          const mid = midpoint(p1, p2);
          const newP: GeoPoint = {
            id: `p-${Date.now()}`,
            name: `M_${p1.name}${p2.name}`,
            x: Math.round(mid.x * 100) / 100,
            y: Math.round(mid.y * 100) / 100,
          };
          setPoints((prev) => [...prev, newP]);
        }
        setPendingPointIds([]);
      }
    } else if (tool === 'bisector') {
      if (pendingPointIds.length === 0) {
        setPendingPointIds([pId]);
      } else {
        const first = pendingPointIds[0];
        if (first !== pId) {
          setLines((prev) => [
            ...prev,
            { id: `l-${Date.now()}`, name: `Bisector`, p1Id: first, p2Id: pId, type: 'perpendicularBisector', color: '#10b981' },
          ]);
        }
        setPendingPointIds([]);
      }
    } else if (tool === 'polygon') {
      if (pendingPointIds.includes(pId)) {
        // Closing polygon
        if (pendingPointIds.length >= 3 && pendingPointIds[0] === pId) {
          setPolygons((prev) => [
            ...prev,
            { id: `poly-${Date.now()}`, name: `Polygon`, pointIds: [...pendingPointIds], color: '#3b82f6' },
          ]);
          setPendingPointIds([]);
        }
      } else {
        setPendingPointIds((prev) => [...prev, pId]);
      }
    }
  };

  // Dragging points
  const handlePointerDownPoint = (e: React.PointerEvent, pId: string) => {
    if (tool !== 'select') return;
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    setDraggingPointId(pId);
  };

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!draggingPointId || !svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const rawX = rect.width > 0 ? ((e.clientX - rect.left) / rect.width) * width : e.clientX - rect.left;
    const rawY = rect.height > 0 ? ((e.clientY - rect.top) / rect.height) * height : e.clientY - rect.top;
    const nextX = Math.round(toMathX(rawX) * 100) / 100;
    const nextY = Math.round(toMathY(rawY) * 100) / 100;

    setPoints((prev) =>
      prev.map((p) => (p.id === draggingPointId ? { ...p, x: nextX, y: nextY } : p))
    );
  };

  const handlePointerUp = () => {
    setDraggingPointId(null);
  };

  // Presets
  const loadPreset = (presetName: string) => {
    setPendingPointIds([]);
    setSelectedObj(null);
    if (presetName === 'equilateral') {
      setPoints([
        { id: 'p1', name: 'A', x: -2, y: -1.5 },
        { id: 'p2', name: 'B', x: 2, y: -1.5 },
        { id: 'p3', name: 'C', x: 0, y: 1.964 },
      ]);
      setSegments([
        { id: 's1', name: 'c', p1Id: 'p1', p2Id: 'p2', color: '#3b82f6' },
        { id: 's2', name: 'a', p1Id: 'p2', p2Id: 'p3', color: '#3b82f6' },
        { id: 's3', name: 'b', p1Id: 'p3', p2Id: 'p1', color: '#3b82f6' },
      ]);
      setCircles([]);
      setLines([]);
      setPolygons([{ id: 'poly1', name: '△ABC', pointIds: ['p1', 'p2', 'p3'], color: '#3b82f6' }]);
    } else if (presetName === 'pythagorean') {
      setPoints([
        { id: 'p1', name: 'A', x: -2, y: -1.5 },
        { id: 'p2', name: 'B', x: 2, y: -1.5 },
        { id: 'p3', name: 'C', x: -2, y: 1.5 },
      ]);
      setSegments([
        { id: 's1', name: 'a', p1Id: 'p1', p2Id: 'p2', color: '#10b981' },
        { id: 's2', name: 'b', p1Id: 'p1', p2Id: 'p3', color: '#f59e0b' },
        { id: 's3', name: 'c', p1Id: 'p2', p2Id: 'p3', color: '#3b82f6' },
      ]);
      setCircles([]);
      setLines([]);
      setPolygons([{ id: 'poly1', name: '△ABC (Right Triangle)', pointIds: ['p1', 'p2', 'p3'], color: '#3b82f6' }]);
    } else if (presetName === 'circumcircle') {
      setPoints([
        { id: 'p1', name: 'O', x: 0, y: 0 },
        { id: 'p2', name: 'R', x: 3, y: 0 },
        { id: 'p3', name: 'T', x: 0, y: 3 },
      ]);
      setSegments([
        { id: 's1', name: 'r', p1Id: 'p1', p2Id: 'p2', color: '#ec4899' },
      ]);
      setCircles([
        { id: 'c1', name: 'Circumcircle', centerId: 'p1', radiusPointId: 'p2', color: '#ec4899' },
      ]);
      setLines([]);
      setPolygons([]);
    }
  };

  // Calculate live geometric metrics
  const activeMetrics = useMemo(() => {
    // If a triangle polygon exists, compute its metrics
    const poly = polygons[0];
    if (poly && poly.pointIds.length === 3) {
      const pA = pointMap.get(poly.pointIds[0]);
      const pB = pointMap.get(poly.pointIds[1]);
      const pC = pointMap.get(poly.pointIds[2]);
      if (pA && pB && pC) {
        const sideC = distance(pA, pB);
        const sideA = distance(pB, pC);
        const sideB = distance(pC, pA);
        const angA = angleBetween(pB, pA, pC);
        const angB = angleBetween(pA, pB, pC);
        const angC = angleBetween(pA, pC, pB);
        const area = triangleArea(pA, pB, pC);

        return {
          type: 'triangle' as const,
          name: poly.name,
          sideA: sideA.toFixed(2),
          sideB: sideB.toFixed(2),
          sideC: sideC.toFixed(2),
          angA: Math.round(angA),
          angB: Math.round(angB),
          angC: Math.round(angC),
          perimeter: (sideA + sideB + sideC).toFixed(2),
          area: area.toFixed(2),
        };
      }
    }

    // If circle exists, compute circle metrics
    if (circles.length > 0) {
      const c = circles[0];
      const center = pointMap.get(c.centerId);
      let r = 1;
      if (c.radiusPointId) {
        const radP = pointMap.get(c.radiusPointId);
        if (center && radP) r = distance(center, radP);
      } else if (c.radius) {
        r = c.radius;
      }
      if (center) {
        return {
          type: 'circle' as const,
          name: c.name,
          center: `(${center.x.toFixed(2)}, ${center.y.toFixed(2)})`,
          radius: r.toFixed(2),
          diameter: (2 * r).toFixed(2),
          circumference: (2 * Math.PI * r).toFixed(2),
          area: (Math.PI * r * r).toFixed(2),
          equation: `(x - ${center.x.toFixed(1)})² + (y - ${center.y.toFixed(1)})² = ${(r * r).toFixed(2)}`,
        };
      }
    }

    return null;
  }, [polygons, circles, pointMap]);

  return (
    <div className="flex h-full flex-col overflow-hidden bg-canvas">
      {/* Module Header Toolbar */}
      <div className="flex h-12 shrink-0 items-center justify-between border-b border-line bg-panel px-4 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-muted">Geometry Lab</span>
            <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold text-amber-400">
              Interactive Euclidean Sandbox
            </span>
          </div>

          <div className="h-4 w-px bg-line" />

          {/* Preset selector */}
          <div className="flex items-center gap-1 text-xs">
            <span className="text-muted text-[11px] hidden sm:inline">Constructions:</span>
            <button
              type="button"
              onClick={() => loadPreset('equilateral')}
              className="rounded-lg border border-line bg-field px-2.5 py-1 text-xs font-medium text-ink hover:border-accent/40"
            >
              Equilateral △
            </button>
            <button
              type="button"
              onClick={() => loadPreset('pythagorean')}
              className="rounded-lg border border-line bg-field px-2.5 py-1 text-xs font-medium text-ink hover:border-accent/40"
            >
              Pythagoras (a²+b²=c²)
            </button>
            <button
              type="button"
              onClick={() => loadPreset('circumcircle')}
              className="rounded-lg border border-line bg-field px-2.5 py-1 text-xs font-medium text-ink hover:border-accent/40"
            >
              Circle & Radius
            </button>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(3, z * 1.2))}
            className="grid h-7 w-7 place-items-center rounded-lg border border-line text-muted hover:text-ink hover:bg-field"
            title="Zoom in"
          >
            <ZoomIn className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.4, z / 1.2))}
            className="grid h-7 w-7 place-items-center rounded-lg border border-line text-muted hover:text-ink hover:bg-field"
            title="Zoom out"
          >
            <ZoomOut className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => {
              setZoom(1);
              setPan({ x: 0, y: 0 });
            }}
            className="grid h-7 w-7 place-items-center rounded-lg border border-line text-muted hover:text-ink hover:bg-field"
            title="Reset viewport"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </button>

          <div className="mx-1 h-3.5 w-px bg-line" />

          <button
            type="button"
            onClick={() => setShowInspector(!showInspector)}
            className={`flex items-center gap-1 rounded-lg border px-2 py-1 text-xs font-semibold transition-colors ${
              showInspector ? 'border-accent bg-accent/15 text-accent' : 'border-line bg-field text-muted hover:text-ink'
            }`}
            title="Toggle Geometric Inspector"
          >
            <Info className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Inspector</span>
          </button>
        </div>
      </div>

      <div className="flex min-h-0 flex-1">
        {/* Left Construction Tools Sidebar */}
        <aside className="w-14 shrink-0 border-r border-line bg-panel flex flex-col items-center py-3 gap-2">
          {[
            { id: 'select' as ToolMode, icon: MousePointer, label: 'Select / Drag' },
            { id: 'point' as ToolMode, icon: CircleDot, label: 'Add Point' },
            { id: 'segment' as ToolMode, icon: Ruler, label: 'Line Segment' },
            { id: 'circle' as ToolMode, icon: Compass, label: 'Circle' },
            { id: 'midpoint' as ToolMode, icon: Sparkles, label: 'Midpoint' },
            { id: 'bisector' as ToolMode, icon: Shapes, label: 'Perp Bisector' },
          ].map((t) => {
            const Icon = t.icon;
            const isActive = tool === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  setTool(t.id);
                  setPendingPointIds([]);
                }}
                title={t.label}
                className={`grid h-9 w-9 place-items-center rounded-xl transition-all ${
                  isActive
                    ? 'bg-accent text-accent-ink shadow-sm'
                    : 'text-muted hover:bg-field hover:text-ink'
                }`}
              >
                <Icon className="h-4 w-4" />
              </button>
            );
          })}

          <div className="my-2 h-px w-8 bg-line" />

          <button
            type="button"
            onClick={() => {
              setPoints([]);
              setSegments([]);
              setCircles([]);
              setPolygons([]);
              setLines([]);
              setPendingPointIds([]);
              setSelectedObj(null);
            }}
            title="Clear Canvas"
            className="grid h-9 w-9 place-items-center rounded-xl text-muted hover:text-danger hover:bg-field"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </aside>

        {/* Main Interactive Geometric Canvas */}
        <main className="relative flex-1 overflow-hidden select-none bg-canvas">
          {/* Construction Instruction Prompt */}
          <div className="absolute top-3 left-4 z-10 flex items-center gap-2 rounded-xl border border-line bg-panel/90 px-3 py-1.5 text-xs shadow-md backdrop-blur">
            <span className="font-bold text-accent capitalize">{tool} Mode:</span>
            <span className="text-muted">
              {tool === 'select' && 'Click and drag any point to dynamically transform shapes.'}
              {tool === 'point' && 'Click anywhere on canvas to create a new point.'}
              {tool === 'segment' && (pendingPointIds.length === 0 ? 'Click first point' : 'Click second point to connect')}
              {tool === 'circle' && (pendingPointIds.length === 0 ? 'Click center point' : 'Click radius point')}
              {tool === 'midpoint' && (pendingPointIds.length === 0 ? 'Click first point' : 'Click second point to find midpoint')}
              {tool === 'bisector' && (pendingPointIds.length === 0 ? 'Click first point' : 'Click second point for perpendicular bisector')}
            </span>
          </div>

          <svg
            ref={svgRef}
            viewBox={`0 0 ${width} ${height}`}
            className="h-full w-full cursor-crosshair"
            onClick={handleCanvasClick}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
          >
            {/* Coordinate Grid */}
            {[-8, -6, -4, -2, 2, 4, 6, 8].map((g) => (
              <g key={`g-${g}`}>
                <line
                  x1={toSvgX(g)}
                  y1={0}
                  x2={toSvgX(g)}
                  y2={height}
                  stroke="currentColor"
                  className="stroke-line/30"
                  strokeDasharray="2,2"
                />
                <line
                  x1={0}
                  y1={toSvgY(g)}
                  x2={width}
                  y2={toSvgY(g)}
                  stroke="currentColor"
                  className="stroke-line/30"
                  strokeDasharray="2,2"
                />
              </g>
            ))}

            {/* Coordinate Axes */}
            <line
              x1={0}
              y1={toSvgY(0)}
              x2={width}
              y2={toSvgY(0)}
              stroke="currentColor"
              className="stroke-line"
              strokeWidth="1.5"
            />
            <line
              x1={toSvgX(0)}
              y1={0}
              x2={toSvgX(0)}
              y2={height}
              stroke="currentColor"
              className="stroke-line"
              strokeWidth="1.5"
            />

            {/* Polygons */}
            {polygons.map((poly) => {
              const polyPts = poly.pointIds
                .map((id) => pointMap.get(id))
                .filter((p): p is GeoPoint => p !== undefined);
              if (polyPts.length < 3) return null;
              const pointsStr = polyPts.map((p) => `${toSvgX(p.x)},${toSvgY(p.y)}`).join(' ');

              return (
                <polygon
                  key={poly.id}
                  points={pointsStr}
                  fill={poly.color || '#3b82f6'}
                  fillOpacity="0.15"
                  stroke={poly.color || '#3b82f6'}
                  strokeWidth="2"
                  strokeLinejoin="round"
                />
              );
            })}

            {/* Circles */}
            {circles.map((c) => {
              const center = pointMap.get(c.centerId);
              if (!center) return null;
              let r = 1;
              if (c.radiusPointId) {
                const radP = pointMap.get(c.radiusPointId);
                if (radP) r = distance(center, radP);
              } else if (c.radius) {
                r = c.radius;
              }

              return (
                <circle
                  key={c.id}
                  cx={toSvgX(center.x)}
                  cy={toSvgY(center.y)}
                  r={r * scale}
                  fill={c.color || '#ec4899'}
                  fillOpacity="0.08"
                  stroke={c.color || '#ec4899'}
                  strokeWidth="2"
                />
              );
            })}

            {/* Perpendicular Bisector Lines */}
            {lines.map((l) => {
              const p1 = pointMap.get(l.p1Id);
              const p2 = pointMap.get(l.p2Id);
              if (!p1 || !p2) return null;
              const mid = midpoint(p1, p2);
              const dx = p2.x - p1.x;
              const dy = p2.y - p1.y;
              const perpLen = 20;

              return (
                <line
                  key={l.id}
                  x1={toSvgX(mid.x - dy * perpLen)}
                  y1={toSvgY(mid.y + dx * perpLen)}
                  x2={toSvgX(mid.x + dy * perpLen)}
                  y2={toSvgY(mid.y - dx * perpLen)}
                  stroke={l.color || '#10b981'}
                  strokeWidth="1.5"
                  strokeDasharray="4,4"
                />
              );
            })}

            {/* Segments */}
            {segments.map((seg) => {
              const p1 = pointMap.get(seg.p1Id);
              const p2 = pointMap.get(seg.p2Id);
              if (!p1 || !p2) return null;
              const len = distance(p1, p2);
              const midX = (toSvgX(p1.x) + toSvgX(p2.x)) / 2;
              const midY = (toSvgY(p1.y) + toSvgY(p2.y)) / 2;

              return (
                <g key={seg.id}>
                  <line
                    x1={toSvgX(p1.x)}
                    y1={toSvgY(p1.y)}
                    x2={toSvgX(p2.x)}
                    y2={toSvgY(p2.y)}
                    stroke={seg.color || '#3b82f6'}
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                  {/* Length Label */}
                  <text
                    x={midX}
                    y={midY - 8}
                    fill="currentColor"
                    className="fill-muted font-mono text-[10px]"
                    textAnchor="middle"
                  >
                    {len.toFixed(2)}
                  </text>
                </g>
              );
            })}

            {/* Points */}
            {points.map((p) => {
              const isSelected = selectedPointId === p.id || pendingPointIds.includes(p.id);
              const px = toSvgX(p.x);
              const py = toSvgY(p.y);

              return (
                <g
                  key={p.id}
                  className="cursor-grab active:cursor-grabbing"
                  onClick={(e) => handlePointClick(e, p.id)}
                  onPointerDown={(e) => handlePointerDownPoint(e, p.id)}
                >
                  {/* Larger hit target circle */}
                  <circle cx={px} cy={py} r="16" fill="transparent" />

                  {/* Visual Circle */}
                  <circle
                    cx={px}
                    cy={py}
                    r={isSelected ? 7 : 5}
                    fill={isSelected ? '#38bdf8' : '#60a5fa'}
                    stroke="#ffffff"
                    strokeWidth="1.5"
                    className="transition-transform duration-75"
                  />

                  {/* Name Label */}
                  <text
                    x={px + 10}
                    y={py - 10}
                    fill="currentColor"
                    className="fill-ink font-bold font-serif text-xs select-none"
                  >
                    {p.name}
                  </text>
                </g>
              );
            })}
          </svg>
        </main>

        {/* Right Inspector & Metric Panel */}
        {showInspector && (
          <aside className="w-72 shrink-0 border-l border-line bg-panel p-4 flex flex-col justify-between overflow-y-auto max-h-full">
          <div className="space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-line text-xs font-bold uppercase tracking-wider text-ink">
              <Info className="h-4 w-4 text-accent" />
              <span>Geometric Inspector</span>
            </div>

            {/* Active Triangle / Circle Metrics */}
            {activeMetrics && activeMetrics.type === 'triangle' && (
              <div className="rounded-xl border border-line bg-field/60 p-3.5 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-ink">
                  <span>{activeMetrics.name}</span>
                  <span className="rounded bg-accent/15 px-1.5 py-0.5 text-[10px] text-accent">Triangle</span>
                </div>

                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-muted">
                    <span>Side a (BC):</span>
                    <span className="font-mono font-bold text-ink">{activeMetrics.sideA}</span>
                  </div>
                  <div className="flex justify-between text-muted">
                    <span>Side b (CA):</span>
                    <span className="font-mono font-bold text-ink">{activeMetrics.sideB}</span>
                  </div>
                  <div className="flex justify-between text-muted">
                    <span>Side c (AB):</span>
                    <span className="font-mono font-bold text-ink">{activeMetrics.sideC}</span>
                  </div>
                </div>

                <div className="border-t border-line/60 pt-2 space-y-1 text-xs">
                  <div className="flex justify-between text-muted">
                    <span>Angle ∠A:</span>
                    <span className="font-mono font-bold text-accent">{activeMetrics.angA}°</span>
                  </div>
                  <div className="flex justify-between text-muted">
                    <span>Angle ∠B:</span>
                    <span className="font-mono font-bold text-accent">{activeMetrics.angB}°</span>
                  </div>
                  <div className="flex justify-between text-muted">
                    <span>Angle ∠C:</span>
                    <span className="font-mono font-bold text-accent">{activeMetrics.angC}°</span>
                  </div>
                </div>

                <div className="border-t border-line/60 pt-2 space-y-1 text-xs">
                  <div className="flex justify-between text-muted">
                    <span>Perimeter:</span>
                    <span className="font-mono font-bold text-ink">{activeMetrics.perimeter}</span>
                  </div>
                  <div className="flex justify-between text-muted">
                    <span>Heron Area:</span>
                    <span className="font-mono font-bold text-emerald-400">{activeMetrics.area}</span>
                  </div>
                </div>
              </div>
            )}

            {activeMetrics && activeMetrics.type === 'circle' && (
              <div className="rounded-xl border border-line bg-field/60 p-3.5 space-y-3">
                <div className="flex items-center justify-between text-xs font-bold text-ink">
                  <span>{activeMetrics.name}</span>
                  <span className="rounded bg-pink-500/15 px-1.5 py-0.5 text-[10px] text-pink-400">Circle</span>
                </div>

                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-muted">
                    <span>Center:</span>
                    <span className="font-mono font-bold text-ink">{activeMetrics.center}</span>
                  </div>
                  <div className="flex justify-between text-muted">
                    <span>Radius r:</span>
                    <span className="font-mono font-bold text-pink-400">{activeMetrics.radius}</span>
                  </div>
                  <div className="flex justify-between text-muted">
                    <span>Diameter 2r:</span>
                    <span className="font-mono font-bold text-ink">{activeMetrics.diameter}</span>
                  </div>
                  <div className="flex justify-between text-muted">
                    <span>Circumference 2πr:</span>
                    <span className="font-mono font-bold text-ink">{activeMetrics.circumference}</span>
                  </div>
                  <div className="flex justify-between text-muted">
                    <span>Area πr²:</span>
                    <span className="font-mono font-bold text-emerald-400">{activeMetrics.area}</span>
                  </div>
                </div>

                <div className="border-t border-line/60 pt-2 text-[10px] text-muted font-mono truncate">
                  {activeMetrics.equation}
                </div>
              </div>
            )}

            {/* Points List */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-muted">
                Defined Coordinates
              </span>
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {points.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => {
                      setSelectedPointId(p.id);
                      setSelectedObj({ type: 'point', id: p.id });
                    }}
                    className={`flex items-center justify-between rounded-lg px-2.5 py-1.5 text-xs font-mono transition-colors cursor-pointer ${
                      selectedPointId === p.id ? 'bg-accent/15 text-accent' : 'bg-field/40 text-muted hover:bg-field'
                    }`}
                  >
                    <span className="font-bold text-ink">{p.name}</span>
                    <span>({p.x.toFixed(2)}, {p.y.toFixed(2)})</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t border-line pt-3 text-[11px] text-muted space-y-2">
            <div className="flex items-center justify-between">
              <span>Dynamic Solver:</span>
              <span className="text-emerald-400 font-semibold">Euler / Euclid</span>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('lab')}
              className="w-full flex items-center justify-center gap-1 rounded-xl bg-field py-2 text-xs font-semibold text-accent hover:border-accent/40 transition-colors"
            >
              <span>Explore Functions in Graphing Lab</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </aside>
        )}
      </div>
    </div>
  );
}
